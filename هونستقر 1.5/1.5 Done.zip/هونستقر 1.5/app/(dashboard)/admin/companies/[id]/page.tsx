import React from "react";
import { cachedQuery } from "@/lib/db";
import { Company } from "@/lib/types";
import { CompanyDetailsClient } from "./company-details-client";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function CompanyDetailsPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  
  const companies = await cachedQuery<Company>(
    "SELECT * FROM companies WHERE id = ?",
    [id]
  );

  if (!companies || companies.length === 0) {
    notFound();
  }

  const company = companies[0];

  return (
    <div className="p-6 md:p-10 bg-slate-900 min-h-screen">
      <CompanyDetailsClient company={company} />
    </div>
  );
}
