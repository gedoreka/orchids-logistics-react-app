import React from "react";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { EcommerceSectionClient } from "./ecommerce-section-client";

export const metadata = {
  title: "قسم التجارة الإلكترونية - Logistics Hub",
};

export default async function EcommerceSectionPage() {
  const cookieStore = await cookies();
  const sessionCookie = cookieStore.get("auth_session");

  if (!sessionCookie) {
    redirect("/login");
  }

  const session = JSON.parse(sessionCookie.value);
  const companyId = session.company_id;

  if (!companyId) {
    redirect("/dashboard");
  }

  return <EcommerceSectionClient companyId={companyId} />;
}
