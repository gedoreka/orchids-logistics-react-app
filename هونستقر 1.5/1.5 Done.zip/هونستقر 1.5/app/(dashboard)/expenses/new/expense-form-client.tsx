"use client";

import React, { useState, useEffect, useRef } from "react";
import { 
  Plus, Trash2, Save, Tags, Cog, Info, CheckCircle, 
  ChevronDown, X, Calculator, Paperclip, Search, 
  ArrowRight, FileText, History, Bolt, Building2, User as UserIcon,
  Settings, AlertTriangle, CheckCircle2, Loader2, FileCheck, Sparkles,
  Calendar, DollarSign
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useRouter } from "next/navigation";
import { User } from "@/lib/types";
import SubtypeManager from "./subtype-manager";
import { useTranslations } from "@/lib/locale-context";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { HierarchicalSearchableSelect } from "@/components/ui/hierarchical-searchable-select";
import { SuccessModal, LoadingModal, ErrorModal, WarningModal, ConfirmModal } from "@/components/ui/notification-modals";

interface Employee {
  id: number;
  name: string;
  iqama_number: string;
  phone: string;
  package_id: number;
}

interface Account {
  id: number;
  account_code: string;
  account_name: string;
  account_level?: number;
  parent_account?: string | null;
}

interface CostCenter {
  id: number;
  center_code: string;
  center_name: string;
  center_level?: number;
  parent_center?: string | null;
}

interface Subtype {
  main_type: string;
  subtype_name: string;
}

interface ExpenseRow {
  id: string;
  expense_date: string;
  expense_type: string;
  amount: string;
  employee_iqama: string;
  employee_name: string;
  employee_id: string;
  account_code: string;
  cost_center_code: string;
  description: string;
  taxable: boolean;
  tax_inclusive: boolean;
  tax_value: string;
  net_amount: string;
  attachment: File | null;
  manualEmployee: boolean;
}

const mainTypes = {
  iqama: 'iqama',
  fuel: 'fuel',
  housing: 'housing',
  maintenance: 'maintenance',
  general: 'general',
  traffic: 'traffic',
  advances: 'advances'
};

const defaultExpenseValues: Record<string, string> = {
  iqama: 'تجديد هوية',
  fuel: 'منصرفات وقود',
  housing: 'إيجار سكن',
  maintenance: 'صيانة المركبات',
  general: 'منصرفات داخلية',
  traffic: 'مخالفات مرورية',
  advances: 'سلفيات'
};

const headersMap: Record<string, string[]> = {
  iqama: ['التاريخ', 'نوع المصروف', 'المبلغ*', 'رقم الهوية', 'الموظف', 'الحساب*', 'مركز التكلفة*', 'الوصف', 'المستند', 'حذف'],
  fuel: ['التاريخ', 'نوع المصروف', 'المبلغ*', 'ضريبة 15%', 'الصافي', 'الحساب*', 'مركز التكلفة*', 'الوصف', 'المستند', 'حذف'],
  traffic: ['التاريخ', 'نوع المصروف', 'المبلغ*', 'السائق', 'رقم الهوية', 'مركز التكلفة*', 'الحساب*', 'الوصف', 'المستند', 'حذف'],
  advances: ['التاريخ', 'نوع المصروف', 'المبلغ*', 'الموظف', 'رقم الهوية', 'الحساب*', 'مركز التكلفة*', 'الوصف', 'المستند*', 'حذف'],
  default: ['التاريخ', 'نوع المصروف', 'المبلغ*', 'الحساب*', 'مركز التكلفة*', 'الوصف', 'المستند', 'حذف']
};

function EmployeeSelect({ row, type, metadata, updateRow, t }: { 
  row: ExpenseRow; 
  type: string; 
  metadata: any; 
  updateRow: any;
  t: any;
}) {
  const [searchTerm, setSearchTerm] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  const filteredEmployees = (metadata?.employees || []).filter((emp: Employee) => 
    (emp.name || "").toLowerCase().includes(searchTerm.toLowerCase()) || 
    (emp.iqama_number || "").includes(searchTerm)
  );

  if (row.manualEmployee) {
    return (
      <div className="flex items-center space-x-2 space-x-reverse">
        <input 
          type="text" 
          className="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1 text-sm text-white placeholder:text-white/30"
          placeholder={t("form.employeeName")}
          value={row.employee_name || ""}
          onChange={(e) => updateRow(type, row.id, 'employee_name', e.target.value)}
        />
        <button 
          type="button"
          onClick={() => updateRow(type, row.id, 'manualEmployee', false)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all text-xs font-black shrink-0 shadow-lg shadow-blue-200"
        >
          <Search className="w-4 h-4" />
          <span>البحث في قاعدة البيانات</span>
        </button>
      </div>
    );
  }

  return (
    <div className="flex items-center space-x-2 space-x-reverse">
      <div className="relative w-full">
        <Popover open={isOpen} onOpenChange={setIsOpen}>
          <PopoverTrigger asChild>
            <div 
              className="w-full bg-white/5 border border-white/15 cursor-pointer text-sm font-medium py-1.5 px-3 flex items-center justify-between min-h-[36px] hover:bg-white/10 hover:border-blue-500/40 rounded-lg transition-all"
            >
              <span className={row.employee_name ? "text-white font-bold" : "text-white/40"}>
                {row.employee_name || t("form.selectEmployee")}
              </span>
              <ChevronDown className={`w-4 h-4 text-white/40 transition-transform duration-200 ${isOpen ? 'rotate-180 text-blue-400' : ''}`} />
            </div>
          </PopoverTrigger>
          <PopoverContent 
            className="p-0 w-[400px] bg-white border border-slate-200 rounded-2xl shadow-[0_20px_70px_-10px_rgba(0,0,0,0.3)] overflow-hidden z-[9999]" 
            align="start"
            sideOffset={8}
          >
            <div className="p-4 border-b border-slate-100 bg-slate-50/50">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  className="w-full pr-10 pl-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                  placeholder={t("form.searchPlaceholder")}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  autoFocus
                />
              </div>
            </div>
            <div className="max-h-96 overflow-y-auto custom-scrollbar">
              {filteredEmployees.length > 0 ? (
                filteredEmployees.map((emp: Employee) => (
                  <div
                    key={emp.id}
                    onClick={() => {
                      updateRow(type, row.id, 'employee_id', emp.id.toString());
                      updateRow(type, row.id, 'employee_name', emp.name);
                      updateRow(type, row.id, 'employee_iqama', emp.iqama_number);
                      setIsOpen(false);
                      setSearchTerm("");
                    }}
                    className="px-5 py-4 hover:bg-blue-50 cursor-pointer border-b border-slate-50 last:border-0 transition-all flex flex-col group/item"
                  >
                    <div className="font-bold text-slate-900 text-[15px] group-hover/item:text-blue-700">{emp.name}</div>
                    <div className="flex items-center gap-3 mt-1.5">
                      <span className="bg-slate-100 text-slate-700 px-2.5 py-1 rounded-md text-[11px] font-mono border border-slate-200">
                        {emp.iqama_number || "بدون هوية"}
                      </span>
                      {emp.phone && (
                        <span className="text-xs text-slate-400 flex items-center gap-1">
                          <Info className="w-3 h-3" />
                          {emp.phone}
                        </span>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-10 text-center">
                  <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4 border border-slate-100">
                    <Search className="w-8 h-8 text-slate-300" />
                  </div>
                  <p className="text-base text-slate-400 font-medium">{t("form.noResults")}</p>
                </div>
              )}
            </div>
          </PopoverContent>
        </Popover>
      </div>
          <button 
            type="button"
            onClick={() => updateRow(type, row.id, 'manualEmployee', true)}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all text-xs font-black shrink-0 shadow-lg shadow-blue-200"
          >
            <Plus className="w-4 h-4" />
            <span>إدخال البيانات يدوياً</span>
          </button>
    </div>
  );
}

export default function ExpenseFormClient({ user }: { user: User }) {
  const router = useRouter();
  const t = useTranslations("expenses");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [metadata, setMetadata] = useState<{
    accounts: Account[];
    costCenters: CostCenter[];
    subtypes: Subtype[];
    employees: Employee[];
    voucherNumber: number;
  } | null>(null);

  const [sections, setSections] = useState<Record<string, ExpenseRow[]>>({});
  const [selectedTypeToAdd, setSelectedTypeToAdd] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);
  const [savedCount, setSavedCount] = useState(0);
  const [showSubtypeManager, setShowSubtypeManager] = useState(false);

  const [successModal, setSuccessModal] = useState<{ isOpen: boolean; type: 'delete' | 'update' | 'create' | null; title: string }>({ isOpen: false, type: null, title: '' });
  const [loadingModal, setLoadingModal] = useState(false);
  const [errorModal, setErrorModal] = useState<{ isOpen: boolean; title: string; message: string }>({ isOpen: false, title: '', message: '' });
  const [warningModal, setWarningModal] = useState<{ isOpen: boolean; title: string; message: string; missingFields: string[] }>({ isOpen: false, title: '', message: '', missingFields: [] });
  const [confirmModal, setConfirmModal] = useState<{ isOpen: boolean; title: string; message: string; details: React.ReactNode; onConfirm: () => void }>({ isOpen: false, title: '', message: '', details: null, onConfirm: () => {} });

  
  const fetchMetadata = async () => {
    try {
      const res = await fetch(`/api/expenses/metadata?company_id=${user.company_id}&user_id=${user.id}`);
      const data = await res.json();
      setMetadata(data);
    } catch (error) {
      console.error("Failed to fetch metadata", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMetadata();
  }, [user.company_id, user.id]);

  const addSection = (type: string) => {
    if (!type) return;
    if (sections[type]) return;

    const newRow: ExpenseRow = {
      id: Math.random().toString(36).substr(2, 9),
      expense_date: new Date().toISOString().split('T')[0],
      expense_type: defaultExpenseValues[type] || "",
      amount: "",
      employee_iqama: "",
      employee_name: "",
      employee_id: "",
      account_code: "",
      cost_center_code: "",
      description: "",
      taxable: false,
      tax_inclusive: false,
      tax_value: "0",
      net_amount: "0",
      attachment: null,
      manualEmployee: false
    };

    setSections(prev => ({
      ...prev,
      [type]: [newRow]
    }));
    setSelectedTypeToAdd("");
  };

  const addRow = (type: string) => {
    const newRow: ExpenseRow = {
      id: Math.random().toString(36).substr(2, 9),
      expense_date: new Date().toISOString().split('T')[0],
      expense_type: defaultExpenseValues[type] || "",
      amount: "",
      employee_iqama: "",
      employee_name: "",
      employee_id: "",
      account_code: "",
      cost_center_code: "",
      description: "",
      taxable: false,
      tax_inclusive: false,
      tax_value: "0",
      net_amount: "0",
      attachment: null,
      manualEmployee: false
    };

    setSections(prev => ({
      ...prev,
      [type]: [...prev[type], newRow]
    }));
  };

  const removeRow = (type: string, id: string) => {
    setSections(prev => {
      const updated = prev[type].filter(row => row.id !== id);
      if (updated.length === 0) {
        const { [type]: removed, ...rest } = prev;
        return rest;
      }
      return { ...prev, [type]: updated };
    });
  };

  const removeSection = (type: string) => {
    setSections(prev => {
      const { [type]: removed, ...rest } = prev;
      return rest;
    });
  };

  const updateRow = (type: string, id: string, field: keyof ExpenseRow, value: any) => {
    setSections(prev => {
      const updatedRows = prev[type].map(row => {
        if (row.id === id) {
          let updatedRow = { ...row, [field]: value };
          if (type === 'fuel') {
            const amtStr = String(updatedRow.amount || "0").trim();
            const amt = parseFloat(amtStr) || 0;
            if (updatedRow.taxable) {
              const tax = amt * 0.15;
              updatedRow.tax_value = tax.toFixed(2);
              updatedRow.net_amount = (amt + tax).toFixed(2);
            } else {
              updatedRow.tax_value = "0";
              updatedRow.net_amount = amt.toFixed(2);
            }
          } else {
            updatedRow.net_amount = updatedRow.amount;
          }
          return updatedRow;
        }
        return row;
      });
      return { ...prev, [type]: updatedRows };
    });
  };

  const handleSubmit = async () => {
    if (Object.keys(sections).length === 0) return;

    // Collect missing fields
    const rowsWithMissingFields: string[] = [];
    
    Object.entries(sections).forEach(([type, rows]) => {
      rows.forEach((row, index) => {
        const rowNumber = index + 1;
        const missing: string[] = [];
        
        if (!String(row.account_code || "").trim()) missing.push('شجرة الحسابات');
        if (!String(row.cost_center_code || "").trim()) missing.push('مركز التكلفة');
        if (!String(row.amount || "").trim() || parseFloat(row.amount) <= 0) missing.push('المبلغ');
        if (!String(row.expense_date || "").trim()) missing.push('التاريخ');
        
        if (missing.length > 0) {
          rowsWithMissingFields.push(`صف ${rowNumber} (${t(`types.${type}`)}) - ${missing.join('، ')}`);
        }
      });
    });

    if (rowsWithMissingFields.length > 0) {
      setWarningModal({
        isOpen: true,
        title: 'حقول إجبارية مفقودة',
        message: 'يرجى إكمال الحقول التالية قبل الحفظ:',
        missingFields: rowsWithMissingFields
      });
      return;
    }

    // Calculate totals
    const allRows = Object.values(sections).flat();
    const totalCount = allRows.length;
    const totalAmount = allRows.reduce((sum, row) => sum + (parseFloat(row.net_amount) || parseFloat(row.amount) || 0), 0);
    const types = Object.keys(sections).map(type => t(`types.${type}`));
    const month = new Date().toLocaleDateString('ar-SA', { month: 'long', year: 'numeric' });

    setConfirmModal({
      isOpen: true,
      title: 'تأكيد حفظ المنصرفات',
      message: 'هل تريد حفظ المنصرفات التالية؟',
      details: (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-rose-50 border border-rose-100 rounded-xl p-4 text-center">
              <p className="text-xs text-rose-500 font-bold mb-1">عدد العمليات</p>
              <p className="text-2xl font-black text-rose-700">{totalCount}</p>
            </div>
            <div className="bg-green-50 border border-green-100 rounded-xl p-4 text-center">
              <p className="text-xs text-green-500 font-bold mb-1">إجمالي المبلغ</p>
              <p className="text-2xl font-black text-green-700">{totalAmount.toFixed(2)}</p>
            </div>
          </div>
          {types.length > 0 && (
            <div className="flex flex-wrap gap-2 justify-center">
              {types.map((t, idx) => (
                <span key={idx} className="bg-rose-100 text-rose-700 px-3 py-1 rounded-full text-xs font-bold">{t}</span>
              ))}
            </div>
          )}
          <p className="text-center text-sm text-slate-500">{month}</p>
        </div>
      ),
      onConfirm: () => executeSave()
    });
  };

  const executeSave = async () => {
    setLoadingModal(true);

    setSubmitting(true);
    const formData = new FormData();
    formData.append("company_id", user.company_id.toString());
    formData.append("user_id", user.id.toString());
    formData.append("month", new Date().toISOString().substring(0, 7));
    
    let rowCount = 0;
    Object.entries(sections).forEach(([mainType, rows]) => {
      rows.forEach(row => {
        formData.append("main_type[]", mainType);
        formData.append("expense_date[]", row.expense_date || "");
        formData.append("expense_type[]", row.expense_type || "");
        formData.append("amount[]", row.amount || "");
        formData.append("employee_iqama[]", row.employee_iqama || "");
        formData.append("employee_name[]", row.employee_name || "");
        formData.append("employee_id[]", row.employee_id || "");
        formData.append("account_code[]", row.account_code || "");
        formData.append("cost_center_code[]", row.cost_center_code || "");
        formData.append("description[]", row.description || "");
        formData.append("tax_value[]", row.tax_value || "0");
        formData.append("net_amount[]", row.net_amount || "");
        rowCount++;
        if (row.attachment) {
          formData.append("attachment[]", row.attachment);
        } else {
          formData.append("attachment[]", "");
        }
      });
    });
    try {
      const res = await fetch("/api/expenses/save", {
        method: "POST",
        body: formData,
      });
      
      if (!res.ok) {
        throw new Error(`HTTP Error: ${res.status} ${res.statusText}`);
      }
      
      const data = await res.json();
      
        if (data.success) {
          const allRows = Object.values(sections).flat();
          const totalAmount = allRows.reduce((sum, row) => sum + (parseFloat(row.net_amount) || parseFloat(row.amount) || 0), 0);
          
          setSavedCount(data.savedCount);
          setLoadingModal(false);
          setConfirmModal(prev => ({ ...prev, isOpen: false }));
          setSuccessModal({ isOpen: true, type: 'create', title: `تم حفظ ${data.savedCount} منصرف بنجاح` });
        } else {
        const errorMsg = data.message || data.error || "فشل حفظ المنصرفات";
        setErrorModal({ isOpen: true, title: 'خطأ في الحفظ', message: errorMsg });
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "حدث خطأ في الاتصال";
      setErrorModal({ isOpen: true, title: 'خطأ في الحفظ', message: errorMessage });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-[96%] w-[96%] mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative bg-gradient-to-br from-slate-800 via-slate-700 to-slate-600 rounded-3xl shadow-2xl overflow-hidden border border-slate-500/30"
      >
        <div className="h-1.5 w-full absolute top-0 left-0 bg-gradient-to-r from-blue-500 via-indigo-500 via-purple-500 via-emerald-500 to-blue-500 z-10" />
        <div className="relative overflow-hidden bg-gradient-to-br from-slate-900/80 via-slate-800/80 to-slate-900/80 p-8 text-white border-b border-white/10">
            <div className="absolute top-0 right-0 w-40 h-40 rounded-full -translate-y-12 translate-x-12 blur-3xl pointer-events-none bg-blue-500/10" />
            <div className="relative z-10 flex flex-col items-center justify-center text-center space-y-4">
              <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-sm border border-white/15">
                <Plus className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-2xl font-bold tracking-tight bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400 bg-clip-text text-transparent">{t("form.addMultiple")}</h1>
              <p className="text-white/50 max-w-2xl">{t("form.subtitle")}</p>
            </div>
        </div>

        <div className="p-6 space-y-6 rounded-2xl">
          <motion.div 
            className="bg-white/95 dark:bg-white/5 backdrop-blur-sm p-4 rounded-2xl shadow-lg border border-white/50 dark:border-white/10 flex flex-col md:flex-row items-center justify-between gap-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <div className="flex items-center space-x-4 space-x-reverse">
              <div className="p-2.5 bg-indigo-50 dark:bg-indigo-500/20 rounded-xl text-indigo-600 dark:text-indigo-400">
                <Tags className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">{t("form.manageCustomTypes")}</h3>
                <p className="text-xs text-slate-700 dark:text-slate-400">{t("form.manageCustomTypesDesc")}</p>
              </div>
            </div>
            <button 
              onClick={() => setShowSubtypeManager(true)}
              className="bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-500/20 dark:hover:bg-indigo-500/30 text-indigo-700 dark:text-indigo-300 px-4 py-2 rounded-xl font-bold transition-all flex items-center space-x-2 space-x-reverse border border-indigo-100 dark:border-indigo-500/30 text-sm"
            >
              <Settings className="w-4 h-4" />
              <span>{t("form.manageBtn")}</span>
            </button>
          </motion.div>
  
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-4"
          >
            <div className="bg-white/95 dark:bg-white/5 backdrop-blur-md p-4 rounded-xl border border-white/50 dark:border-white/10 shadow-md flex items-center space-x-3 space-x-reverse">
                <div className="p-2.5 bg-blue-50 dark:bg-blue-500/20 rounded-lg text-blue-600 dark:text-blue-400">
                  <History className="w-5 h-5" />
                </div>
                <div>
                <p className="text-xs text-slate-700 dark:text-slate-400">{t("form.currentMonth")}</p>
                    <p className="text-base font-bold text-slate-900 dark:text-white">{new Date().toLocaleString('en-US', { month: 'long', year: 'numeric' })}</p>
                </div>
              </div>
              <div className="bg-white/95 dark:bg-white/5 backdrop-blur-md p-4 rounded-xl border border-white/50 dark:border-white/10 shadow-md flex items-center space-x-3 space-x-reverse">
                <div className="p-2.5 bg-green-50 dark:bg-green-500/20 rounded-lg text-green-600 dark:text-green-400">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                <p className="text-xs text-slate-700 dark:text-slate-400">{t("form.nextVoucher")}</p>
                    <p className="text-base font-bold text-slate-900 dark:text-white">{metadata?.voucherNumber}</p>
                </div>
              </div>
              <div className="bg-white/95 dark:bg-white/5 backdrop-blur-md p-4 rounded-xl border border-white/50 dark:border-white/10 shadow-md flex items-center space-x-3 space-x-reverse">
                <div className="p-2.5 bg-purple-50 dark:bg-purple-500/20 rounded-lg text-purple-600 dark:text-purple-400">
                  <Bolt className="w-5 h-5" />
                </div>
                <div>
                <p className="text-xs text-slate-700 dark:text-slate-400">{t("form.voucherStatus")}</p>
                    <p className="text-base font-bold text-slate-900 dark:text-white">{t("form.new")}</p>
              </div>
            </div>
          </motion.div>
  
          <motion.div 
            className="bg-white/95 dark:bg-white/5 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-white/50 dark:border-white/10"
            whileHover={{ y: -2 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <div className="flex items-center space-x-2 space-x-reverse mb-4">
              <Tags className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">{t("form.chooseType")}</h2>
            </div>
            <div className="flex flex-col md:flex-row gap-4">
              <select 
                className="flex-1 bg-slate-50 dark:bg-slate-700/50 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm text-gray-900 dark:text-white dark:text-white"
                value={selectedTypeToAdd}
                onChange={(e) => setSelectedTypeToAdd(e.target.value)}
              >
                <option value="">{t("form.selectType")}</option>
                {Object.entries(mainTypes).map(([key]) => (
                  <option key={key} value={key}>{t(`types.${key}`)}</option>
                ))}
              </select>
              <button 
                onClick={() => addSection(selectedTypeToAdd)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-xl font-bold transition-all flex items-center justify-center space-x-2 space-x-reverse shadow-lg shadow-blue-200 text-sm"
              >
                <Plus className="w-4 h-4" />
                <span>{t("form.addTypeBtn")}</span>
              </button>
            </div>
          </motion.div>
        </div>

        <div className="space-y-6 p-6 rounded-2xl">
          <AnimatePresence>
            {Object.entries(sections).map(([type, rows]) => (
              <motion.div 
                key={type}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
className="bg-white/95 dark:bg-white/5 backdrop-blur-sm rounded-2xl shadow-lg border border-white/50 dark:border-white/10 overflow-hidden"
                >
                  <div className="bg-white/5 p-4 border-b border-white/10 flex items-center justify-between">
                    <div className="flex items-center space-x-3 space-x-reverse">
                      <div className="p-2 bg-blue-500/20 rounded-lg text-blue-400">
                        <Building2 className="w-4 h-4" />
                      </div>
                      <h3 className="text-base font-bold text-white">{t(`types.${type}`)}</h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeSection(type)}
                    className="text-red-400 hover:bg-red-500/20 p-1.5 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="overflow-x-auto p-4">
                      <table className="w-full text-start border-collapse min-w-[1000px]">
                        <thead>
                          <tr className="bg-blue-600 border-b border-blue-700 text-white text-[10px] uppercase tracking-wider">
                              {headersMap[type] ? headersMap[type].map((h, i) => {
                                const isRequired = h.endsWith('*');
                                const cleanH = h.replace('*', '');
                                const key = cleanH === 'التاريخ' ? 'date' : cleanH === 'نوع المصروف' ? 'type' : cleanH === 'المبلغ' ? 'amount' : cleanH === 'ضريبة 15%' ? 'tax' : cleanH === 'الصافي' ? 'net' : cleanH === 'الحساب' ? 'account' : cleanH === 'مركز التكلفة' ? 'costCenter' : cleanH === 'الوصف' ? 'description' : cleanH === 'المستند' ? 'document' : cleanH === 'رقم الهوية' ? 'iqamaNumber' : cleanH === 'الموظف' ? 'employee' : cleanH === 'السائق' ? 'driver' : 'delete';
                                return (
                                <th key={i} className="px-4 py-4 font-black text-start whitespace-nowrap">
                                  {t(`form.${key}`)}
                                  {isRequired && <span className="text-red-300 mr-1 text-sm">★</span>}
                                </th>
                                );
                              }) : headersMap.default.map((h, i) => {
                                const isRequired = h.endsWith('*');
                                const cleanH = h.replace('*', '');
                                const key = cleanH === 'التاريخ' ? 'date' : cleanH === 'نوع المصروف' ? 'type' : cleanH === 'المبلغ' ? 'amount' : cleanH === 'الحساب' ? 'account' : cleanH === 'مركز التكلفة' ? 'costCenter' : cleanH === 'الوصف' ? 'description' : cleanH === 'المستند' ? 'document' : 'delete';
                                return (
                                <th key={i} className="px-4 py-4 font-black text-start whitespace-nowrap">
                                  {t(`form.${key}`)}
                                  {isRequired && <span className="text-red-300 mr-1 text-sm">★</span>}
                                </th>
                                );
                              })}
                          </tr>
                        </thead>
                        <tbody>
                          {rows.map((row) => (
                            <tr key={row.id} className="border-b border-white/5 hover:bg-white/5 transition-colors group">
                              <td className="px-2 py-4">

                              <input 
                                type="date" 
                                className="w-full bg-transparent border-none focus:ring-0 text-xs font-bold text-gray-900 dark:text-white"
                                value={row.expense_date || ""}
                                onChange={(e) => updateRow(type, row.id, 'expense_date', e.target.value)}
                                required
                              />
                            </td>
                            <td className="px-2 py-4">
                              <select 
                                className="w-full bg-transparent border-none focus:ring-0 text-xs font-bold text-gray-900 dark:text-white"
                                value={row.expense_type || ""}
                                onChange={(e) => updateRow(type, row.id, 'expense_type', e.target.value)}
                              >
                                <option value="">{t("form.selectType")}</option>
                                {(metadata?.subtypes || [])
                                  .filter(s => s.main_type === type)
                                  .map(s => (
                                    <option key={s.subtype_name} value={s.subtype_name}>{s.subtype_name}</option>
                                  ))}
                                <option value="other">أخرى</option>
                              </select>
                            </td>
                            <td className="px-2 py-4">
                              <input 
                                type="number" 
                                className="w-20 bg-transparent border-none focus:ring-0 text-xs font-black text-gray-900 dark:text-white"
                                placeholder="0.00"
                                value={row.amount || ""}
                                onChange={(e) => updateRow(type, row.id, 'amount', e.target.value)}
                                required
                              />
                            </td>
                            {type === 'fuel' && (
                              <>
                                <td className="px-2 py-4 text-center">
                                  <input 
                                    type="checkbox" 
                                    className="w-4 h-4 rounded text-blue-600 cursor-pointer"
                                    checked={row.taxable}
                                    onChange={(e) => updateRow(type, row.id, 'taxable', e.target.checked)}
                                  />
                                </td>
                                <td className="px-2 py-4">
                                  <span className="text-xs font-black text-emerald-400 bg-emerald-500/20 px-2 py-1 rounded-lg border border-emerald-500/20">{row.net_amount}</span>
                                </td>
                              </>
                            )}
                            {(type === 'iqama') && (
                              <>
                                <td className="px-2 py-4">
                                  <input 
                                    type="text" 
                                    className="w-24 bg-transparent border-none focus:ring-0 text-xs font-bold text-gray-900 dark:text-white"
                                    value={row.employee_iqama || ""}
                                    readOnly={!row.manualEmployee}
                                    onChange={(e) => updateRow(type, row.id, 'employee_iqama', e.target.value)}
                                    placeholder={t("form.iqamaNumber")}
                                  />
                                </td>
                                <td className="px-2 py-4 min-w-[200px]">
                                  <EmployeeSelect row={row} type={type} metadata={metadata} updateRow={updateRow} t={t} />
                                </td>
                              </>
                            )}
                            {(type === 'traffic' || type === 'advances') && (
                              <>
                                <td className="px-2 py-4 min-w-[200px]">
                                  <EmployeeSelect row={row} type={type} metadata={metadata} updateRow={updateRow} t={t} />
                                </td>
                                <td className="px-2 py-4">
                                  <input 
                                    type="text" 
                                    className="w-24 bg-transparent border-none focus:ring-0 text-xs font-bold text-gray-900 dark:text-white"
                                    value={row.employee_iqama || ""}
                                    readOnly={!row.manualEmployee}
                                    onChange={(e) => updateRow(type, row.id, 'employee_iqama', e.target.value)}
                                    placeholder={t("form.iqamaNumber")}
                                  />
                                </td>
                              </>
                            )}
                              <td className="px-2 py-4">
                                <div className="w-48">
                                  <HierarchicalSearchableSelect
                                    items={(metadata?.accounts || []).map(acc => ({
                                      id: acc.id,
                                      code: acc.account_code,
                                      name: acc.account_name,
                                      level: acc.account_level,
                                      parent: acc.parent_account
                                    }))}
                                    value={row.account_code || ""}
                                    onSelect={(val) => updateRow(type, row.id, 'account_code', val)}
                                    placeholder={t("form.account")}
                                  />
                                </div>
                              </td>
                                <td className="px-2 py-4">
                                  <div className="w-48">
                                    <HierarchicalSearchableSelect
                                      items={(metadata?.costCenters || []).map(cc => ({
                                        id: cc.id,
                                        code: cc.center_code,
                                        name: cc.center_name,
                                        level: cc.center_level,
                                        parent: cc.parent_center
                                      }))}
                                      value={row.cost_center_code || ""}
                                      onSelect={(val) => updateRow(type, row.id, 'cost_center_code', val)}
                                      placeholder={t("form.costCenter")}
                                    />
                                  </div>
                                </td>
                          <td className="px-2 py-4">
                            <input 
                              type="text" 
                              className="w-full bg-transparent border-none focus:ring-0 text-sm text-gray-900 dark:text-white"
                              placeholder={t("form.description")}
                              value={row.description || ""}
                              onChange={(e) => updateRow(type, row.id, 'description', e.target.value)}
                            />
                          </td>
                          <td className="px-2 py-4 text-center">
                            <label className="cursor-pointer hover:text-blue-600 transition-colors">
                              <Paperclip className={`w-5 h-5 ${row.attachment ? 'text-green-600' : 'text-slate-400'}`} />
                              <input 
                                type="file" 
                                className="hidden" 
                                onChange={(e) => updateRow(type, row.id, 'attachment', e.target.files ? e.target.files[0] : null)}
                              />
                            </label>
                          </td>
                          <td className="px-2 py-4 text-center">
                            <button 
                              type="button"
                              onClick={() => removeRow(type, row.id)}
                              className="text-slate-300 hover:text-red-500 transition-colors"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="p-4 bg-white/5 border-t border-white/10">
                  <button
                    type="button"
                    onClick={() => addRow(type)}
                    className="flex items-center space-x-2 space-x-reverse text-blue-400 hover:text-blue-300 font-semibold text-sm transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{t("form.addRow")}</span>
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {Object.keys(sections).length > 0 && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex justify-center pt-8 pb-8"
            >
              <button 
                type="button"
                onClick={handleSubmit}
                disabled={submitting}
                className={`bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-xl font-bold transition-all flex items-center space-x-3 space-x-reverse shadow-xl shadow-green-200/50 dark:shadow-green-900/50 transform active:scale-95 ${submitting ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {submitting ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                ) : (
                  <Save className="w-5 h-5" />
                )}
                <span className="text-lg">{t("form.saveAll")}</span>
              </button>
            </motion.div>
          )}
        </div>
      </motion.div>

      <AnimatePresence>
        {showSuccess && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/70 backdrop-blur-md z-[9998]"
              onClick={() => {
                setShowSuccess(false);
                setSections({});
                setSelectedTypeToAdd("");
              }}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.85, y: 50 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.85, y: 50 }}
              transition={{ type: "spring", duration: 0.5 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[9999] bg-gradient-to-br from-green-500 via-emerald-600 to-teal-700 text-white p-10 rounded-3xl shadow-2xl text-center w-[90%] max-w-[550px]"
            >
              <div className="w-24 h-24 bg-white/25 rounded-full flex items-center justify-center mx-auto mb-6 animate-bounce">
                <CheckCircle className="w-16 h-16 text-white drop-shadow-lg" />
              </div>
              <h2 className="text-4xl font-black mb-4 drop-shadow-md">✓ تم الحفظ بنجاح</h2>
              <p className="text-xl opacity-95 mb-2 font-bold">
                تم حفظ {savedCount} من السجلات بنجاح في النظام
              </p>
              <p className="text-base opacity-85 mb-10">
                يمكنك الآن إدخال منصروفات جديدة أو العودة للقائمة الرئيسية
              </p>
              <div className="flex gap-4 justify-center">
                <button 
                  onClick={() => {
                    setShowSuccess(false);
                    setSections({});
                    setSelectedTypeToAdd("");
                  }}
                  className="bg-white text-green-700 px-8 py-3.5 rounded-xl font-bold text-base hover:bg-green-50 transition-all flex items-center gap-2 shadow-lg hover:shadow-xl active:scale-95"
                >
                  <Plus className="w-5 h-5" />
                  <span>إدخال جديد</span>
                </button>
                <button 
                  onClick={() => {
                    setShowSuccess(false);
                    setTimeout(() => router.push('/expenses'), 200);
                  }}
                  className="bg-white/20 backdrop-blur-sm text-white border-2 border-white/40 px-8 py-3.5 rounded-xl font-bold text-base hover:bg-white/30 transition-all flex items-center gap-2 shadow-lg hover:shadow-xl active:scale-95"
                >
                  <span>العودة للمركز</span>
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

        {/* Luxury Notification Modal */}
        <WarningModal
          isOpen={warningModal.isOpen}
          title={warningModal.title}
          message={warningModal.message}
          missingFields={warningModal.missingFields}
          onClose={() => setWarningModal(prev => ({ ...prev, isOpen: false }))}
        />
        <ConfirmModal
          isOpen={confirmModal.isOpen}
          title={confirmModal.title}
          message={confirmModal.message}
          details={confirmModal.details}
          confirmText="تأكيد الحفظ"
          onConfirm={() => {
            setConfirmModal(prev => ({ ...prev, isOpen: false }));
            confirmModal.onConfirm();
          }}
          onCancel={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
        />
        <SuccessModal
          isOpen={successModal.isOpen}
          type={successModal.type}
          title={successModal.title}
          onClose={() => {
            setSuccessModal({ isOpen: false, type: null, title: '' });
            setSections({});
            setSelectedTypeToAdd("");
            fetchMetadata();
          }}
        />
        <LoadingModal isOpen={loadingModal} title="جاري الحفظ..." message="يرجى الانتظار" />
        <ErrorModal
          isOpen={errorModal.isOpen}
          title={errorModal.title}
          message={errorModal.message}
          onClose={() => setErrorModal({ isOpen: false, title: '', message: '' })}
        />

        <AnimatePresence>
          {showSubtypeManager && (
            <SubtypeManager 
              companyId={user.company_id}
              userId={user.id}
              onClose={() => setShowSubtypeManager(false)}
              onRefresh={fetchMetadata}
            />
          )}
        </AnimatePresence>

        <style jsx global>{`
        .glow-text {
          text-shadow: 0 0 10px rgba(59, 130, 246, 0.15), 0 0 20px rgba(147, 51, 234, 0.1);
        }
        .glow-text-white {
          text-shadow: 0 0 10px rgba(255, 255, 255, 0.4), 0 0 20px rgba(59, 130, 246, 0.3);
        }
        input[type="date"]::-webkit-calendar-picker-indicator {
          cursor: pointer;
          filter: invert(0.5);
        }
      `}</style>
    </div>
  );
}
