import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { cachedQuery } from "@/lib/db";
import { User } from "@/lib/types";
import ExpenseFormClient from "./expense-form-client";

export default async function NewExpensePage() {
  const cookieStore = await cookies();
  const sessionCookie = cookieStore.get("auth_session");

  if (!sessionCookie) {
    redirect("/login");
  }

  const session = JSON.parse(sessionCookie.value);
  const users = await cachedQuery<User>(
    "SELECT id, name, email, role, company_id FROM users WHERE id = ?",
    [session.user_id]
  );

  if (users.length === 0) {
    redirect("/login");
  }

  const user = users[0];

    return (
      <div className="w-full py-6">
        <ExpenseFormClient user={user} />
      </div>
    );
}
