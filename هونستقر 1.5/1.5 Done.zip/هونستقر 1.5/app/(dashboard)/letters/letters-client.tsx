"use client";

import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  FileText, Plus, Search, Edit2, Trash2, Printer, Download,
  Calendar, User, Building2, X, Check, Mail, FileSignature,
  ClipboardList, Receipt, ChevronLeft, Eye, Settings, Upload, MoveVertical,
  Send, AtSign, Loader2, AlertTriangle, Sparkles, Shield, CheckCircle,
  PenLine, Bookmark, Tag, Wand2
} from "lucide-react";
import { toast } from "sonner";
import * as pdfjsLib from "pdfjs-dist";
import { useTranslations, useLocale } from "@/lib/locale-context";

pdfjsLib.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjsLib.version}/build/pdf.worker.min.mjs`;

interface LetterTemplate {
  id: number;
  template_key: string;
  template_name: string;
  template_name_ar: string;
  template_content: string;
  placeholders: string[];
  is_system_template: boolean;
  company_id?: number;
  placeholder_labels?: Record<string, string> | string;
}

interface GeneratedLetter {
  id: number;
  company_id: number;
  template_id: number;
  letter_number: string;
  letter_data: Record<string, string>;
  status: string;
  notes: string | null;
  created_at: string;
  template_name_ar: string;
  template_key: string;
}

interface CompanyInfo {
  name: string;
  commercial_number: string;
  email?: string;
  letterhead_path?: string;
  letterhead_top_margin?: number;
  letterhead_bottom_margin?: number;
}

const templateIcons: Record<string, any> = {
  salary_receipt: Receipt,
  work_receipt: ClipboardList,
  custody_receipt: Receipt,
  resignation_letter: Mail,
  final_clearance: FileSignature,
};

const templateColors: Record<string, string> = {
  salary_receipt: "from-blue-600 to-cyan-600",
  work_receipt: "from-blue-500 to-indigo-600",
  custody_receipt: "from-amber-500 to-orange-600",
  resignation_letter: "from-rose-500 to-pink-600",
  final_clearance: "from-emerald-500 to-teal-600",
};

function PreviewPage({ content, letterheadPath, topMargin, bottomMargin, convertPdfToImage }: {
  content: string;
  letterheadPath?: string;
  topMargin: number;
  bottomMargin: number;
  convertPdfToImage: (url: string) => Promise<string>;
}) {
  const [bgImage, setBgImage] = useState<string>('');

  useEffect(() => {
    if (!letterheadPath) return;
    if (letterheadPath.toLowerCase().endsWith('.pdf')) {
      convertPdfToImage(letterheadPath).then(setBgImage);
    } else {
      setBgImage(letterheadPath);
    }
  }, [letterheadPath, convertPdfToImage]);

  // Scale: A4 = 794x1123px at 96dpi, we show at 595px width
  const scale = 595 / 794;
  const scaledTop = Math.round(topMargin * scale);
  const scaledBottom = Math.round(bottomMargin * scale);

  return (
    <div style={{ width: '595px', flexShrink: 0 }}>
      <div
        className="bg-white shadow-2xl"
        style={{
          width: '595px',
          minHeight: '842px',
          position: 'relative',
        }}
      >
        {/* Letterhead background */}
        {bgImage && (
          <img
            src={bgImage}
            alt=""
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: '842px',
              objectFit: 'fill',
              zIndex: 0,
              pointerEvents: 'none',
            }}
            crossOrigin="anonymous"
          />
        )}
        {/* Content on top of letterhead with white semi-transparent bg for readability */}
        <div
          dir="rtl"
          style={{
            position: 'relative',
            zIndex: 1,
            paddingTop: `${scaledTop}px`,
            paddingBottom: `${scaledBottom}px`,
            paddingLeft: '35px',
            paddingRight: '35px',
          }}
        >
          <div
            style={{
              background: 'rgba(255,255,255,0.88)',
              borderRadius: '8px',
              padding: '24px 20px',
              fontFamily: "'Tajawal', 'Arial', sans-serif",
              fontSize: '13px',
              lineHeight: 1.7,
              color: '#1a1a1a',
            }}
            dangerouslySetInnerHTML={{ __html: content }}
          />
        </div>
      </div>
    </div>
  );
}

const placeholderLabels: Record<string, string> = {
  employee_name: "اسم الموظف",
  id_number: "رقم الهوية",
  company_name: "اسم الشركة",
  commercial_number: "رقم السجل التجاري",
  start_date: "تاريخ البداية",
  job_title: "المسمى الوظيفي",
  profession: "المهنة",
  nationality: "الجنسية",
  resignation_day: "يوم الاستقالة",
  resignation_date: "تاريخ الاستقالة",
  resignation_reason: "سبب الاستقالة",
  receipt_date: "تاريخ الاستلام",
  item_1: "البند 1", qty_1: "الكمية 1", value_1: "القيمة 1", status_1: "الحالة 1", notes_1: "ملاحظات 1",
  item_2: "البند 2", qty_2: "الكمية 2", value_2: "القيمة 2", status_2: "الحالة 2", notes_2: "ملاحظات 2",
  item_3: "البند 3", qty_3: "الكمية 3", value_3: "القيمة 3", status_3: "الحالة 3", notes_3: "ملاحظات 3",
  item_4: "البند 4", qty_4: "الكمية 4", value_4: "القيمة 4", status_4: "الحالة 4", notes_4: "ملاحظات 4",
  total_value: "إجمالي القيمة",
  service_days: "أيام الخدمة", service_months: "أشهر الخدمة", service_years: "سنوات الخدمة",
  end_date: "تاريخ النهاية",
    basic_salary: "الراتب الأساسي الشهري", 
    housing_allowance: "بدل السكن الشهري",
    salary_period_type: "نوع فترة الراتب",
    total_deduction: "إجمالي الخصم المستحق",
    transport_allowance: "بدل المواصلات",

  end_service_bonus: "مكافأة نهاية الخدمة", vacation_balance: "رصيد الإجازات", total_amount: "إجمالي المستحقات",
  payroll_period: "فترة الراتب",
  period_from: "من تاريخ",
  period_to: "إلى تاريخ",
  total_amount_text: "المبلغ كتابة",
  bank_name: "اسم البنك",
  account_number: "رقم الحساب",
  transfer_date: "تاريخ التحويل",
  due_date: "تاريخ الاستحقاق",
  actual_receipt_date: "تاريخ الاستلام الفعلي",
};

const convertAmountToWords = (amount: number): string => {
  if (isNaN(amount) || amount === 0) return "";
  const ones = ["", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة", "عشرة"];
  const teens = ["عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"];
  const tens = ["", "عشرة", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"];
  const hundreds = ["", "مائة", "مائتان", "ثلاثمائة", "أربعمائة", "خمسمائة", "ستمائة", "سبعمائة", "ثمانمائة", "تسمائة"];
  const processThreeDigits = (num: number): string => {
    let result = "";
    const h = Math.floor(num / 100);
    const rest = num % 100;
    if (h > 0) result += hundreds[h];
    if (rest > 0) {
      if (h > 0) result += " و ";
      if (rest <= 10) result += ones[rest];
      else if (rest < 20) result += teens[rest - 10];
      else {
        const t = Math.floor(rest / 10);
        const o = rest % 10;
        if (o > 0) result += ones[o] + " و ";
        result += tens[t];
      }
    }
    return result;
  };
  const thousands = Math.floor(amount / 1000);
  const rest = Math.floor(amount % 1000);
  let finalResult = "";
  if (thousands > 0) {
    if (thousands === 1) finalResult += "ألف";
    else if (thousands === 2) finalResult += "ألفان";
    else if (thousands >= 3 && thousands <= 10) finalResult += ones[thousands] + " آلاف";
    else finalResult += processThreeDigits(thousands) + " ألف";
  }
  if (rest > 0) {
    if (thousands > 0) finalResult += " و ";
    finalResult += processThreeDigits(rest);
  }
  return finalResult;
};

// ─────────────────────────────── LetterTypeBuilderModal ───────────────────────

function LetterTypeBuilderModal({
  onClose,
  onSave,
}: {
  onClose: () => void;
  onSave: (name: string, content: string, placeholders: string[], labels: Record<string, string>) => Promise<void>;
}) {
  const [templateName, setTemplateName] = useState("");
  const [templateText, setTemplateText] = useState("");
  const [customFields, setCustomFields] = useState<{ key: string; label: string }[]>([]);
  const [showFieldInput, setShowFieldInput] = useState(false);
  const [fieldLabel, setFieldLabel] = useState("");
  const [selectionInfo, setSelectionInfo] = useState<{ start: number; end: number } | null>(null);
  const [saving, setSaving] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fieldInputRef = useRef<HTMLInputElement>(null);

  const handleMarkSelection = () => {
    const textarea = textareaRef.current;
    if (!textarea) return;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selected = templateText.substring(start, end).trim();
    setSelectionInfo({ start: textarea.selectionStart, end: textarea.selectionEnd });
    setFieldLabel(selected || "");
    setShowFieldInput(true);
    setTimeout(() => fieldInputRef.current?.focus(), 50);
  };

  const confirmField = () => {
    const label = fieldLabel.trim();
    if (!label) return;
    const key = `f${customFields.length + 1}`;
    const marker = `«${label}»`;
    let newText = templateText;
    if (selectionInfo && selectionInfo.start !== selectionInfo.end) {
      newText =
        templateText.substring(0, selectionInfo.start) +
        marker +
        templateText.substring(selectionInfo.end);
    } else if (selectionInfo) {
      newText =
        templateText.substring(0, selectionInfo.start) +
        marker +
        templateText.substring(selectionInfo.start);
    } else {
      newText = templateText + marker;
    }
    setTemplateText(newText);
    setCustomFields((prev) => [...prev, { key, label }]);
    setFieldLabel("");
    setShowFieldInput(false);
    setSelectionInfo(null);
  };

  const removeField = (key: string) => {
    const field = customFields.find((f) => f.key === key);
    if (field) {
      setTemplateText((prev) => prev.replaceAll(`«${field.label}»`, field.label));
    }
    setCustomFields((prev) => prev.filter((f) => f.key !== key));
  };

  const handleSave = async () => {
    if (!templateName.trim()) { toast.error("يرجى إدخال اسم نوع الخطاب"); return; }
    if (!templateText.trim()) { toast.error("يرجى كتابة نص الخطاب"); return; }
    let finalContent = templateText;
    const labels: Record<string, string> = {};
    const placeholders: string[] = [];
    customFields.forEach(({ key, label }) => {
      finalContent = finalContent.replaceAll(`«${label}»`, `{${key}}`);
      labels[key] = label;
      placeholders.push(key);
    });
    // Wrap lines in <p> tags for HTML rendering
    finalContent = finalContent
      .split("\n")
      .map((line) => `<p>${line || "&nbsp;"}</p>`)
      .join("");
    setSaving(true);
    await onSave(templateName.trim(), finalContent, placeholders, labels);
    setSaving(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[70] flex items-center justify-center p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        initial={{ scale: 0.93, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.93, opacity: 0, y: 20 }}
        transition={{ type: "spring", damping: 26, stiffness: 300 }}
        className="relative bg-gradient-to-br from-slate-800/98 via-slate-800/95 to-slate-900/98 backdrop-blur-2xl rounded-[2rem] border border-white/10 shadow-2xl w-full max-w-3xl max-h-[92vh] overflow-hidden flex flex-col"
        dir="rtl"
      >
        {/* Top accent bar */}
        <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-violet-500 via-purple-500 to-pink-500" />

        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/[0.08] flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-br from-violet-500/20 to-purple-500/20 rounded-xl border border-violet-500/20">
              <PenLine className="w-5 h-5 text-violet-400" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white tracking-tight">إنشاء نوع خطاب جديد</h2>
              <p className="text-slate-400 text-xs">اكتب نص الخطاب وحدد الأجزاء التي تريدها حقول إدخال</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl transition-all">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">

          {/* Template name */}
          <div>
            <label className="block text-sm font-bold text-slate-300 mb-2 flex items-center gap-2">
              <Bookmark className="w-4 h-4 text-violet-400" />
              اسم نوع الخطاب
            </label>
            <input
              value={templateName}
              onChange={(e) => setTemplateName(e.target.value)}
              placeholder="مثال: خطاب تعريف بالموظف، خطاب إجازة، إشعار تحذير..."
              className="w-full bg-white/[0.06] border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-slate-600 focus:outline-none focus:border-violet-500/50 focus:bg-white/[0.08] transition-all"
            />
          </div>

          {/* Text area + mark button */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-bold text-slate-300 flex items-center gap-2">
                <FileText className="w-4 h-4 text-violet-400" />
                نص الخطاب
              </label>
              <button
                type="button"
                onClick={handleMarkSelection}
                className="flex items-center gap-2 px-4 py-2 bg-violet-500/15 hover:bg-violet-500/25 border border-violet-500/25 text-violet-300 rounded-xl text-xs font-black transition-all"
              >
                <Tag className="w-3.5 h-3.5" />
                تحديد النص المختار كحقل إدخال
              </button>
            </div>
            <div className="relative">
              <textarea
                ref={textareaRef}
                value={templateText}
                onChange={(e) => setTemplateText(e.target.value)}
                rows={12}
                placeholder={`اكتب نص الخطاب كاملاً هنا...\n\nمثال:\nسعادة مدير عام مؤسسة .......... المحترم\nالسلام عليكم ورحمة الله وبركاته\n\nنفيدكم بأن الموظف .......... يعمل لدينا بمسمى ..........`}
                className="w-full bg-white/[0.05] border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-slate-700 focus:outline-none focus:border-violet-500/40 transition-all resize-none leading-relaxed font-mono"
              />
              {/* Markers legend */}
              {customFields.length > 0 && (
                <div className="absolute bottom-3 left-3 right-3 pointer-events-none">
                  <div className="flex flex-wrap gap-1 justify-end">
                    {customFields.map((f) => (
                      <span key={f.key} className="text-[9px] bg-violet-500/20 text-violet-300 px-1.5 py-0.5 rounded border border-violet-500/20 font-mono">
                        «{f.label}»
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <p className="text-[11px] text-slate-600 mt-1.5">
              حدد جزءاً من النص ثم اضغط "تحديد كحقل إدخال" — أو ضع المؤشر وأضف حقلاً جديداً
            </p>
          </div>

          {/* Field label input popup */}
          <AnimatePresence>
            {showFieldInput && (
              <motion.div
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                className="bg-violet-500/10 border border-violet-500/25 rounded-2xl p-4 space-y-3"
              >
                <p className="text-sm font-bold text-violet-300 flex items-center gap-2">
                  <Wand2 className="w-4 h-4" />
                  ما اسم هذا الحقل؟
                </p>
                <div className="flex gap-2">
                  <input
                    ref={fieldInputRef}
                    value={fieldLabel}
                    onChange={(e) => setFieldLabel(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") confirmField(); if (e.key === "Escape") { setShowFieldInput(false); setFieldLabel(""); } }}
                    placeholder="مثال: اسم المدير العام، رقم العقد، تاريخ البداية..."
                    className="flex-1 bg-white/[0.07] border border-violet-500/30 rounded-xl px-3 py-2 text-white text-sm placeholder-slate-600 focus:outline-none focus:border-violet-400"
                  />
                  <button
                    type="button"
                    onClick={confirmField}
                    disabled={!fieldLabel.trim()}
                    className="px-4 py-2 bg-violet-500 hover:bg-violet-600 disabled:opacity-40 text-white rounded-xl text-sm font-black transition-all"
                  >
                    إضافة
                  </button>
                  <button
                    type="button"
                    onClick={() => { setShowFieldInput(false); setFieldLabel(""); }}
                    className="px-3 py-2 bg-white/5 hover:bg-white/10 text-slate-400 rounded-xl text-sm transition-all"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Defined fields list */}
          {customFields.length > 0 && (
            <div>
              <p className="text-sm font-bold text-slate-300 mb-3 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                حقول الإدخال المعرفة ({customFields.length})
              </p>
              <div className="flex flex-wrap gap-2">
                {customFields.map((f) => (
                  <div key={f.key} className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 rounded-xl px-3 py-1.5">
                    <Tag className="w-3 h-3 text-emerald-400" />
                    <span className="text-sm text-emerald-300 font-bold">{f.label}</span>
                    <button
                      type="button"
                      onClick={() => removeField(f.key)}
                      className="text-slate-500 hover:text-red-400 transition-colors"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center gap-3 p-6 border-t border-white/[0.08] flex-shrink-0">
          <button
            type="button"
            onClick={handleSave}
            disabled={saving || !templateName.trim() || !templateText.trim()}
            className="flex-1 py-3 bg-gradient-to-r from-violet-500 to-purple-600 text-white font-black rounded-xl hover:opacity-90 transition-all disabled:opacity-40 flex items-center justify-center gap-2 shadow-lg shadow-violet-500/20"
          >
            {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle className="w-5 h-5" />}
            {saving ? "جاري الحفظ..." : "حفظ نوع الخطاب"}
          </button>
          <button type="button" onClick={onClose} className="px-6 py-3 bg-white/5 hover:bg-white/10 text-slate-400 rounded-xl font-bold transition-all">
            إلغاء
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ──────────────────────────────────────────────────────────────────────────────

export default function LettersClient() {
  const t = useTranslations("officialLettersPage");
  const { locale, isRTL } = useLocale();
  const [templates, setTemplates] = useState<LetterTemplate[]>([]);
  const [letters, setLetters] = useState<GeneratedLetter[]>([]);
  const [loading, setLoading] = useState(true);
  const [companyInfo, setCompanyInfo] = useState<CompanyInfo | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [margins, setMargins] = useState({ top: 100, bottom: 100 });
  const [hasUnsavedMargins, setHasUnsavedMargins] = useState(false);

  const [showTypeBuilder, setShowTypeBuilder] = useState(false);

  const [showForm, setShowForm] = useState(false);
  const [showTemplateSelectModal, setShowTemplateSelectModal] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<LetterTemplate | null>(null);
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [editingLetter, setEditingLetter] = useState<GeneratedLetter | null>(null);

  const [showPreview, setShowPreview] = useState(false);
  const [previewLetter, setPreviewLetter] = useState<GeneratedLetter | null>(null);
  const printRef = useRef<HTMLDivElement>(null);
  const pdfCanvasRef = useRef<HTMLCanvasElement>(null);
  const [pdfRendered, setPdfRendered] = useState(false);

  const [showEmailModal, setShowEmailModal] = useState(false);
  const [emailLetter, setEmailLetter] = useState<GeneratedLetter | null>(null);
  const [customEmail, setCustomEmail] = useState("");
  const [isSendingEmail, setIsSendingEmail] = useState(false);

  // Luxury modal states
  const [saveConfirmModal, setSaveConfirmModal] = useState(false);
  const [savingModal, setSavingModal] = useState(false);
  const [saveSuccessModal, setSaveSuccessModal] = useState<{ isOpen: boolean; letterNumber: string }>({ isOpen: false, letterNumber: '' });
  const [saveErrorModal, setSaveErrorModal] = useState<{ isOpen: boolean; message: string }>({ isOpen: false, message: '' });
  
  const [deleteConfirmModal, setDeleteConfirmModal] = useState<{ isOpen: boolean; item: GeneratedLetter | null }>({ isOpen: false, item: null });
  const [deletingModal, setDeletingModal] = useState(false);
  const [deleteSuccessModal, setDeleteSuccessModal] = useState<{ isOpen: boolean; title: string }>({ isOpen: false, title: '' });

  const placeholderLabels = useMemo(() => ({
    employee_name: t("placeholders.employee_name"),
    id_number: t("placeholders.id_number"),
    company_name: t("placeholders.company_name"),
    commercial_number: t("placeholders.commercial_number"),
    start_date: t("placeholders.start_date"),
    job_title: t("placeholders.job_title"),
    profession: t("placeholders.profession"),
    nationality: t("placeholders.nationality"),
    resignation_day: t("placeholders.resignation_day"),
    resignation_date: t("placeholders.resignation_date"),
    resignation_reason: t("placeholders.resignation_reason"),
    receipt_date: t("placeholders.receipt_date"),
    item_1: t("placeholders.item", { n: 1 }), qty_1: t("placeholders.qty", { n: 1 }), value_1: t("placeholders.value", { n: 1 }), status_1: t("placeholders.status", { n: 1 }), notes_1: t("placeholders.notes", { n: 1 }),
    item_2: t("placeholders.item", { n: 2 }), qty_2: t("placeholders.qty", { n: 2 }), value_2: t("placeholders.value", { n: 2 }), status_2: t("placeholders.status", { n: 2 }), notes_2: t("placeholders.notes", { n: 2 }),
    item_3: t("placeholders.item", { n: 3 }), qty_3: t("placeholders.qty", { n: 3 }), value_3: t("placeholders.value", { n: 3 }), status_3: t("placeholders.status", { n: 3 }), notes_3: t("placeholders.notes", { n: 3 }),
    item_4: t("placeholders.item", { n: 4 }), qty_4: t("placeholders.qty", { n: 4 }), value_4: t("placeholders.value", { n: 4 }), status_4: t("placeholders.status", { n: 4 }), notes_4: t("placeholders.notes", { n: 4 }),
    total_value: t("placeholders.total_value"),
    service_days: t("placeholders.service_days"), service_months: t("placeholders.service_months"), service_years: t("placeholders.service_years"),
    end_date: t("placeholders.end_date"),
    basic_salary: t("placeholders.basic_salary"), 
    housing_allowance: t("placeholders.housing_allowance"),
    salary_period_type: t("placeholders.salary_period_type"),
    total_deduction: t("placeholders.total_deduction"),
    transport_allowance: t("placeholders.transport_allowance"),
    end_service_bonus: t("placeholders.end_service_bonus"), vacation_balance: t("placeholders.vacation_balance"), total_amount: t("placeholders.total_amount"),
    payroll_period: t("placeholders.payroll_period"),
    period_from: t("placeholders.period_from"),
    period_to: t("placeholders.period_to"),
    total_amount_text: t("placeholders.total_amount_text"),
    bank_name: t("placeholders.bank_name"),
    account_number: t("placeholders.account_number"),
    transfer_date: t("placeholders.transfer_date"),
    due_date: t("placeholders.due_date"),
    actual_receipt_date: t("placeholders.actual_receipt_date"),
  }), [t]);

  const renderPdfToCanvas = useCallback(async (pdfUrl: string, canvas: HTMLCanvasElement | null) => {
    if (!canvas || !pdfUrl) return;
    try {
      const loadingTask = pdfjsLib.getDocument(pdfUrl);
      const pdf = await loadingTask.promise;
      const page = await pdf.getPage(1);
      const desiredWidth = 200;
      const unscaledViewport = page.getViewport({ scale: 1 });
      const scale = desiredWidth / unscaledViewport.width;
      const viewport = page.getViewport({ scale });
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      const context = canvas.getContext("2d");
      if (context) {
        await page.render({ canvasContext: context, viewport }).promise;
        setPdfRendered(true);
      }
    } catch (error) {
      console.error("Error rendering PDF:", error);
    }
  }, []);

  useEffect(() => {
    if (showSettings && companyInfo?.letterhead_path?.toLowerCase().endsWith('.pdf')) {
      setPdfRendered(false);
      setTimeout(() => {
        renderPdfToCanvas(companyInfo.letterhead_path!, pdfCanvasRef.current);
      }, 100);
    }
  }, [showSettings, companyInfo?.letterhead_path, renderPdfToCanvas]);

  const calculateMonths = (from: string, to: string): number => {
    if (!from || !to) return 1;
    const startDate = new Date(from);
    const endDate = new Date(to);
    if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) return 1;
    
    let months = (endDate.getFullYear() - startDate.getFullYear()) * 12;
    months -= startDate.getMonth();
    months += endDate.getMonth();
    
    return Math.max(1, months + 1);
  };

  useEffect(() => {
    if (selectedTemplate?.template_key === "salary_receipt" || selectedTemplate?.template_key === "final_clearance") {
      const basic = parseFloat(formData.basic_salary || "0");
      const housing = parseFloat(formData.housing_allowance || "0");
      const transport = parseFloat(formData.transport_allowance || "0");
      const bonus = parseFloat(formData.end_service_bonus || "0");
      const vacation = parseFloat(formData.vacation_balance || "0");
      const deduction = parseFloat(formData.total_deduction || "0");
      
      let months = 1;
      if (selectedTemplate?.template_key === "salary_receipt") {
        months = calculateMonths(formData.period_from, formData.period_to);
      }
      
      const subtotal = (basic + housing + transport) * months + bonus + vacation;
      const total = Math.max(0, subtotal - deduction);
      
      if (total.toString() !== formData.total_amount) {
        setFormData(prev => ({
          ...prev,
          total_amount: total.toString(),
          total_amount_text: convertAmountToWords(Math.floor(total))
        }));
      }
    }
  }, [formData.basic_salary, formData.housing_allowance, formData.transport_allowance, formData.end_service_bonus, formData.vacation_balance, formData.total_deduction, formData.period_from, formData.period_to, selectedTemplate]);

  const fetchData = async () => {
    try {
      const [lettersRes, companyRes] = await Promise.all([
        fetch("/api/letters"),
        fetch("/api/company-info")
      ]);
      const lettersData = await lettersRes.json();
      const companyData = await companyRes.json();
      if (lettersData.success) {
        setTemplates(lettersData.templates || []);
        setLetters(lettersData.letters || []);
      }
      if (companyData.company) {
        setCompanyInfo(companyData.company);
        setMargins({
          top: companyData.company.letterhead_top_margin || 100,
          bottom: companyData.company.letterhead_bottom_margin || 100
        });
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      toast.error(t("messages.fetchError"));
    } finally {
      setLoading(false);
    }
  };

    const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      setIsUploading(true);
      const uploadFormData = new FormData();
      uploadFormData.append("file", file);
      uploadFormData.append("bucket", "letterheads");
      try {
        const res = await fetch("/api/upload", { method: "POST", body: uploadFormData });
        const data = await res.json();
        if (data.url) {
          const success = await updateCompanySettings({ letterhead_path: data.url });
          if (success) {
            toast.success(t("messages.uploadSuccess"));
            fetchData();
          } else {
            toast.error(t("messages.dbSaveError"));
          }
        } else {
          toast.error(data.error || t("messages.uploadError"));
        }
      } catch (error) {
        console.error("Upload error:", error);
        toast.error(t("messages.uploadError"));
      } finally {
        setIsUploading(false);
      }
    };

  const updateCompanySettings = async (updates: Partial<CompanyInfo>) => {
    try {
      const res = await fetch("/api/company-info", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
      const data = await res.json();
        if (data.success) {
          setCompanyInfo(prev => ({ ...(prev || {}), ...updates } as CompanyInfo));
          return true;
        }

    } catch (error) {
      console.error("Update settings error:", error);
      toast.error(t("messages.updateSettingsError"));
    }
    return false;
  };

  useEffect(() => {
    fetchData();
  }, []);

  const openCreateForm = (template: LetterTemplate) => {
    setSelectedTemplate(template);
    setEditingLetter(null);
    const initialData: Record<string, string> = {};
    const placeholders = typeof template.placeholders === 'string' 
      ? JSON.parse(template.placeholders) 
      : template.placeholders;
    placeholders.forEach((p: string) => {
      if (p === "company_name" && companyInfo) initialData[p] = companyInfo.name;
      else if (p === "commercial_number" && companyInfo) initialData[p] = companyInfo.commercial_number;
      else initialData[p] = "";
    });
    setFormData(initialData);
    setShowForm(true);
  };

  const openEditForm = (letter: GeneratedLetter) => {
    const template = templates.find(t => t.id === letter.template_id);
    if (!template) return;
    setSelectedTemplate(template);
    setEditingLetter(letter);
    const letterData = typeof letter.letter_data === 'string' ? JSON.parse(letter.letter_data) : letter.letter_data;
    setFormData(letterData);
    setShowForm(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTemplate) return;
    setSaveConfirmModal(true);
  };

  const confirmSave = async () => {
    if (!selectedTemplate) return;
    setSaveConfirmModal(false);
    setSavingModal(true);
    try {
      const payload = editingLetter 
        ? { id: editingLetter.id, letter_data: formData, status: "active" }
        : { template_id: selectedTemplate.id, letter_data: formData };
      const res = await fetch("/api/letters", {
        method: editingLetter ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      setSavingModal(false);
      if (data.success) {
        setSaveSuccessModal({ isOpen: true, letterNumber: data.letter_number || editingLetter?.letter_number || '' });
        fetchData();
        resetForm();
      } else {
        setSaveErrorModal({ isOpen: true, message: data.error || t("common.error") });
      }
    } catch (error) {
      console.error("Error saving letter:", error);
      setSavingModal(false);
      setSaveErrorModal({ isOpen: true, message: t("common.error") });
    }
  };

  const handleDeleteClick = (letter: GeneratedLetter) => {
    setDeleteConfirmModal({ isOpen: true, item: letter });
  };

  const confirmDelete = async () => {
    const item = deleteConfirmModal.item;
    if (!item) return;
    setDeleteConfirmModal({ isOpen: false, item: null });
    setDeletingModal(true);
    try {
      const res = await fetch(`/api/letters?id=${item.id}`, { method: "DELETE" });
      const data = await res.json();
      setDeletingModal(false);
      if (data.success) {
        setDeleteSuccessModal({ isOpen: true, title: item.letter_number });
        fetchData();
      } else {
        toast.error(data.error || t("common.error"));
      }
    } catch (error) {
      console.error("Error deleting letter:", error);
      setDeletingModal(false);
      toast.error(t("common.error"));
    }
  };

  const resetForm = () => {
    setShowForm(false);
    setSelectedTemplate(null);
    setEditingLetter(null);
    setFormData({});
  };

  const openPreview = (letter: GeneratedLetter) => {
    setPreviewLetter(letter);
    setShowPreview(true);
  };

  const generateLetterContent = (letter: GeneratedLetter): string => {
    const template = templates.find(t => t.id === letter.template_id);
    if (!template) return "";
    let content = template.template_content;
    const letterData = typeof letter.letter_data === 'string' ? JSON.parse(letter.letter_data) : letter.letter_data;
    Object.entries(letterData).forEach(([key, value]) => {
      const regex = new RegExp(`\\{${key}\\}`, 'g');
      content = content.replace(regex, value as string || "..................");
    });
    return content;
  };

    const convertPdfToImage = async (pdfUrl: string): Promise<string> => {
      try {
        const loadingTask = pdfjsLib.getDocument(pdfUrl);
        const pdf = await loadingTask.promise;
        const page = await pdf.getPage(1);
        const scale = 3;
        const viewport = page.getViewport({ scale });
        const canvas = document.createElement('canvas');
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) throw new Error('no canvas context');
        await page.render({ canvasContext: ctx, viewport }).promise;
        return canvas.toDataURL('image/png');
      } catch (e) {
        console.error('PDF to image error:', e);
        return '';
      }
    };

    const buildPrintHTML = (content: string, forPrint: boolean = true, letterheadImageDataUrl?: string): string => {
        const letterhead = companyInfo?.letterhead_path;
        const topMargin = margins.top;
        const bottomMargin = margins.bottom;
        const isPdf = letterhead?.toLowerCase().endsWith('.pdf');
        const bgImage = letterheadImageDataUrl || (!isPdf ? letterhead : '') || '';
      
      return `<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <title>طباعة الخطاب</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
      * { margin: 0; padding: 0; box-sizing: border-box; }
      body { 
        font-family: 'Tajawal', 'Arial', 'Tahoma', sans-serif; 
        direction: rtl; 
        background: #fff; 
        color: #000; 
        line-height: 1.6;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
      }
      @page { size: A4; margin: 0; }
      .page-container { 
        width: 210mm; 
        min-height: 297mm; 
        position: relative; 
        margin: 0 auto;
      }
      .letterhead-bg { 
        position: absolute; 
        top: 0; left: 0; 
        width: 100%; height: 297mm; 
        object-fit: fill; 
        z-index: 0; 
      }
      .letter-content-wrapper { 
        position: relative;
        z-index: 1; 
        padding-top: ${topMargin}px; 
        padding-bottom: ${bottomMargin}px; 
        padding-left: 50px; 
        padding-right: 50px; 
      }
      .letter-content { 
        font-size: 15px; 
        text-align: justify; 
        line-height: 1.7;
        color: #000;
      }
      .letter-content p { margin-bottom: 10px; }
      .field { font-weight: bold; color: #000; }
      h2 { font-size: 20px; margin-bottom: 12px; text-align: center; }
      table { width: 100%; border-collapse: collapse; margin: 8px 0; }
      td, th { padding: 6px 8px; border: 1px solid #000; font-size: 13px; text-align: center; }
      th { background: #f0f0f0; font-weight: bold; }
      @media print { 
        body { margin: 0; }
        .page-container { width: 100%; min-height: 100%; margin: 0; box-shadow: none; }
      }
    </style>
</head>
<body>
    <div class="page-container">
      ${bgImage ? `<img src="${bgImage}" class="letterhead-bg" crossorigin="anonymous" />` : ''}
      <div class="letter-content-wrapper">
        <div class="letter-content">${content}</div>
      </div>
    </div>
  ${forPrint ? `<script>
    function waitAndPrint() {
      var imgs = document.querySelectorAll('img');
      var promises = [];
      for (var i = 0; i < imgs.length; i++) {
        if (!imgs[i].complete) {
          promises.push(new Promise(function(resolve) { 
            imgs[i].onload = resolve; 
            imgs[i].onerror = resolve; 
          }));
        }
      }
      if (promises.length > 0) {
        Promise.all(promises).then(function() { setTimeout(function(){ window.print(); }, 300); });
      } else {
        window.print();
      }
    }
    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(function() { setTimeout(waitAndPrint, 300); });
    } else {
      setTimeout(waitAndPrint, 1500);
    }
  </script>` : ''}
</body>
</html>`;
    };

    const handlePrint = async () => {
        if (!previewLetter) return;
        const content = generateLetterContent(previewLetter);
        if (!content) { toast.error("لا يوجد محتوى للطباعة"); return; }
        
        let letterheadImg = '';
        if (companyInfo?.letterhead_path?.toLowerCase().endsWith('.pdf')) {
          letterheadImg = await convertPdfToImage(companyInfo.letterhead_path);
        }
        
        const printWindow = window.open("", "_blank");
        if (!printWindow) { toast.error("يرجى السماح بالنوافذ المنبثقة"); return; }
        printWindow.document.write(buildPrintHTML(content, true, letterheadImg));
        printWindow.document.close();
      };

    const handleDownloadPdf = async () => {
      if (!previewLetter) return;
      const content = generateLetterContent(previewLetter);
      if (!content) { toast.error("لا يوجد محتوى للتحميل"); return; }
      
      try {
        toast.info("جاري تجهيز ملف PDF...");
        
        let letterheadImg = '';
        if (companyInfo?.letterhead_path?.toLowerCase().endsWith('.pdf')) {
          letterheadImg = await convertPdfToImage(companyInfo.letterhead_path);
        }
        
        const html2canvas = (await import('html2canvas')).default;
        const { jsPDF } = await import('jspdf');

        const iframe = document.createElement('iframe');
        iframe.style.cssText = 'position:fixed;left:-9999px;top:0;width:794px;height:1123px;border:none;';
        document.body.appendChild(iframe);

        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
        if (!iframeDoc) throw new Error('iframe error');

          iframeDoc.open();
          iframeDoc.write(buildPrintHTML(content, false, letterheadImg));
          iframeDoc.close();

          // Wait for fonts and images to load
          await new Promise(resolve => setTimeout(resolve, 500));
          const imgs = iframeDoc.querySelectorAll('img');
          if (imgs.length > 0) {
            await Promise.all(Array.from(imgs).map(img => 
              img.complete ? Promise.resolve() : new Promise(r => { img.onload = r; img.onerror = r; })
            ));
          }
          await new Promise(resolve => setTimeout(resolve, 500));

          const pageEl = iframeDoc.querySelector('.page-container') as HTMLElement;
        if (!pageEl) throw new Error('no content');

        const canvas = await html2canvas(pageEl, {
          scale: 2,
          useCORS: true,
          allowTaint: true,
          width: 794,
          height: 1123,
          backgroundColor: '#ffffff',
        });

        document.body.removeChild(iframe);

        const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
        const imgData = canvas.toDataURL('image/png');
        pdf.addImage(imgData, 'PNG', 0, 0, 210, 297);
        pdf.save(`${previewLetter.letter_number}.pdf`);
        toast.success("تم تحميل الملف بنجاح");
      } catch (error) {
        console.error("PDF error:", error);
        toast.error("حدث خطأ أثناء إنشاء ملف PDF");
      }
    };

  const openEmailModal = (letter: GeneratedLetter) => {
    setEmailLetter(letter);
    setCustomEmail("");
    setShowEmailModal(true);
  };

  const generatePdfBase64 = async (letter: GeneratedLetter): Promise<string> => {
    const content = generateLetterContent(letter);

    let letterheadImg = '';
    if (companyInfo?.letterhead_path?.toLowerCase().endsWith('.pdf')) {
      letterheadImg = await convertPdfToImage(companyInfo.letterhead_path);
    }

    const html = buildPrintHTML(content, false, letterheadImg);

    const { jsPDF } = await import('jspdf');
    const html2canvas = (await import('html2canvas')).default;
    
    const iframe = document.createElement('iframe');
    iframe.style.cssText = 'position:fixed;left:-9999px;top:0;width:794px;height:1123px;border:none;';
    document.body.appendChild(iframe);
    
    const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
    if (!iframeDoc) throw new Error('Could not access iframe document');
    
    iframeDoc.open();
    iframeDoc.write(html);
    iframeDoc.close();
    
    await new Promise(resolve => setTimeout(resolve, 500));
    const imgs = iframeDoc.querySelectorAll('img');
    if (imgs.length > 0) {
      await Promise.all(Array.from(imgs).map(img => 
        img.complete ? Promise.resolve() : new Promise(r => { img.onload = r; img.onerror = r; })
      ));
    }
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const pageEl = iframeDoc.querySelector('.page-container') as HTMLElement;
    if (!pageEl) throw new Error('no content');

    const canvas = await html2canvas(pageEl, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      width: 794,
      height: 1123,
      backgroundColor: '#ffffff',
    });
    
    document.body.removeChild(iframe);
    
    const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const imgData = canvas.toDataURL('image/png');
    pdf.addImage(imgData, 'PNG', 0, 0, 210, 297);
    
    return pdf.output('datauristring').split(',')[1];
  };

  const handleSendEmail = async (toCompanyEmail: boolean) => {
    if (!emailLetter) return;
    
    const recipientEmail = toCompanyEmail ? companyInfo?.email : customEmail;
    
    if (!recipientEmail) {
      toast.error(toCompanyEmail ? t("email.noCompanyEmail") : t("messages.enterEmail"));
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(recipientEmail)) {
      toast.error(t("messages.invalidEmail"));
      return;
    }

    setIsSendingEmail(true);
    
    try {
      const pdfBase64 = await generatePdfBase64(emailLetter);
      
      const res = await fetch("/api/letters/send-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recipientEmail,
          letterNumber: emailLetter.letter_number,
          letterType: t(`templates.${emailLetter.template_key}`),
          pdfBase64
        })
      });

      const data = await res.json();
      
      if (data.success) {
        toast.success(t("messages.emailSendSuccess", { email: recipientEmail }));
        setShowEmailModal(false);
        setEmailLetter(null);
        setCustomEmail("");
      } else {
        toast.error(data.error || t("messages.emailSendError"));
      }
    } catch (error) {
      console.error("Error sending email:", error);
      toast.error(t("messages.emailSendError"));
    } finally {
      setIsSendingEmail(false);
    }
  };

    const filteredLetters = letters.filter(letter =>
    letter.letter_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t(`templates.${letter.template_key}`).includes(searchTerm)
  );


  const getPlaceholders = (template: LetterTemplate): string[] => {
    let placeholders = typeof template.placeholders === 'string' ? JSON.parse(template.placeholders) : template.placeholders;
    if (template.template_key === "salary_receipt") {
      const essential = ["salary_period_type", "total_deduction"];
      essential.forEach(field => {
        if (!placeholders.includes(field)) {
          placeholders.push(field);
        }
      });
    }
    return placeholders;
  };

  const getFieldLabel = (placeholder: string, template: LetterTemplate): string => {
    if (template.placeholder_labels) {
      const labels: Record<string, string> =
        typeof template.placeholder_labels === "string"
          ? JSON.parse(template.placeholder_labels)
          : template.placeholder_labels;
      if (labels[placeholder]) return labels[placeholder];
    }
    return (placeholderLabels as any)[placeholder] || placeholder;
  };

  const getTemplateName = (template: LetterTemplate): string =>
    template.is_system_template
      ? t(`templates.${template.template_key}`)
      : template.template_name_ar || template.template_name;

  const handleSaveCustomTemplate = async (
    name: string,
    content: string,
    placeholderArr: string[],
    labels: Record<string, string>
  ) => {
    try {
      const res = await fetch("/api/letters/templates", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          template_name: name,
          template_content: content,
          placeholders: placeholderArr,
          placeholder_labels: labels,
        }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success(`تم حفظ نوع الخطاب "${name}" بنجاح`);
        setShowTypeBuilder(false);
        fetchData();
      } else {
        toast.error(data.error || "حدث خطأ أثناء الحفظ");
      }
    } catch {
      toast.error("حدث خطأ غير متوقع");
    }
  };

  const handleDeleteCustomTemplate = async (id: number, name: string) => {
    if (!confirm(`هل تريد حذف نوع الخطاب "${name}"؟ سيتم حذفه نهائياً.`)) return;
    try {
      const res = await fetch(`/api/letters/templates?id=${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        toast.success("تم حذف نوع الخطاب");
        fetchData();
      } else {
        toast.error(data.error || "حدث خطأ");
      }
    } catch {
      toast.error("حدث خطأ");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-blue-900 p-4 md:p-8" dir={locale === 'ar' ? 'rtl' : 'ltr'}>
        <div className="w-[95%] mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 rounded-3xl p-8 mb-8 shadow-2xl relative overflow-hidden"
          >
            {/* Decorative elements */}
            <div className="absolute inset-0 overflow-hidden">
              <div className="absolute -top-20 -right-20 w-60 h-60 bg-white/5 rounded-full blur-3xl" />
              <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-purple-500/10 rounded-full blur-3xl" />
            </div>
            <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6">
              <div className={`text-center ${locale === 'ar' ? 'md:text-right' : 'md:text-left'}`}>
                <h1 className="text-3xl md:text-4xl font-black text-white mb-2 flex items-center gap-3 tracking-tight">
                  <div className="p-3 bg-white/15 backdrop-blur-sm rounded-2xl border border-white/20">
                    <FileText className="w-8 h-8" />
                  </div>
                  {t("title")}
                </h1>
                <p className="text-blue-100/80 text-lg">{t("subtitle")}</p>
              </div>
              <div className="flex items-center gap-3 flex-wrap justify-center md:justify-end">
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => setShowTypeBuilder(true)}
                  className="flex items-center gap-2 px-5 py-2.5 bg-white/15 hover:bg-white/25 backdrop-blur-sm border border-white/25 text-white rounded-2xl text-sm font-black transition-all shadow-lg"
                >
                  <PenLine className="w-4 h-4" />
                  إنشاء نوع خطاب جديد
                </motion.button>
                <button
                  onClick={() => setShowSettings(true)}
                  className="bg-white/15 hover:bg-white/25 backdrop-blur-sm text-white shadow-lg rounded-2xl p-3 transition-all flex items-center gap-2 border border-white/20"
                  title={t("paperSettings")}
                >
                  <Settings className="w-5 h-5" />
                  <span className="hidden sm:inline font-bold">{t("paperSettings")}</span>
                </button>
                {companyInfo && (
                  <div className="bg-white/15 backdrop-blur-sm rounded-2xl px-5 py-3 text-white border border-white/20 font-bold">
                    <Building2 className={`w-5 h-5 inline-block ${locale === 'ar' ? 'ml-2' : 'mr-2'}`} />
                    {companyInfo.name}
                  </div>
                )}
              </div>
            </div>
          </motion.div>

          {/* Luxury Create New Letter Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            className="mb-8"
          >
            <motion.button
              whileHover={{ scale: 1.01, y: -2 }}
              whileTap={{ scale: 0.99 }}
              onClick={() => {
                if (templates.length > 0) {
                  setShowTemplateSelectModal(true);
                }
              }}
              className="w-full group relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-600 via-indigo-500 to-purple-600 p-[2px] shadow-2xl shadow-blue-500/20 hover:shadow-blue-500/40 transition-all"
            >
              <div className="relative bg-gradient-to-r from-blue-600/90 via-indigo-500/90 to-purple-600/90 backdrop-blur-xl rounded-[22px] px-8 py-6 flex items-center justify-center gap-4 overflow-hidden">
                {/* Animated background shimmer */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                <div className="absolute inset-0 overflow-hidden">
                  <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/5 rounded-full blur-2xl" />
                  <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-purple-400/10 rounded-full blur-2xl" />
                </div>
                <div className="relative z-10 flex items-center gap-4">
                  <div className="p-4 bg-white/20 backdrop-blur-sm rounded-2xl border border-white/30 shadow-lg">
                    <Plus className="w-7 h-7 text-white" strokeWidth={3} />
                  </div>
                  <div className={`${locale === 'ar' ? 'text-right' : 'text-left'}`}>
                    <span className="text-white font-black text-2xl block tracking-tight">{t("newLetterTitle")}</span>
                    <span className="text-white/70 text-sm font-medium">{t("subtitle")}</span>
                  </div>
                </div>
                <div className="relative z-10">
                  <Sparkles className="w-6 h-6 text-yellow-300 opacity-70" />
                </div>
              </div>
            </motion.button>
          </motion.div>

          {/* Templates Section - Own Card */}
          <motion.div
            id="templates-section"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-8"
          >
            <div className="relative bg-gradient-to-br from-slate-800/80 via-slate-800/60 to-slate-900/80 backdrop-blur-2xl rounded-[2rem] border border-white/10 overflow-hidden shadow-2xl">
              {/* Card decorative top border */}
              <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500" />
              {/* Decorative glow */}
              <div className="absolute -top-20 -right-20 w-60 h-60 bg-blue-500/5 rounded-full blur-3xl" />
              <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-indigo-500/5 rounded-full blur-3xl" />

              <div className="relative z-10 p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className="p-2.5 bg-gradient-to-br from-blue-500/20 to-indigo-500/20 rounded-xl border border-blue-500/20">
                    <FileSignature className="w-6 h-6 text-blue-400" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-black text-white tracking-tight">{t("newLetterTitle")}</h2>
                    <p className="text-slate-400 text-sm">اختر نوع الخطاب لإنشائه</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
                  {templates.map((template, idx) => {
                    const Icon = templateIcons[template.template_key] || (template.is_system_template ? FileText : PenLine);
                    const colorClass = templateColors[template.template_key] || (template.is_system_template ? "from-gray-500 to-gray-600" : "from-violet-600 to-purple-700");
                    const isCustom = !template.is_system_template;
                    return (
                      <div key={template.id} className="relative group">
                        <motion.button
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.1 + idx * 0.05 }}
                          whileHover={{ scale: 1.03, y: -5 }}
                          whileTap={{ scale: 0.97 }}
                          onClick={() => openCreateForm(template)}
                          className={`w-full bg-gradient-to-br ${colorClass} p-6 rounded-2xl text-white ${locale === 'ar' ? 'text-right' : 'text-left'} shadow-xl hover:shadow-2xl transition-all overflow-hidden`}
                        >
                          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
                          <div className="relative z-10">
                            <div className="flex items-start justify-between mb-4">
                              <div className="p-3 bg-white/20 backdrop-blur-sm rounded-xl border border-white/20 shadow-lg">
                                <Icon className="w-6 h-6" />
                              </div>
                              <div className="flex items-center gap-1">
                                {isCustom && (
                                  <span className="text-[9px] bg-white/20 text-white/80 px-1.5 py-0.5 rounded-full font-bold">مخصص</span>
                                )}
                                <motion.div whileHover={{ x: locale === 'ar' ? -5 : 5 }}>
                                  {locale === 'ar' ? <ChevronLeft className="w-5 h-5 opacity-50" /> : <ChevronLeft className="w-5 h-5 opacity-50 rotate-180" />}
                                </motion.div>
                              </div>
                            </div>
                            <h3 className="font-bold text-base mb-1 leading-tight">{getTemplateName(template)}</h3>
                            <p className="text-sm text-white/60">{t("fieldsToFill", { count: getPlaceholders(template).length })}</p>
                          </div>
                        </motion.button>
                        {/* Delete button for custom templates */}
                        {isCustom && (
                          <button
                            onClick={(e) => { e.stopPropagation(); handleDeleteCustomTemplate(template.id, getTemplateName(template)); }}
                            className="absolute top-2 left-2 p-1.5 bg-red-500/20 hover:bg-red-500/40 text-red-300 rounded-lg opacity-0 group-hover:opacity-100 transition-all z-10"
                            title="حذف هذا النوع"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Created Letters Section - Own Luxury Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="relative bg-gradient-to-br from-slate-800/80 via-slate-800/60 to-slate-900/80 backdrop-blur-2xl rounded-[2rem] border border-white/10 overflow-hidden shadow-2xl">
              {/* Card decorative top border */}
              <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-emerald-500 via-blue-500 to-purple-500" />
              {/* Decorative glow */}
              <div className="absolute -top-20 -right-20 w-60 h-60 bg-emerald-500/5 rounded-full blur-3xl" />
              <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-blue-500/5 rounded-full blur-3xl" />

              <div className="relative z-10 p-8">
                {/* Section header */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-gradient-to-br from-emerald-500/20 to-blue-500/20 rounded-xl border border-emerald-500/20">
                      <ClipboardList className="w-6 h-6 text-emerald-400" />
                    </div>
                    <div>
                      <h2 className="text-2xl font-black text-white tracking-tight">{t("createdLettersTitle", { count: filteredLetters.length })}</h2>
                      <p className="text-slate-400 text-sm">الخطابات الرسمية المنشأة مسبقاً</p>
                    </div>
                  </div>
                  {/* Search inside the card */}
                  <div className="relative w-full md:w-80">
                    <Search className={`absolute ${locale === 'ar' ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5`} />
                    <input
                      type="text"
                      placeholder={t("searchPlaceholder")}
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className={`w-full bg-white/5 border border-white/10 rounded-xl py-3 ${locale === 'ar' ? 'pr-12 pl-4' : 'pl-12 pr-4'} text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all`}
                    />
                  </div>
                </div>

                {filteredLetters.length === 0 ? (
                  <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-12 text-center border border-white/5">
                    <div className="p-5 bg-slate-700/30 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                      <FileText className="w-10 h-10 text-slate-500" />
                    </div>
                    <h3 className="text-xl text-white font-bold mb-2">{t("noLetters")}</h3>
                    <p className="text-slate-400">{t("noLettersDesc")}</p>
                  </div>
                ) : (
                  <div className="grid gap-3">
                    {filteredLetters.map((letter, index) => {
                      const Icon = templateIcons[letter.template_key] || FileText;
                      const colorClass = templateColors[letter.template_key] || "from-gray-500 to-gray-600";
                      return (
                        <motion.div
                          key={letter.id}
                          initial={{ opacity: 0, x: locale === 'ar' ? 30 : -30 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.04 }}
                          whileHover={{ x: locale === 'ar' ? -4 : 4 }}
                          className="group relative bg-gradient-to-r from-white/[0.07] to-white/[0.03] backdrop-blur-sm rounded-2xl p-5 border border-white/[0.08] hover:border-blue-500/30 transition-all hover:shadow-lg hover:shadow-blue-500/5"
                        >
                          {/* Left accent bar */}
                          <div className={`absolute ${locale === 'ar' ? 'right-0 rounded-l-full' : 'left-0 rounded-r-full'} top-3 bottom-3 w-1 bg-gradient-to-b ${colorClass} opacity-60 group-hover:opacity-100 transition-opacity`} />

                          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                            <div className="flex items-center gap-4 flex-1">
                              <div className={`p-3 rounded-xl bg-gradient-to-br ${colorClass} shadow-lg`}>
                                <Icon className="w-6 h-6 text-white" />
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                                  <span className="bg-blue-500/15 text-blue-400 px-3 py-1 rounded-lg text-xs font-black tracking-wider border border-blue-500/20">{letter.letter_number}</span>
                                  <span className={`px-3 py-1 rounded-lg text-xs font-bold border ${letter.status === 'active' ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20' : letter.status === 'cancelled' ? 'bg-red-500/15 text-red-400 border-red-500/20' : 'bg-yellow-500/15 text-yellow-400 border-yellow-500/20'}`}>
                                    {t(`status.${letter.status}`)}
                                  </span>
                                </div>
                                <h3 className="text-lg font-bold text-white group-hover:text-blue-300 transition-colors">{letter.template_key.startsWith("custom_") ? letter.template_name_ar : t(`templates.${letter.template_key}`)}</h3>
                                <p className="text-slate-500 text-sm flex items-center gap-2 mt-1">
                                  <Calendar className="w-3.5 h-3.5" />
                                  {new Date(letter.created_at).toLocaleDateString(locale === 'ar' ? 'ar-SA' : 'en-US')}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <button onClick={() => openPreview(letter)} className="p-2.5 bg-blue-500/10 text-blue-400 rounded-xl hover:bg-blue-500/20 transition-all border border-blue-500/10 hover:border-blue-500/30" title={t("actions.preview")}><Eye className="w-5 h-5" /></button>
                              <button onClick={() => openEmailModal(letter)} className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl hover:bg-emerald-500/20 transition-all border border-emerald-500/10 hover:border-emerald-500/30" title={t("actions.sendEmail")}><Send className="w-5 h-5" /></button>
                              <button onClick={() => openEditForm(letter)} className="p-2.5 bg-yellow-500/10 text-yellow-400 rounded-xl hover:bg-yellow-500/20 transition-all border border-yellow-500/10 hover:border-yellow-500/30" title={t("actions.edit")}><Edit2 className="w-5 h-5" /></button>
                              <button onClick={() => handleDeleteClick(letter)} className="p-2.5 bg-red-500/10 text-red-400 rounded-xl hover:bg-red-500/20 transition-all border border-red-500/10 hover:border-red-500/30" title={t("actions.delete")}><Trash2 className="w-5 h-5" /></button>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </motion.div>

        {/* Letter Type Builder Modal */}
        <AnimatePresence>
          {showTypeBuilder && (
            <LetterTypeBuilderModal
              onClose={() => setShowTypeBuilder(false)}
              onSave={handleSaveCustomTemplate}
            />
          )}
        </AnimatePresence>

        {/* Settings Modal */}
        <AnimatePresence>
          {showSettings && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={(e) => e.target === e.currentTarget && setShowSettings(false)}>
              <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="bg-slate-800 rounded-2xl p-6 w-full max-w-lg shadow-2xl border border-white/10">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-white flex items-center gap-2"><Settings className="w-6 h-6 text-blue-500" /> {t("settings.title")}</h2>
                  <button onClick={() => setShowSettings(false)} className="text-slate-400 hover:text-white"><X className="w-6 h-6" /></button>
                </div>
                <div className="space-y-6">
                    <div className="bg-slate-700/50 p-6 rounded-xl border border-slate-600">
                      <label className="block text-white font-bold mb-4 flex items-center gap-2"><Upload className="w-5 h-5 text-blue-400" /> {t("settings.letterheadLabel")}</label>
                      <div className="relative group">
                        <input type="file" accept="image/*,.pdf" onChange={handleFileUpload} className="hidden" id="letterhead-upload" />
                        <label htmlFor="letterhead-upload" className="cursor-pointer block border-2 border-dashed border-slate-500 hover:border-blue-500 rounded-xl p-8 text-center transition-all bg-slate-800/50">
                          {isUploading ? <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto"></div> :
                            companyInfo?.letterhead_path ? (
                              <div className="relative">
                                {companyInfo.letterhead_path.toLowerCase().endsWith('.pdf') ? (
                                  <div className="flex flex-col items-center gap-2">
                                    <FileText className="w-20 h-20 text-red-500" />
                                    <span className="text-white text-sm">{t("settings.pdfSuccess")}</span>
                                    <span className="text-slate-400 text-xs">{t("settings.pdfNotice")}</span>
                                  </div>
                                ) : (
                                  <img src={companyInfo.letterhead_path} alt="Letterhead" className="max-h-40 mx-auto rounded shadow-lg" />
                                )}
                                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity rounded">
                                  <span className="text-white text-sm">{t("settings.changeFile")}</span>
                                </div>
                              </div>
                            ) : (
                              <div className="text-slate-400"><Upload className="w-12 h-12 mx-auto mb-2 opacity-20" /><p>{t("settings.dragDrop")}</p></div>
                            )
                          }
                        </label>
                      </div>
                    </div>

                      <div className="space-y-4">
                        <div className="bg-slate-700/50 p-4 rounded-xl border border-slate-600">
                          <div className="flex justify-between items-center mb-4">
                            <label className="text-white font-bold flex items-center gap-2"><MoveVertical className="w-5 h-5 text-blue-400" /> {t("settings.topMargin")}</label>
                            <span className="bg-blue-500 text-white px-2 py-1 rounded text-sm">{margins.top}px</span>
                          </div>
                          <input 
                            type="range" 
                            min="0" 
                            max="500" 
                            step="5" 
                            value={margins.top} 
                            onChange={(e) => {
                              setMargins({ ...margins, top: parseInt(e.target.value) });
                              setHasUnsavedMargins(true);
                            }}
                            className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer accent-blue-500" 
                          />
                        </div>
                        <div className="bg-slate-700/50 p-4 rounded-xl border border-slate-600">
                          <div className="flex justify-between items-center mb-4">
                            <label className="text-white font-bold flex items-center gap-2"><MoveVertical className="w-5 h-5 text-blue-400" /> {t("settings.bottomMargin")}</label>
                            <span className="bg-blue-500 text-white px-2 py-1 rounded text-sm">{margins.bottom}px</span>
                          </div>
                          <input 
                            type="range" 
                            min="0" 
                            max="500" 
                            step="5" 
                            value={margins.bottom} 
                            onChange={(e) => {
                              setMargins({ ...margins, bottom: parseInt(e.target.value) });
                              setHasUnsavedMargins(true);
                            }}
                            className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer accent-blue-500" 
                          />
                        </div>
                      </div>

                        {/* Visual Margin Preview with Full Letterhead */}
                        <div className="bg-slate-900/50 rounded-xl p-4">
                          <p className="text-center text-slate-400 text-sm mb-3">{t("settings.previewMargins")}</p>
                          <div className="flex justify-center">
                            <div 
                              className="relative bg-white border-2 border-slate-500 overflow-hidden shadow-2xl"
                              style={{ width: '200px', height: '283px' }}
                            >
                              {companyInfo?.letterhead_path ? (
                                companyInfo.letterhead_path.toLowerCase().endsWith('.pdf') ? (
                                  <div className="absolute inset-0">
                                    <canvas 
                                      ref={pdfCanvasRef} 
                                      className="w-full h-full object-cover"
                                    />
                                    {!pdfRendered && (
                                      <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-b from-slate-100 to-slate-200">
                                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mb-2"></div>
                                        <span className="text-[9px] text-slate-500">Loading PDF...</span>
                                      </div>
                                    )}
                                  </div>
                                ) : (
                                  <img 
                                    src={companyInfo.letterhead_path} 
                                    className="absolute inset-0 w-full h-full object-cover" 
                                    alt="Letterhead" 
                                  />
                                )
                              ) : (
                                <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-100 text-slate-400">
                                  <Upload className="w-10 h-10 mb-2 opacity-30" />
                                  <span className="text-[9px]">{t("settings.noFileUploaded")}</span>
                                </div>
                              )}
                              
                              {/* Top Margin Overlay */}
                              <div 
                                className="absolute top-0 left-0 right-0 bg-blue-500/50 border-b-2 border-blue-600 flex items-end justify-center transition-all duration-200"
                                style={{ height: `${(margins.top / 1122) * 283}px` }}
                              >
                                <div className="bg-blue-600 text-white text-[8px] font-bold px-2 py-0.5 rounded-t-md mb-[-1px] shadow">
                                  {margins.top}px
                                </div>
                              </div>
                              
                              {/* Bottom Margin Overlay */}
                              <div 
                                className="absolute bottom-0 left-0 right-0 bg-blue-500/50 border-t-2 border-blue-600 flex items-start justify-center transition-all duration-200"
                                style={{ height: `${(margins.bottom / 1122) * 283}px` }}
                              >
                                <div className="bg-blue-600 text-white text-[8px] font-bold px-2 py-0.5 rounded-b-md mt-[-1px] shadow">
                                  {margins.bottom}px
                                </div>
                              </div>
                              
                              {/* Safe Content Zone Indicator */}
                              <div 
                                className="absolute left-2 right-2 border border-dashed border-green-500/60 bg-green-500/10 flex items-center justify-center transition-all duration-200"
                                style={{ 
                                  top: `${(margins.top / 1122) * 283}px`,
                                  bottom: `${(margins.bottom / 1122) * 283}px`
                                }}
                              >
                                <span className="text-[7px] text-green-600 font-bold bg-white/80 px-1 rounded">{t("settings.safeZone")}</span>
                              </div>
                            </div>
                          </div>
                        </div>

                      <div className="flex gap-3">
                        <button
                          onClick={async () => {
                            const success = await updateCompanySettings({
                              letterhead_top_margin: margins.top,
                              letterhead_bottom_margin: margins.bottom
                            });
                            if (success) {
                              setHasUnsavedMargins(false);
                              toast.success(t("messages.updateSuccess"));
                            }
                          }}
                          disabled={!hasUnsavedMargins}
                          className={`flex-1 py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all ${
                            hasUnsavedMargins 
                              ? "bg-blue-500 hover:bg-blue-600 text-white" 
                              : "bg-slate-700 text-slate-500 cursor-not-allowed"
                          }`}
                        >
                          <Check className="w-5 h-5" />
                          {t("settings.saveSettings")}
                        </button>
                      </div>
                    </div>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>


        {/* Template Selection Modal */}
        <AnimatePresence>
          {showTemplateSelectModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4"
              onClick={(e) => e.target === e.currentTarget && setShowTemplateSelectModal(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.9, opacity: 0, y: 20 }}
                transition={{ type: "spring", damping: 25, stiffness: 300 }}
                className="relative bg-gradient-to-br from-slate-800/95 via-slate-800/90 to-slate-900/95 backdrop-blur-2xl rounded-[2rem] border border-white/10 shadow-2xl w-full max-w-3xl overflow-hidden"
              >
                <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500" />
                <div className="p-8">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-gradient-to-br from-blue-500/20 to-indigo-500/20 rounded-xl border border-blue-500/20">
                        <FileSignature className="w-6 h-6 text-blue-400" />
                      </div>
                      <div>
                        <h2 className="text-2xl font-black text-white tracking-tight">{t("newLetterTitle")}</h2>
                        <p className="text-slate-400 text-sm">اختر نوع الخطاب لإنشائه</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setShowTemplateSelectModal(false)}
                      className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl transition-all"
                    >
                      <X className="w-6 h-6" />
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {templates.map((template, idx) => {
                      const Icon = templateIcons[template.template_key] || (template.is_system_template ? FileText : PenLine);
                      const colorClass = templateColors[template.template_key] || (template.is_system_template ? "from-gray-500 to-gray-600" : "from-violet-600 to-purple-700");
                      return (
                        <motion.button
                          key={template.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: idx * 0.05 }}
                          whileHover={{ scale: 1.03, y: -4 }}
                          whileTap={{ scale: 0.97 }}
                          onClick={() => {
                            setShowTemplateSelectModal(false);
                            openCreateForm(template);
                          }}
                          className={`group relative bg-gradient-to-br ${colorClass} p-6 rounded-2xl text-white ${locale === 'ar' ? 'text-right' : 'text-left'} shadow-xl hover:shadow-2xl transition-all overflow-hidden`}
                        >
                          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
                          <div className="relative z-10">
                            <div className="flex items-start justify-between mb-4">
                              <div className="p-3 bg-white/20 backdrop-blur-sm rounded-xl border border-white/20 shadow-lg">
                                <Icon className="w-6 h-6" />
                              </div>
                              <motion.div whileHover={{ x: locale === 'ar' ? -5 : 5 }}>
                                {locale === 'ar' ? <ChevronLeft className="w-5 h-5 opacity-50" /> : <ChevronLeft className="w-5 h-5 opacity-50 rotate-180" />}
                              </motion.div>
                            </div>
                            <h3 className="font-bold text-base mb-1 leading-tight">{getTemplateName(template)}</h3>
                            <p className="text-sm text-white/60">{t("fieldsToFill", { count: getPlaceholders(template).length })}</p>
                          </div>
                        </motion.button>
                      );
                    })}
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Create/Edit Form Modal */}
        <AnimatePresence>
          {showForm && selectedTemplate && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={(e) => e.target === e.currentTarget && resetForm()}>
              <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="bg-slate-800 rounded-2xl p-6 w-full max-w-3xl max-h-[90vh] overflow-y-auto">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-white flex items-center gap-2"><FileText className="w-6 h-6 text-blue-500" /> {editingLetter ? t("form.editTitle") : t("form.createTitle", { template: getTemplateName(selectedTemplate) })}</h2>
                  <button onClick={resetForm} className="text-slate-400 hover:text-white"><X className="w-6 h-6" /></button>
                </div>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {getPlaceholders(selectedTemplate).map((placeholder) => (
                        <div key={placeholder}>
                          <label className="block text-slate-300 mb-2 text-sm font-medium">{getFieldLabel(placeholder, selectedTemplate)}</label>
                          {placeholder === "salary_period_type" ? (
                            <select
                              value={formData[placeholder] || ""}
                              onChange={(e) => setFormData({ ...formData, [placeholder]: e.target.value })}
                              className="w-full bg-slate-700 border border-slate-600 rounded-xl py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                              <option value="">{t("form.select") || "اختر..."}</option>
                              <option value="شهري">شهري</option>
                              <option value="سنوي">سنوي</option>
                            </select>
                          ) : (
                            <>
                              <input
                                type={placeholder.includes("date") || placeholder.includes("period_") ? "date" : "text"}
                                value={formData[placeholder] || ""}
                                onChange={(e) => setFormData({ ...formData, [placeholder]: e.target.value })}
                                readOnly={placeholder === "total_amount" || placeholder === "total_amount_text"}
                                className={`w-full bg-slate-700 border border-slate-600 rounded-xl py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 ${(placeholder === "total_amount" || placeholder === "total_amount_text") ? "opacity-75 cursor-not-allowed bg-slate-800" : ""}`}
                                placeholder={getFieldLabel(placeholder, selectedTemplate)}
                              />
                              {placeholder === "total_deduction" && (
                                <p className="text-xs text-slate-400 mt-1">يمكنك إضافة مبلغ خصم هنا من الإجمالي إذا كان المبلغ لا يطابق أو أشهر رواتبها منخفضة</p>
                              )}
                            </>
                          )}
                        </div>
                      ))}

                  </div>
                  <div className="flex gap-3 pt-4">
                    <button type="submit" className="flex-1 bg-blue-500 hover:bg-blue-600 text-white py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2">
                      <Check className="w-5 h-5" /> 
                      {editingLetter ? t("form.saveChanges") : t("form.createLetter")}
                    </button>
                    <button type="button" onClick={resetForm} className="px-6 bg-slate-600 hover:bg-slate-500 text-white py-3 rounded-xl font-bold transition-all">
                      {t("form.cancel")}
                    </button>
                  </div>
                </form>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

          {/* Preview Modal */}
          <AnimatePresence>
            {showPreview && previewLetter && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={(e) => e.target === e.currentTarget && setShowPreview(false)}>
                <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="bg-white rounded-2xl w-full max-w-4xl max-h-[95vh] overflow-hidden flex flex-col">
                  <div className="bg-slate-800 p-4 flex items-center justify-between">
                    <h2 className="text-xl font-bold text-white">{t("preview.title", { number: previewLetter.letter_number })}</h2>
                    <div className="flex items-center gap-2">
                        <button onClick={handlePrint} className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition-all"><Printer className="w-5 h-5" /> {t("preview.print")}</button>
                        <button onClick={handleDownloadPdf} className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-lg transition-all"><Download className="w-5 h-5" /> {t("preview.downloadPdf")}</button>
                      <button onClick={() => setShowPreview(false)} className="text-slate-400 hover:text-white p-2"><X className="w-6 h-6" /></button>
                    </div>
                  </div>
                    <div className="flex-1 overflow-y-auto bg-slate-200 p-4 md:p-8 flex justify-center">
                        <PreviewPage
                          content={generateLetterContent(previewLetter)}
                          letterheadPath={companyInfo?.letterhead_path}
                          topMargin={margins.top}
                          bottomMargin={margins.bottom}
                          convertPdfToImage={convertPdfToImage}
                        />
                        </div>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>

          {/* Email Modal */}
          <AnimatePresence>
            {showEmailModal && emailLetter && (
              <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                exit={{ opacity: 0 }} 
                className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4" 
                onClick={(e) => e.target === e.currentTarget && !isSendingEmail && setShowEmailModal(false)}
              >
                <motion.div 
                  initial={{ scale: 0.9, opacity: 0 }} 
                  animate={{ scale: 1, opacity: 1 }} 
                  exit={{ scale: 0.9, opacity: 0 }} 
                  className="bg-slate-800 rounded-3xl p-8 w-full max-w-lg shadow-2xl border border-white/10"
                >
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-white flex items-center gap-3">
                      <div className="p-3 bg-emerald-500/20 rounded-xl">
                        <Send className="w-6 h-6 text-emerald-400" />
                      </div>
                      {t("email.title")}
                    </h2>
                    <button 
                      onClick={() => !isSendingEmail && setShowEmailModal(false)} 
                      className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-white/10 transition-all"
                      disabled={isSendingEmail}
                    >
                      <X className="w-6 h-6" />
                    </button>
                  </div>

                  <div className="bg-slate-700/30 rounded-2xl p-4 mb-6 border border-slate-600/50">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-500/20 rounded-lg">
                        <FileText className="w-5 h-5 text-blue-400" />
                      </div>
                      <div>
                        <p className="text-white font-bold">{t(`templates.${emailLetter.template_key}`)}</p>
                        <p className="text-slate-400 text-sm">{emailLetter.letter_number}</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <button
                      onClick={() => handleSendEmail(true)}
                      disabled={isSendingEmail || !companyInfo?.email}
                      className={`w-full p-5 rounded-2xl border-2 transition-all flex items-center gap-4 ${
                        companyInfo?.email 
                          ? "bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border-emerald-500/30 hover:border-emerald-500/60 hover:bg-emerald-500/20" 
                          : "bg-slate-700/30 border-slate-600/30 opacity-50 cursor-not-allowed"
                      }`}
                    >
                      <div className="p-3 bg-emerald-500/20 rounded-xl">
                        {isSendingEmail ? (
                          <Loader2 className="w-6 h-6 text-emerald-400 animate-spin" />
                        ) : (
                          <Building2 className="w-6 h-6 text-emerald-400" />
                        )}
                      </div>
                      <div className={`${locale === 'ar' ? 'text-right' : 'text-left'} flex-1`}>
                        <p className="text-white font-bold text-lg">{t("email.sendToCompany")}</p>
                        <p className="text-slate-400 text-sm">
                          {companyInfo?.email || t("email.noCompanyEmail")}
                        </p>
                      </div>
                      <Send className={`w-5 h-5 text-emerald-400 ${locale === 'ar' ? '' : 'rotate-180'}`} />
                    </button>

                    <div className="relative">
                      <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-slate-600"></div>
                      </div>
                      <div className="relative flex justify-center">
                        <span className="bg-slate-800 px-4 text-slate-400 text-sm">{t("email.or")}</span>
                      </div>
                    </div>

                    <div className="bg-slate-700/30 rounded-2xl p-5 border border-slate-600/50">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="p-2 bg-blue-500/20 rounded-lg">
                          <AtSign className="w-5 h-5 text-blue-400" />
                        </div>
                        <p className="text-white font-bold">{t("email.sendToOther")}</p>
                      </div>
                      <div className="flex gap-3">
                        <input
                          type="email"
                          placeholder={t("email.emailPlaceholder")}
                          value={customEmail}
                          onChange={(e) => setCustomEmail(e.target.value)}
                          disabled={isSendingEmail}
                          className="flex-1 bg-slate-800 border border-slate-600 rounded-xl py-3 px-4 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          dir="ltr"
                        />
                        <button
                          onClick={() => handleSendEmail(false)}
                          disabled={isSendingEmail || !customEmail}
                          className={`px-6 rounded-xl font-bold flex items-center gap-2 transition-all ${
                            customEmail && !isSendingEmail
                              ? "bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white"
                              : "bg-slate-700 text-slate-500 cursor-not-allowed"
                          }`}
                        >
                          {isSendingEmail ? (
                            <Loader2 className="w-5 h-5 animate-spin" />
                          ) : (
                            <Send className={`w-5 h-5 ${locale === 'ar' ? '' : 'rotate-180'}`} />
                          )}
                        </button>
                      </div>
                    </div>
                  </div>

                  {isSendingEmail && (
                    <div className="mt-6 bg-blue-500/10 border border-blue-500/30 rounded-xl p-4 flex items-center gap-3">
                      <Loader2 className="w-5 h-5 text-blue-400 animate-spin" />
                      <p className="text-blue-400 text-sm">{t("email.sendingStatus")}</p>
                    </div>
                  )}
                </motion.div>
              </motion.div>
            )}
            </AnimatePresence>

          {/* Save Confirm Modal */}
          <AnimatePresence>
            {saveConfirmModal && (
              <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => setSaveConfirmModal(false)}
                  className="absolute inset-0 bg-slate-950/90 backdrop-blur-2xl"
                />
                <motion.div
                  initial={{ opacity: 0, scale: 0.8, y: 50 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.8, y: 50 }}
                  transition={{ type: "spring", damping: 25, stiffness: 300 }}
                  className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-[3rem] shadow-[0_0_100px_rgba(59,130,246,0.3)] overflow-hidden border-4 border-blue-500/20"
                >
                  <div className="relative bg-gradient-to-br from-blue-500 via-indigo-600 to-blue-700 p-10 text-white text-center overflow-hidden">
                    <div className="absolute inset-0 opacity-10">
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                    </div>
                    <motion.div
                      initial={{ scale: 0, rotate: -180 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ delay: 0.2, type: "spring", damping: 15 }}
                      className="relative z-10 mx-auto w-24 h-24 bg-white/20 backdrop-blur-xl rounded-full flex items-center justify-center mb-6 shadow-2xl border-4 border-white/30"
                    >
                      <motion.div animate={{ scale: [1, 1.1, 1] }} transition={{ repeat: Infinity, duration: 2 }}>
                        <Shield size={48} className="text-white drop-shadow-lg" />
                      </motion.div>
                    </motion.div>
                    <motion.h3 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="text-3xl font-black tracking-tight relative z-10">
                      تأكيد {editingLetter ? 'تعديل' : 'حفظ'} الخطاب
                    </motion.h3>
                    <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="text-white/80 font-bold mt-2 relative z-10">
                      يرجى التأكد من صحة البيانات قبل المتابعة
                    </motion.p>
                  </div>
                  <div className="p-8 text-center space-y-6">
                    <div className="bg-blue-50 dark:bg-blue-950/30 rounded-2xl p-6 border-2 border-blue-100 dark:border-blue-900/50">
                      <p className="text-slate-700 dark:text-slate-300 font-bold text-lg leading-relaxed">
                        {editingLetter ? 'هل تريد حفظ التعديلات على الخطاب؟' : 'هل تريد إنشاء هذا الخطاب الرسمي؟'}
                      </p>
                      <p className="text-blue-600 dark:text-blue-400 font-black text-xl mt-2">
                        {selectedTemplate ? t(`templates.${selectedTemplate.template_key}`) : ''}
                      </p>
                      {formData.employee_name && (
                        <p className="text-slate-500 dark:text-slate-400 font-bold text-sm mt-2">
                          الموظف: {formData.employee_name}
                        </p>
                      )}
                    </div>
                    <p className="text-slate-500 font-bold text-sm">
                      سيتم حفظ الخطاب وإضافته إلى السجلات الرسمية
                    </p>
                    <div className="flex gap-4 pt-4">
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => setSaveConfirmModal(false)}
                        className="flex-1 flex items-center justify-center gap-3 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 py-4 rounded-2xl font-black text-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                      >
                        <X size={20} />
                        إلغاء
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.02, boxShadow: "0 20px 40px rgba(59, 130, 246, 0.4)" }}
                        whileTap={{ scale: 0.98 }}
                        onClick={confirmSave}
                        className="flex-1 flex items-center justify-center gap-3 bg-gradient-to-r from-blue-500 via-indigo-600 to-blue-600 text-white py-4 rounded-2xl font-black text-lg shadow-xl shadow-blue-500/30 border-b-4 border-blue-700/50"
                      >
                        <Check size={20} />
                        نعم، احفظ
                      </motion.button>
                    </div>
                  </div>
                </motion.div>
              </div>
            )}
          </AnimatePresence>

          {/* Saving Modal */}
          <AnimatePresence>
            {savingModal && (
              <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 bg-slate-950/90 backdrop-blur-2xl"
                />
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  transition={{ type: "spring", damping: 25, stiffness: 300 }}
                  className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-[3rem] shadow-[0_0_100px_rgba(59,130,246,0.3)] overflow-hidden border-4 border-blue-500/20"
                >
                  <div className="relative bg-gradient-to-br from-blue-500 via-indigo-600 to-blue-700 p-12 text-white text-center overflow-hidden">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                      className="mx-auto w-24 h-24 bg-white/20 backdrop-blur-xl rounded-full flex items-center justify-center mb-6 shadow-2xl border-4 border-white/30"
                    >
                      <Loader2 size={48} className="text-white" />
                    </motion.div>
                    <h3 className="text-3xl font-black tracking-tight">جارٍ الحفظ</h3>
                    <div className="flex items-center justify-center gap-1 mt-3">
                      {[0, 1, 2].map((i) => (
                        <motion.div
                          key={i}
                          animate={{ opacity: [0.3, 1, 0.3], scale: [0.8, 1.2, 0.8] }}
                          transition={{ repeat: Infinity, duration: 1.5, delay: i * 0.3 }}
                          className="w-3 h-3 bg-white rounded-full"
                        />
                      ))}
                    </div>
                    <p className="text-white/80 font-bold mt-4">يتم حفظ الخطاب الرسمي في النظام...</p>
                  </div>
                </motion.div>
              </div>
            )}
          </AnimatePresence>

          {/* Save Success Modal */}
          <AnimatePresence>
            {saveSuccessModal.isOpen && (
              <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => setSaveSuccessModal({ isOpen: false, letterNumber: '' })}
                  className="absolute inset-0 bg-slate-950/90 backdrop-blur-2xl"
                />
                <motion.div
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.5 }}
                  transition={{ type: "spring", damping: 20, stiffness: 300 }}
                  className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-[3rem] shadow-[0_0_100px_rgba(16,185,129,0.3)] overflow-hidden border-4 border-emerald-500/20"
                >
                  <div className="relative bg-gradient-to-br from-emerald-500 via-green-600 to-teal-600 p-10 text-white text-center overflow-hidden">
                    <div className="absolute inset-0 overflow-hidden">
                      {[...Array(6)].map((_, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, y: 100, x: Math.random() * 400 - 200 }}
                          animate={{ opacity: [0, 1, 0], y: -100, rotate: Math.random() * 360 }}
                          transition={{ duration: 2, delay: i * 0.3, repeat: Infinity }}
                          className="absolute"
                        >
                          <Sparkles size={20} className="text-yellow-300" />
                        </motion.div>
                      ))}
                    </div>
                    <motion.div
                      initial={{ scale: 0, rotate: -180 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ delay: 0.2, type: "spring", damping: 15 }}
                      className="relative z-10 mx-auto w-24 h-24 bg-white/20 backdrop-blur-xl rounded-full flex items-center justify-center mb-6 shadow-2xl border-4 border-white/30"
                    >
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: [0, 1.3, 1] }}
                        transition={{ delay: 0.5, duration: 0.5 }}
                      >
                        <CheckCircle size={48} className="text-white drop-shadow-lg" />
                      </motion.div>
                    </motion.div>
                    <motion.h3 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="text-3xl font-black tracking-tight relative z-10">
                      تم الحفظ بنجاح!
                    </motion.h3>
                    <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="text-white/80 font-bold mt-2 relative z-10">
                      تم إنشاء الخطاب الرسمي وإضافته للسجلات
                    </motion.p>
                  </div>
                  <div className="p-8 text-center space-y-6">
                    <div className="bg-emerald-50 dark:bg-emerald-950/30 rounded-2xl p-6 border-2 border-emerald-100 dark:border-emerald-900/50">
                      <p className="text-slate-700 dark:text-slate-300 font-bold text-lg">
                        رقم الخطاب
                      </p>
                      <p className="text-emerald-600 dark:text-emerald-400 font-black text-2xl mt-2">
                        {saveSuccessModal.letterNumber}
                      </p>
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.02, boxShadow: "0 20px 40px rgba(16, 185, 129, 0.4)" }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setSaveSuccessModal({ isOpen: false, letterNumber: '' })}
                      className="w-full flex items-center justify-center gap-3 bg-gradient-to-r from-emerald-500 via-green-600 to-teal-600 text-white py-4 rounded-2xl font-black text-lg shadow-xl shadow-emerald-500/30 border-b-4 border-emerald-700/50"
                    >
                      <Check size={20} />
                      تم، إغلاق
                    </motion.button>
                  </div>
                </motion.div>
              </div>
            )}
          </AnimatePresence>

          {/* Save Error Modal */}
          <AnimatePresence>
            {saveErrorModal.isOpen && (
              <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => setSaveErrorModal({ isOpen: false, message: '' })}
                  className="absolute inset-0 bg-slate-950/90 backdrop-blur-2xl"
                />
                <motion.div
                  initial={{ opacity: 0, scale: 0.8, y: 50 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.8, y: 50 }}
                  transition={{ type: "spring", damping: 25, stiffness: 300 }}
                  className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-[3rem] shadow-[0_0_100px_rgba(239,68,68,0.3)] overflow-hidden border-4 border-red-500/20"
                >
                  <div className="relative bg-gradient-to-br from-red-500 via-rose-600 to-red-700 p-10 text-white text-center">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 0.2, type: "spring", damping: 15 }}
                      className="mx-auto w-24 h-24 bg-white/20 backdrop-blur-xl rounded-full flex items-center justify-center mb-6 shadow-2xl border-4 border-white/30"
                    >
                      <X size={48} className="text-white drop-shadow-lg" />
                    </motion.div>
                    <h3 className="text-3xl font-black tracking-tight">فشل في الحفظ</h3>
                    <p className="text-white/80 font-bold mt-2">حدث خطأ أثناء حفظ الخطاب</p>
                  </div>
                  <div className="p-8 text-center space-y-6">
                    <div className="bg-red-50 dark:bg-red-950/30 rounded-2xl p-6 border-2 border-red-100 dark:border-red-900/50">
                      <p className="text-red-600 dark:text-red-400 font-bold text-lg">{saveErrorModal.message}</p>
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setSaveErrorModal({ isOpen: false, message: '' })}
                      className="w-full flex items-center justify-center gap-3 bg-gradient-to-r from-red-500 via-rose-600 to-red-600 text-white py-4 rounded-2xl font-black text-lg shadow-xl shadow-red-500/30 border-b-4 border-red-700/50"
                    >
                      <X size={20} />
                      إغلاق
                    </motion.button>
                  </div>
                </motion.div>
              </div>
            )}
          </AnimatePresence>

          {/* Delete Confirm Modal */}
          <AnimatePresence>
            {deleteConfirmModal.isOpen && (
              <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => setDeleteConfirmModal({ isOpen: false, item: null })}
                  className="absolute inset-0 bg-slate-950/90 backdrop-blur-2xl"
                />
                <motion.div
                  initial={{ opacity: 0, scale: 0.8, y: 50 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.8, y: 50 }}
                  transition={{ type: "spring", damping: 25, stiffness: 300 }}
                  className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-[3rem] shadow-[0_0_100px_rgba(239,68,68,0.3)] overflow-hidden border-4 border-red-500/20"
                >
                  <div className="relative bg-gradient-to-br from-red-500 via-rose-600 to-red-700 p-10 text-white text-center overflow-hidden">
                    <div className="absolute inset-0 opacity-10">
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                    </div>
                    <motion.div
                      initial={{ scale: 0, rotate: -180 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ delay: 0.2, type: "spring", damping: 15 }}
                      className="relative z-10 mx-auto w-24 h-24 bg-white/20 backdrop-blur-xl rounded-full flex items-center justify-center mb-6 shadow-2xl border-4 border-white/30"
                    >
                      <motion.div animate={{ scale: [1, 1.1, 1] }} transition={{ repeat: Infinity, duration: 2 }}>
                        <AlertTriangle size={48} className="text-white drop-shadow-lg" />
                      </motion.div>
                    </motion.div>
                    <motion.h3 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="text-3xl font-black tracking-tight relative z-10">
                      تأكيد الحذف
                    </motion.h3>
                    <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="text-white/80 font-bold mt-2 relative z-10">
                      هذا الإجراء لا يمكن التراجع عنه
                    </motion.p>
                  </div>
                  <div className="p-8 text-center space-y-6">
                    <div className="bg-red-50 dark:bg-red-950/30 rounded-2xl p-6 border-2 border-red-100 dark:border-red-900/50">
                      <p className="text-slate-700 dark:text-slate-300 font-bold text-lg leading-relaxed">
                        هل أنت متأكد من حذف الخطاب الرسمي
                      </p>
                      <p className="text-red-600 dark:text-red-400 font-black text-xl mt-2">
                        "{deleteConfirmModal.item?.letter_number}"
                      </p>
                      <p className="text-slate-500 dark:text-slate-400 font-bold text-sm mt-2">
                        {deleteConfirmModal.item ? t(`templates.${deleteConfirmModal.item.template_key}`) : ''}
                      </p>
                    </div>
                    <p className="text-slate-500 font-bold text-sm">
                      سيتم حذف الخطاب نهائياً من السجلات ولا يمكن التراجع عنه
                    </p>
                    <div className="flex gap-4 pt-4">
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => setDeleteConfirmModal({ isOpen: false, item: null })}
                        className="flex-1 flex items-center justify-center gap-3 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 py-4 rounded-2xl font-black text-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                      >
                        <X size={20} />
                        إلغاء
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.02, boxShadow: "0 20px 40px rgba(239, 68, 68, 0.4)" }}
                        whileTap={{ scale: 0.98 }}
                        onClick={confirmDelete}
                        className="flex-1 flex items-center justify-center gap-3 bg-gradient-to-r from-red-500 via-rose-600 to-red-600 text-white py-4 rounded-2xl font-black text-lg shadow-xl shadow-red-500/30 border-b-4 border-red-700/50"
                      >
                        <Trash2 size={20} />
                        نعم، احذف
                      </motion.button>
                    </div>
                  </div>
                </motion.div>
              </div>
            )}
          </AnimatePresence>

          {/* Deleting Modal */}
          <AnimatePresence>
            {deletingModal && (
              <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 bg-slate-950/90 backdrop-blur-2xl"
                />
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  transition={{ type: "spring", damping: 25, stiffness: 300 }}
                  className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-[3rem] shadow-[0_0_100px_rgba(239,68,68,0.3)] overflow-hidden border-4 border-red-500/20"
                >
                  <div className="relative bg-gradient-to-br from-red-500 via-rose-600 to-red-700 p-12 text-white text-center overflow-hidden">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                      className="mx-auto w-24 h-24 bg-white/20 backdrop-blur-xl rounded-full flex items-center justify-center mb-6 shadow-2xl border-4 border-white/30"
                    >
                      <Loader2 size={48} className="text-white" />
                    </motion.div>
                    <h3 className="text-3xl font-black tracking-tight">جارٍ الحذف</h3>
                    <div className="flex items-center justify-center gap-1 mt-3">
                      {[0, 1, 2].map((i) => (
                        <motion.div
                          key={i}
                          animate={{ opacity: [0.3, 1, 0.3], scale: [0.8, 1.2, 0.8] }}
                          transition={{ repeat: Infinity, duration: 1.5, delay: i * 0.3 }}
                          className="w-3 h-3 bg-white rounded-full"
                        />
                      ))}
                    </div>
                    <p className="text-white/80 font-bold mt-4">يتم حذف الخطاب من السجلات...</p>
                  </div>
                </motion.div>
              </div>
            )}
          </AnimatePresence>

          {/* Delete Success Modal */}
          <AnimatePresence>
            {deleteSuccessModal.isOpen && (
              <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => setDeleteSuccessModal({ isOpen: false, title: '' })}
                  className="absolute inset-0 bg-slate-950/90 backdrop-blur-2xl"
                />
                <motion.div
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.5 }}
                  transition={{ type: "spring", damping: 20, stiffness: 300 }}
                  className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-[3rem] shadow-[0_0_100px_rgba(16,185,129,0.3)] overflow-hidden border-4 border-emerald-500/20"
                >
                  <div className="relative bg-gradient-to-br from-emerald-500 via-green-600 to-teal-600 p-10 text-white text-center overflow-hidden">
                    <div className="absolute inset-0 overflow-hidden">
                      {[...Array(6)].map((_, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, y: 100, x: Math.random() * 400 - 200 }}
                          animate={{ opacity: [0, 1, 0], y: -100, rotate: Math.random() * 360 }}
                          transition={{ duration: 2, delay: i * 0.3, repeat: Infinity }}
                          className="absolute"
                        >
                          <Sparkles size={20} className="text-yellow-300" />
                        </motion.div>
                      ))}
                    </div>
                    <motion.div
                      initial={{ scale: 0, rotate: -180 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ delay: 0.2, type: "spring", damping: 15 }}
                      className="relative z-10 mx-auto w-24 h-24 bg-white/20 backdrop-blur-xl rounded-full flex items-center justify-center mb-6 shadow-2xl border-4 border-white/30"
                    >
                      <motion.div initial={{ scale: 0 }} animate={{ scale: [0, 1.3, 1] }} transition={{ delay: 0.5, duration: 0.5 }}>
                        <CheckCircle size={48} className="text-white drop-shadow-lg" />
                      </motion.div>
                    </motion.div>
                    <motion.h3 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="text-3xl font-black tracking-tight relative z-10">
                      تم الحذف بنجاح!
                    </motion.h3>
                    <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="text-white/80 font-bold mt-2 relative z-10">
                      تم حذف الخطاب من السجلات الرسمية
                    </motion.p>
                  </div>
                  <div className="p-8 text-center space-y-6">
                    <div className="bg-emerald-50 dark:bg-emerald-950/30 rounded-2xl p-6 border-2 border-emerald-100 dark:border-emerald-900/50">
                      <p className="text-slate-700 dark:text-slate-300 font-bold text-lg">
                        تم حذف الخطاب
                      </p>
                      <p className="text-emerald-600 dark:text-emerald-400 font-black text-xl mt-2">
                        "{deleteSuccessModal.title}"
                      </p>
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.02, boxShadow: "0 20px 40px rgba(16, 185, 129, 0.4)" }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setDeleteSuccessModal({ isOpen: false, title: '' })}
                      className="w-full flex items-center justify-center gap-3 bg-gradient-to-r from-emerald-500 via-green-600 to-teal-600 text-white py-4 rounded-2xl font-black text-lg shadow-xl shadow-emerald-500/30 border-b-4 border-emerald-700/50"
                    >
                      <Check size={20} />
                      تم، إغلاق
                    </motion.button>
                  </div>
                </motion.div>
              </div>
            )}
          </AnimatePresence>

        </div>
      </div>
    );
}

