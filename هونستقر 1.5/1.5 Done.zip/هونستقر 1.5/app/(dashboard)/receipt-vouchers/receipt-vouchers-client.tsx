"use client";

import React, { useState, useEffect, useMemo, Suspense } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Receipt, Save, Calendar, User, Building, CreditCard, Landmark,
  DollarSign, FileText, Percent, Calculator, Hash, PlusCircle,
  Search, Edit3, Trash2, Printer, Mail, Eye, ChevronDown, ChevronUp,
  CheckCircle, AlertCircle, X, ArrowDown, ArrowUp, Building2,
  Banknote, StickyNote, Sparkles, Filter, Download, RefreshCw,
  Plus, Loader2, TrendingUp, FileSpreadsheet, ExternalLink
} from "lucide-react";
import Link from "next/link";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useTranslations, useLocale } from "@/lib/locale-context";
import { DeleteNotification, useDeleteNotification } from "@/components/ui/delete-notification";

interface Account {
  id: number;
  account_code: string;
  account_name: string;
}

interface CostCenter {
  id: number;
  center_code: string;
  center_name: string;
}

interface Voucher {
  id: number;
  receipt_number: string;
  receipt_date: string;
  received_from: string;
  branch_code: string;
  branch_name: string;
  payment_method: string;
  account_name: string;
  debit_account_code: string;
  debit_cost_center: string;
  credit_account_code: string;
  credit_cost_center: string;
  amount: number;
  tax_rate: number;
  tax_value: number;
  total_amount: number;
  document_number: string;
  bank_name: string;
  document_date: string;
  description: string;
  notes: string;
  created_by: string;
  created_at: string;
}

const paymentMethods = [
  { value: "نقدي", label: "نقدي", icon: Banknote },
  { value: "شبكة", label: "شبكة", icon: CreditCard },
  { value: "الإيداع", label: "الإيداع", icon: Building2 },
  { value: "التحويل الإلكتروني", label: "تحويل إلكتروني", icon: Landmark },
];

function ReceiptVouchersContent({ companyId }: { companyId: string }) {
  const t = useTranslations("financialVouchersPage.receiptVouchersPage");
  const tFinancial = useTranslations("financialVouchersPage");
  const tSales = useTranslations("financialVouchersPage.salesReceiptsPage");
  const tCommon = useTranslations("common");
  const { locale } = useLocale();
  const isRtl = locale === "ar";
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [receiptNumber, setReceiptNumber] = useState("");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [deleteLoading, setDeleteLoading] = useState<number | null>(null);
  const [fetchError, setFetchError] = useState(false);
  const { notification, showDeleteConfirm, showLoading, showSuccess: showSuccessNotif, showError, hideNotification } = useDeleteNotification("blue");

  const initialForm = {
    receipt_date: new Date().toISOString().split("T")[0],
    received_from: "",
    branch_code: "",
    branch_name: "",
    payment_method: "نقدي",
    account_name: "",
    debit_account_code: "",
    debit_cost_center: "",
    credit_account_code: "",
    credit_cost_center: "",
    amount: "",
    tax_rate: "15",
    tax_value: "0",
    total_amount: "0",
    document_number: "",
    bank_name: "",
    document_date: "",
    description: "",
    notes: "",
  };

  const [form, setForm] = useState(initialForm);

    const fetchData = async () => {
      setFetchError(false);
      try {
        const res = await fetch(`/api/receipt-vouchers/metadata?company_id=${companyId}`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        if (data.error) throw new Error(data.error);
        setAccounts(data.accounts || []);
        setCostCenters(data.costCenters || []);
        setVouchers(data.vouchers || []);
        if (!editingId) setReceiptNumber(data.receiptNumber);
      } catch (error) {
        console.error(error);
        setFetchError(true);
        toast.error(t("notifications.fetchError"));
      } finally {
        setLoading(false);
      }
    };

    useEffect(() => {
      fetchData();
    }, []);

    useEffect(() => {
      const amount = parseFloat(form.amount) || 0;
      const taxRate = parseFloat(form.tax_rate) || 0;
      const taxValue = amount * (taxRate / 100);
      const total = amount + taxValue;
      setForm(prev => ({
        ...prev,
        tax_value: taxValue.toFixed(2),
        total_amount: total.toFixed(2),
      }));
    }, [form.amount, form.tax_rate]);

    const filteredVouchers = useMemo(() => {
      if (!searchTerm) return vouchers;
      const lower = searchTerm.toLowerCase();
      return vouchers.filter(v =>
        v.receipt_number.toLowerCase().includes(lower) ||
        v.received_from.toLowerCase().includes(lower) ||
        v.description?.toLowerCase().includes(lower)
      );
    }, [vouchers, searchTerm]);

    const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      setSubmitting(true);

      try {
        const res = await fetch("/api/receipt-vouchers/save", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ...form,
            id: editingId,
            company_id: companyId,
            receipt_number: receiptNumber,
            created_by: "المدير",
          }),
        });

        const data = await res.json();
        if (!data.success) throw new Error(data.error);

        setShowSuccess(true);
        setTimeout(() => setShowSuccess(false), 3000);
        resetForm();
        fetchData();
      } catch (error: any) {
        toast.error(error.message || t("notifications.saveFailed"));
      } finally {
        setSubmitting(false);
      }
    };

    const resetForm = () => {
      setForm(initialForm);
      setEditingId(null);
      setShowForm(false);
    };

    const handleEdit = (voucher: Voucher) => {
      setForm({
        receipt_date: voucher.receipt_date,
        received_from: voucher.received_from || "",
        branch_code: voucher.branch_code || "",
        branch_name: voucher.branch_name || "",
        payment_method: voucher.payment_method || "نقدي",
        account_name: voucher.account_name || "",
        debit_account_code: voucher.debit_account_code || "",
        debit_cost_center: voucher.debit_cost_center || "",
        credit_account_code: voucher.credit_account_code || "",
        credit_cost_center: voucher.credit_cost_center || "",
        amount: String(voucher.amount || ""),
        tax_rate: String(voucher.tax_rate || "15"),
        tax_value: String(voucher.tax_value || "0"),
        total_amount: String(voucher.total_amount || "0"),
        document_number: voucher.document_number || "",
        bank_name: voucher.bank_name || "",
        document_date: voucher.document_date || "",
        description: voucher.description || "",
        notes: voucher.notes || "",
      });
      setReceiptNumber(voucher.receipt_number);
      setEditingId(voucher.id);
      setShowForm(true);
      window.scrollTo({ top: 0, behavior: "smooth" });
    };

    const handleDelete = (id: number, receiptNumber: string) => {
      showDeleteConfirm(
        isRtl ? "تأكيد حذف سند القبض" : "Confirm Delete Receipt Voucher",
        isRtl 
          ? `هل أنت متأكد من حذف سند القبض رقم "${receiptNumber}"؟\nلا يمكن التراجع عن هذا الإجراء.`
          : `Are you sure you want to delete receipt voucher "${receiptNumber}"?\nThis action cannot be undone.`,
        () => confirmDelete(id),
        id,
        receiptNumber
      );
    };

    const confirmDelete = async (id: number) => {
      setDeleteLoading(id);
      hideNotification();
      showLoading(
        isRtl ? "جاري الحذف" : "Deleting",
        isRtl ? "جاري حذف سند القبض..." : "Deleting receipt voucher..."
      );
      
      try {
        const res = await fetch(`/api/receipt-vouchers/delete?id=${id}&company_id=${companyId}`, {
          method: "DELETE",
        });
        if (res.ok) {
          showSuccessNotif(
            isRtl ? "تم الحذف بنجاح" : "Deleted Successfully",
            isRtl ? "تم حذف سند القبض بنجاح" : "Receipt voucher deleted successfully"
          );
          fetchData();
        } else {
          showError(
            isRtl ? "فشل الحذف" : "Delete Failed",
            isRtl ? "فشل حذف سند القبض" : "Failed to delete receipt voucher"
          );
        }
      } catch {
        showError(
          isRtl ? "خطأ" : "Error",
          isRtl ? "حدث خطأ أثناء الحذف" : "An error occurred during deletion"
        );
      } finally {
        setDeleteLoading(null);
      }
    };

    if (loading) {
      return (
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="w-10 h-10 text-blue-500 animate-spin" />
        </div>
      );
    }

    if (fetchError && vouchers.length === 0) {
      return (
        <div className="flex items-center justify-center min-h-screen" dir={isRtl ? "rtl" : "ltr"}>
          <div className="text-center space-y-6 max-w-md mx-auto p-10">
            <div className="mx-auto w-20 h-20 rounded-full bg-rose-500/10 flex items-center justify-center">
              <AlertCircle className="w-10 h-10 text-rose-400" />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-black text-white">{isRtl ? "خطأ في جلب البيانات" : "Error Fetching Data"}</h2>
              <p className="text-slate-400 font-medium">{isRtl ? "حدث خطأ أثناء الاتصال بقاعدة البيانات. يرجى المحاولة مرة أخرى." : "An error occurred while connecting to the database. Please try again."}</p>
            </div>
            <button
              onClick={() => { setLoading(true); fetchData(); }}
              className="inline-flex items-center gap-3 px-8 py-4 bg-blue-600 text-white font-black rounded-2xl hover:bg-blue-700 transition-all active:scale-95 shadow-xl"
            >
              <RefreshCw size={20} />
              {isRtl ? "إعادة المحاولة" : "Retry"}
            </button>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen pb-20" dir={isRtl ? "rtl" : "ltr"}>
        <DeleteNotification
          notification={notification}
          onClose={hideNotification}
          cancelLabel={tCommon("cancel")}
          deleteLabel={tCommon("delete")}
          okLabel={tCommon("ok")}
          isRtl={isRtl}
        />

        <div className="w-full px-2 pt-6 pb-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-gradient-to-br from-slate-800 via-slate-700 to-slate-600 rounded-[3rem] shadow-2xl border border-slate-500/30 overflow-hidden"
        >
          <div className="h-2 w-full bg-gradient-to-r from-blue-500 via-indigo-500 via-purple-500 via-emerald-500 to-blue-500" />

          <div className="p-6 md:p-10 space-y-6">
            {/* ── Header ── */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 }}
              className="bg-white/5 backdrop-blur-xl p-8 rounded-[2rem] border border-white/10 shadow-xl relative overflow-hidden"
            >
              <div className="absolute -bottom-8 -right-8 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute -top-8 -left-8 w-40 h-40 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
              <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-8 relative z-10">
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-300 mb-3">
                    <Link href="/dashboard" className="hover:text-blue-400 transition-colors">{isRtl ? 'لوحة التحكم' : 'Dashboard'}</Link>
                    <ExternalLink size={12} className="text-slate-500 rotate-90" />
                    <Link href="/financial-vouchers" className="hover:text-blue-400 transition-colors">{isRtl ? 'السندات المالية' : 'Financial Vouchers'}</Link>
                    <ExternalLink size={12} className="text-slate-500 rotate-90" />
                    <span className="text-blue-400">{t("title")}</span>
                  </div>
                  <div className="flex items-center gap-5">
                    <div className="h-16 w-16 rounded-[1.25rem] bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/25 flex-shrink-0">
                      <Receipt size={32} strokeWidth={2.5} className="text-white" />
                    </div>
                    <div>
                      <h1 className="text-3xl md:text-4xl font-black text-white tracking-tight mb-1">{t("title")}</h1>
                      <div className="flex flex-wrap items-center gap-3">
                        <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold border border-blue-500/30">
                          <Sparkles size={12} className="animate-pulse" />
                          {t("subtitle")}
                        </span>
                        <p className="text-slate-400 text-sm font-semibold">{t("description")}</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-3 mt-4">
                  <button
                    onClick={() => { setShowForm(!showForm); if (showForm) resetForm(); }}
                    className={cn(
                      "flex items-center gap-2.5 px-6 py-3 font-black text-sm rounded-2xl transition-all shadow-lg",
                      showForm ? "bg-white/10 text-white border border-white/20 hover:bg-white/20" : "bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:from-blue-500 hover:to-indigo-500 shadow-blue-500/25"
                    )}
                  >
                    {showForm ? <X size={18} /> : <Plus size={18} />}
                    {showForm ? t("cancelForm") : t("addNew")}
                  </button>
                  <button
                    onClick={fetchData}
                    className="flex items-center gap-2 px-4 py-3 bg-white/5 text-white/70 font-bold text-sm rounded-2xl border border-white/10 hover:bg-white/10 hover:text-white transition-all"
                  >
                    <RefreshCw size={16} className={cn("text-blue-400", loading ? "animate-spin" : "")} />
                    {t("refreshData")}
                  </button>
                </div>
              </div>

              {/* Summary Stats */}
              <div className="grid grid-cols-2 gap-4">
                <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-500 to-indigo-600 p-5 shadow-xl shadow-blue-500/25">
                  <div className="p-2 bg-white/10 rounded-xl border border-white/10 w-fit mb-3"><Receipt className="w-5 h-5 text-white" /></div>
                  <p className="text-white/70 text-[10px] font-black uppercase tracking-widest">{t("stats.count")}</p>
                  <p className="text-3xl font-black text-white mt-1">{vouchers.length}</p>
                  <p className="text-white/50 text-[10px] font-black mt-0.5">{t("stats.voucherLabel")}</p>
                  <div className="absolute -bottom-4 -left-4 w-20 h-20 bg-white/10 rounded-full blur-2xl" />
                </div>
                <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-600 p-5 shadow-xl shadow-emerald-500/25">
                  <div className="p-2 bg-white/10 rounded-xl border border-white/10 w-fit mb-3"><TrendingUp className="w-5 h-5 text-white" /></div>
                  <p className="text-white/70 text-[10px] font-black uppercase tracking-widest">{t("stats.nextNumber")}</p>
                  <p className="text-2xl font-black text-white tracking-tight">{receiptNumber}</p>
                  <p className="text-emerald-400/60 text-[10px] font-black mt-1">{t("stats.sequential")}</p>
                  <div className="absolute -bottom-4 -left-4 w-20 h-20 bg-white/10 rounded-full blur-2xl" />
                </div>
              </div>
            </motion.div>

          <AnimatePresence>
            {showForm && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                  <div className="bg-white/5 backdrop-blur-xl rounded-[2rem] border border-white/10 overflow-hidden shadow-2xl">
                      <div className="p-8 border-b border-white/10 bg-white/5">
                          <div className="flex items-center gap-4">
                              <div className="p-3 bg-blue-500/20 rounded-2xl text-blue-400">
                                  <PlusCircle className="w-8 h-8" />
                              </div>
                              <div>
                                  <h2 className="text-2xl font-black text-white">
                                      {editingId ? t("form.editTitle") : t("form.addTitle")}
                                  </h2>
                                  <p className="text-slate-400 font-bold tracking-wide">{t("form.fillData")}</p>
                              </div>
                          </div>
                      </div>
  
                      <form onSubmit={handleSubmit} className="p-8 space-y-8">
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                              <div className="space-y-2">
                                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mr-2">{t("form.date")}</label>
                                  <div className="relative">
                                      <Calendar className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                                      <input
                                          type="date"
                                          value={form.receipt_date}
                                          onChange={(e) => setForm({ ...form, receipt_date: e.target.value })}
                                          className="w-full pr-12 pl-4 py-3 bg-white/5 border border-white/10 rounded-2xl text-white font-bold focus:bg-white/10 focus:border-blue-500 outline-none transition-all"
                                          required
                                      />
                                  </div>
                              </div>
                              <div className="space-y-2 md:col-span-2">
                                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mr-2">{t("form.receivedFrom")}</label>
                                  <div className="relative">
                                      <User className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                                      <input
                                          type="text"
                                          value={form.received_from}
                                          onChange={(e) => setForm({ ...form, received_from: e.target.value })}
                                          placeholder={t("form.receivedFromPlaceholder")}
                                          className="w-full pr-12 pl-4 py-3 bg-white/5 border border-white/10 rounded-2xl text-white font-bold focus:bg-white/10 focus:border-blue-500 outline-none transition-all"
                                          required
                                      />
                                  </div>
                              </div>
                          </div>
  
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                              <div className="space-y-2">
                                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mr-2">{t("form.method")}</label>
                                  <div className="relative">
                                      <CreditCard className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                                      <select
                                          value={form.payment_method}
                                          onChange={(e) => setForm({ ...form, payment_method: e.target.value })}
                                          className="w-full pr-12 pl-4 py-3 bg-white/5 border border-white/10 rounded-2xl text-white font-bold focus:bg-white/10 focus:border-blue-500 outline-none transition-all appearance-none"
                                      >
                                          {paymentMethods.map(m => <option key={m.value} value={m.value} className="bg-slate-800">{m.label}</option>)}
                                      </select>
                                  </div>
                              </div>
                              <div className="space-y-2">
                                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mr-2">{t("form.amount")}</label>
                                  <div className="relative">
                                      <DollarSign className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                                      <input
                                          type="number"
                                          step="0.01"
                                          value={form.amount}
                                          onChange={(e) => setForm({ ...form, amount: e.target.value })}
                                          placeholder="0.00"
                                          className="w-full pr-12 pl-4 py-3 bg-white/5 border border-white/10 rounded-2xl text-white font-bold focus:bg-white/10 focus:border-blue-500 outline-none transition-all"
                                          required
                                      />
                                  </div>
                              </div>
                              <div className="space-y-2">
                                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mr-2">{t("form.taxRate")}</label>
                                  <div className="relative">
                                      <Percent className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                                      <input
                                          type="number"
                                          value={form.tax_rate}
                                          onChange={(e) => setForm({ ...form, tax_rate: e.target.value })}
                                          className="w-full pr-12 pl-4 py-3 bg-white/5 border border-white/10 rounded-2xl text-white font-bold focus:bg-white/10 focus:border-blue-500 outline-none transition-all"
                                      />
                                  </div>
                              </div>
                          </div>
  
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6 bg-white/5 rounded-3xl border border-white/5">
                              <div className="space-y-2">
                                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mr-2">{t("form.taxValue")}</label>
                                  <input
                                      type="text"
                                      value={form.tax_value}
                                      readOnly
                                      className="w-full px-6 py-3 bg-white/5 border border-white/10 rounded-2xl text-amber-400 font-black cursor-not-allowed"
                                  />
                              </div>
                              <div className="space-y-2">
                                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mr-2">{t("form.total")}</label>
                                  <input
                                      type="text"
                                      value={form.total_amount}
                                      readOnly
                                      className="w-full px-6 py-3 bg-blue-500/20 border border-blue-500/30 rounded-2xl text-blue-400 font-black cursor-not-allowed"
                                  />
                              </div>
                          </div>
  
                          <div className="space-y-2">
                              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mr-2">{t("form.description")}</label>
                              <textarea
                                  value={form.description}
                                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                                  rows={3}
                                  placeholder={t("form.descriptionPlaceholder")}
                                  className="w-full px-6 py-4 bg-white/5 border border-white/10 rounded-2xl text-white font-medium focus:bg-white/10 focus:border-blue-500 outline-none transition-all resize-none"
                              />
                          </div>
  
                          <div className="flex justify-end gap-4">
                              <button
                                  type="button"
                                  onClick={resetForm}
                                  className="px-10 py-4 bg-white/5 text-white font-black rounded-2xl border border-white/10 hover:bg-white/10 transition-all active:scale-95"
                              >
                                  {t("form.cancel")}
                              </button>
                              <button
                                  type="submit"
                                  disabled={submitting}
                                  className="flex items-center gap-3 px-10 py-4 bg-teal-500 text-white font-black rounded-2xl shadow-xl shadow-teal-500/20 hover:bg-teal-600 transition-all active:scale-95 disabled:opacity-50"
                              >
                                  {submitting ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
                                  {editingId ? t("form.editSave") : t("form.save")}
                              </button>
                          </div>
                      </form>
                  </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Divider */}
          <div className="border-t border-white/10" />

            {/* Search & Table Section */}
            <div className="space-y-6">
              <div className="bg-white/5 backdrop-blur-xl rounded-3xl p-6 border border-white/10 flex flex-col md:flex-row gap-4 items-center justify-between">
                  <div className="relative w-full md:w-96">
                  <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                  <input
                      type="text"
                      placeholder={t("searchPlaceholder")}
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pr-12 pl-4 py-3 bg-white/10 border border-white/10 rounded-2xl text-white font-medium focus:bg-white/20 focus:border-blue-500/50 outline-none transition-all placeholder:text-slate-500"
                  />
                  </div>
                  <div className="flex gap-3 w-full md:w-auto">
                        <button className="flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-blue-500/20 text-blue-300 font-bold rounded-2xl border border-blue-500/30 hover:bg-blue-500/30 transition-all">
                            <FileSpreadsheet size={18} />
                            {tSales("exportData")}
                        </button>
                    </div>
                </div>
    
                <div className="bg-white/5 backdrop-blur-xl rounded-[2rem] border border-white/10 overflow-hidden shadow-2xl">
                    <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-8 py-5 flex items-center justify-between">
                        <div className="flex items-center gap-3 text-white">
                            <div className="p-2 bg-white/20 rounded-xl backdrop-blur-xl border border-white/10">
                                <Receipt className="w-5 h-5" strokeWidth={2.5} />
                            </div>
                            <h3 className="font-black text-lg">{t("table.title")}</h3>
                        </div>
                        <span className="bg-white/20 backdrop-blur-xl px-5 py-1.5 rounded-xl text-sm font-black text-white border border-white/20">
                            {t("table.countLabel", { count: filteredVouchers.length })}
                        </span>
                    </div>
    
                    <div className="overflow-x-auto">
                        <table className="w-full text-right">
                            <thead>
                                <tr className="bg-white/5 border-b border-white/5">
                                    <th className="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">{t("table.no")}</th>
                                    <th className="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">{t("table.date")}</th>
                                    <th className="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">{t("table.from")}</th>
                                    <th className="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">{t("table.method")}</th>
                                    <th className="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">{t("table.total")}</th>
                                    <th className="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">{t("table.actions")}</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-white/5">
                                {filteredVouchers.length > 0 ? (
                                    filteredVouchers.map((voucher, idx) => (
                                        <motion.tr 
                                            key={voucher.id}
                                            initial={{ opacity: 0, x: -10 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            transition={{ delay: 0.05 * idx }}
                                            className="hover:bg-white/5 transition-colors group"
                                        >
                                            <td className="px-6 py-5">
                                                <span className="px-3 py-1.5 bg-blue-500/10 text-blue-400 rounded-lg text-xs font-black border border-blue-500/20">
                                                    {voucher.receipt_number}
                                                </span>
                                            </td>
                                            <td className="px-6 py-5">
                                                <div className="flex items-center gap-2 text-xs text-slate-400 font-bold">
                                                    <Calendar size={14} className="text-slate-500" />
                                                    {voucher.receipt_date}
                                                </div>
                                            </td>
                                            <td className="px-6 py-5">
                                                <div className="flex items-center gap-3">
                                                    <div className="h-9 w-9 rounded-xl bg-white/5 flex items-center justify-center text-slate-400 group-hover:bg-blue-500/20 group-hover:text-blue-400 transition-all">
                                                        <User size={16} />
                                                    </div>
                                                    <span className="font-bold text-sm text-slate-200 truncate max-w-[150px]">{voucher.received_from}</span>
                                                </div>
                                            </td>
                                            <td className="px-6 py-5 text-center">
                                                <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-purple-500/10 text-purple-400 text-[10px] font-black rounded-full border border-purple-500/20">
                                                    {voucher.payment_method}
                                                </span>
                                            </td>
                                            <td className="px-6 py-5">
                                                <div className="flex items-baseline gap-1 text-emerald-400">
                                                    <span className="text-lg font-black">{Number(voucher.total_amount).toLocaleString()}</span>
                                                    <span className="text-[10px] font-bold text-emerald-400/50 uppercase">{tFinancial("currency")}</span>
                                                </div>
                                            </td>
                                            <td className="px-6 py-5">
                                                <div className="flex items-center justify-center gap-2">
                                                    <Link href={`/receipt-vouchers/${voucher.id}`}>
                                                      <button 
                                                          className="h-9 w-9 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center hover:bg-blue-500 hover:text-white transition-all shadow-lg active:scale-95"
                                                          title={tCommon("view")}
                                                      >
                                                          <Eye size={16} />
                                                      </button>
                                                    </Link>
                                                    <button 
                                                        onClick={() => handleEdit(voucher)}
                                                        className="h-9 w-9 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center hover:bg-amber-500 hover:text-white transition-all shadow-lg active:scale-95"
                                                        title={tCommon("edit")}
                                                    >
                                                        <Edit3 size={16} />
                                                    </button>
                                                    <Link href={`/receipt-vouchers/${voucher.id}?action=email`}>
                                                      <button 
                                                          className="h-9 w-9 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center hover:bg-teal-500 hover:text-white transition-all shadow-lg active:scale-95"
                                                          title={isRtl ? "إرسال بريد" : "Send Email"}
                                                      >
                                                          <Mail size={16} />
                                                      </button>
                                                    </Link>
                                                    <Link href={`/receipt-vouchers/${voucher.id}?action=print`}>
                                                      <button 
                                                          className="h-9 w-9 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center hover:bg-purple-500 hover:text-white transition-all shadow-lg active:scale-95"
                                                          title={isRtl ? "طباعة" : "Print"}
                                                      >
                                                          <Printer size={16} />
                                                      </button>
                                                    </Link>
                                                    <button 
                                                        onClick={() => handleDelete(voucher.id, voucher.receipt_number)}
                                                        disabled={deleteLoading === voucher.id}
                                                        className="h-9 w-9 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center hover:bg-rose-500 hover:text-white transition-all shadow-lg active:scale-95 disabled:opacity-50"
                                                        title={tCommon("delete")}
                                                    >
                                                        {deleteLoading === voucher.id ? <Loader2 size={16} className="animate-spin" /> : <Trash2 size={16} />}
                                                    </button>
                                                </div>
                                            </td>
                                        </motion.tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan={6} className="px-6 py-20 text-center">
                                            <div className="flex flex-col items-center gap-4 opacity-40">
                                                <Receipt size={64} className="text-slate-400" />
                                                <div className="space-y-1">
                                                    <p className="text-xl font-black text-slate-300">{t("noVouchers.title")}</p>
                                                    <p className="text-sm font-medium text-slate-500">{t("noVouchers.desc")}</p>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
              </div>

            {/* Footer */}
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-[11px] font-black text-white/30 uppercase tracking-widest pt-6 border-t border-white/10">
              <div className="flex items-center gap-2">
                <Sparkles size={12} className="text-blue-400" />
                <span>{tFinancial("systemTitle", { name: "Logistics Hub" })} - {t("subtitle")}</span>
              </div>
              <span className="bg-white/5 px-3 py-1 rounded-lg border border-white/10">{tFinancial("allRightsReserved", { year: new Date().getFullYear() })}</span>
            </div>
          </div>
        </motion.div>
        </div>

        <AnimatePresence>
            {showSuccess && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8, y: 50 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.8, y: 50 }}
                className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[101] bg-emerald-600 text-white px-8 py-4 rounded-[2rem] shadow-2xl flex items-center gap-4 font-black"
              >
                <CheckCircle size={24} />
                <span>{t("notifications.saveSuccess")}</span>
              </motion.div>
            )}
        </AnimatePresence>
      </div>
    );
  }
  
export function ReceiptVouchersClient({ companyId }: { companyId: string }) {
  const t = useTranslations("common");
  return (
    <Suspense fallback={<div className="flex items-center justify-center min-h-screen">{t("loading")}</div>}>
      <ReceiptVouchersContent companyId={companyId} />
    </Suspense>
  );
}

