import { cookies } from "next/headers";
import { notFound } from "next/navigation";
import { cachedQuery } from "@/lib/db";
import { PayrollViewClient } from "./payroll-view-client";

async function getPayroll(id: string, companyId: number) {
  try {
    const payrolls = await cachedQuery<any>(
      `SELECT p.*, pkg.group_name as package_name, pkg.work_type, pkg.monthly_target, pkg.bonus_after_target
       FROM salary_payrolls p
       LEFT JOIN employee_packages pkg ON p.package_id = pkg.id
       WHERE p.id = ? AND p.company_id = ?`,
      [id, companyId]
    );

    if (payrolls.length === 0) return null;

    const items = await cachedQuery<any>(
      `SELECT * FROM salary_payroll_items WHERE payroll_id = ?`,
      [id]
    );

    let totalNet = 0;
    items.forEach((item: any) => {
      if (item.net_salary >= 0) {
        totalNet += parseFloat(item.net_salary || 0);
      }
    });

    return { ...payrolls[0], items, total_net: totalNet };
  } catch (error) {
    console.error("Error fetching payroll:", error);
    return null;
  }
}

async function getCompany(companyId: number) {
  try {
    const companies = await cachedQuery<any>(
      `SELECT name, vat_number, short_address FROM companies WHERE id = ?`,
      [companyId]
    );
    return companies[0] || { name: 'اسم الشركة', vat_number: 'غير محدد', short_address: 'غير محدد' };
  } catch (error) {
    return { name: 'اسم الشركة', vat_number: 'غير محدد', short_address: 'غير محدد' };
  }
}

export default async function PayrollViewPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const cookieStore = await cookies();
  const sessionCookie = cookieStore.get("auth_session");
  const session = JSON.parse(sessionCookie?.value || "{}");
  
  const companyId = session.company_id;

  if (!companyId) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-gray-500">جاري التحميل...</p>
      </div>
    );
  }

  const [payroll, company] = await Promise.all([
    getPayroll(id, companyId),
    getCompany(companyId)
  ]);

  if (!payroll) {
    notFound();
  }

  return <PayrollViewClient payroll={payroll} company={company} companyId={companyId} />;
}
