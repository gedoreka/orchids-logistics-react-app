"use client";

import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";

import { 
  Car, 
  Settings, 
  Wrench, 
  Plus, 
  Search, 
  AlertTriangle, 
  Box, 
  Clock, 
  History, 
  ChevronRight, 
  Edit, 
  Trash2, 
  Printer, 
  Filter,
  Package,
  Shield,
  Calendar,
  User,
  MoreVertical,
  CheckCircle2,
  X,
  RefreshCcw,
  Tag,
  FileText,
  Calculator,
  LayoutDashboard,
  Truck,
  Layers,
  FileCheck,
  Sparkles,
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  PlusCircle,
  ShieldCheck,
  Gauge,
  Mail,
  Send,
  Eye,
  Loader2
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter
} from "@/components/ui/dialog";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

import { Label } from "@/components/ui/label";
import { ChevronsUpDown, Check, Users, Hash, IdCard, Image as ImageIcon } from "lucide-react";
import { addVehicle, addSpare, addSpareCategory, addVehicleCategory, createMaintenanceRequest, deleteVehicle, deleteMaintenanceRequest, getMaintenanceDetails, completeMaintenanceRequest } from "@/lib/actions/fleet";
import { SuccessModal, ErrorModal, DeleteConfirmModal, LoadingModal, NotificationBanner, MaintenanceAlertModal } from "@/components/ui/luxury-notification";
import { ScrollArea } from "@/components/ui/scroll-area";
import { motion, AnimatePresence } from "framer-motion";
import { useReactToPrint } from "react-to-print";
import { cn } from "@/lib/utils";
import { useTranslations, useLocale } from "@/lib/locale-context";

// ------------------------------------------------------------------------------------------------
// Sub-components
// ------------------------------------------------------------------------------------------------

function DashboardStatCard({ title, value, icon, color, desc, alert }: any) {
  const iconMap: any = {
    blue: "bg-gradient-to-br from-blue-500 to-indigo-600 shadow-blue-500/30",
    emerald: "bg-gradient-to-br from-emerald-500 to-teal-600 shadow-emerald-500/30",
    amber: "bg-gradient-to-br from-amber-500 to-orange-600 shadow-amber-500/30",
    rose: "bg-gradient-to-br from-rose-500 to-pink-600 shadow-rose-500/30",
  };
  const glowMap: any = {
    blue: "bg-blue-500/10",
    emerald: "bg-emerald-500/10",
    amber: "bg-amber-500/10",
    rose: "bg-rose-500/10",
  };

  return (
    <motion.div
      whileHover={{ y: -5, scale: 1.02 }}
      className="relative overflow-hidden bg-white/5 backdrop-blur-xl rounded-[2rem] p-6 border border-white/10 shadow-lg transition-all group hover:bg-white/8"
    >
      <div className={cn("absolute top-0 right-0 w-24 h-24 rounded-full -translate-y-10 translate-x-10 blur-2xl pointer-events-none", glowMap[color] || glowMap.blue)} />
      <div className="relative z-10 flex justify-between items-start mb-4">
        <div className={cn("p-3 rounded-2xl shadow-lg group-hover:scale-110 transition-transform", iconMap[color] || iconMap.blue)}>
          {React.cloneElement(icon, { size: 22, className: "text-white" })}
        </div>
        {alert && (
          <span className="flex h-2 w-2 mt-1">
            <span className="animate-ping absolute inline-flex h-2 w-2 rounded-full bg-rose-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
          </span>
        )}
      </div>
      <div className="relative z-10">
        <p className="text-white/50 font-black text-[10px] uppercase tracking-wider mb-1">{title}</p>
        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-black text-white tracking-tight">{value}</span>
          <span className="text-[10px] font-black text-white/30 uppercase">{desc}</span>
        </div>
      </div>
      <div className="absolute -bottom-4 -right-4 opacity-5 group-hover:opacity-10 transition-opacity">
        {React.cloneElement(icon, { size: 80 })}
      </div>
    </motion.div>
  );
}

function AddVehicleCategoryDialog({ companyId, t }: { companyId: number, t: any }) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    const formData = new FormData(e.currentTarget);
    const res = await addVehicleCategory({
      company_id: companyId,
      name: formData.get("name") as string,
      description: formData.get("description") as string,
    });
    setLoading(false);
    if (res.success) {
      setOpen(false);
      setShowSuccess(true);
    } else {
      setShowError(true);
    }
  }

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <button className="flex items-center gap-3 px-6 py-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 text-white font-black text-sm hover:bg-white/20 transition-all shadow-xl active:scale-95">
            <Layers size={18} />
            {t('newVehicleCategory')}
          </button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[425px] rounded-[2.5rem] bg-slate-900 text-white border-white/10">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black">{t('addCategory')}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-6 pt-4">
            <div className="space-y-2">
              <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('categoryName')}</Label>
              <Input name="name" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" required />
            </div>
            <div className="space-y-2">
              <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('description')}</Label>
              <Input name="description" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" />
            </div>
            <Button type="submit" className="w-full h-14 rounded-2xl bg-blue-600 hover:bg-blue-700 font-black text-lg shadow-xl shadow-blue-500/20" disabled={loading}>
              {loading ? t('loading') : t('save')}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
      <SuccessModal open={showSuccess} onClose={() => setShowSuccess(false)} title={t('saveSuccess')} />
      <ErrorModal open={showError} onClose={() => setShowError(false)} title={t('error')} />
    </>
  );
}

function AddCategoryDialog({ companyId, t }: { companyId: number, t: any }) {
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [showSuccess, setShowSuccess] = useState(false);
    const [showError, setShowError] = useState(false);

    async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
      e.preventDefault();
      setLoading(true);
      const formData = new FormData(e.currentTarget);
      const res = await addSpareCategory({
        company_id: companyId,
        name: formData.get("name") as string,
        description: formData.get("description") as string,
      });
      setLoading(false);
      if (res.success) {
        setOpen(false);
        setShowSuccess(true);
      } else {
        setShowError(true);
      }
    }

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <button className="flex items-center gap-3 px-6 py-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 text-white font-black text-sm hover:bg-white/20 transition-all shadow-xl active:scale-95">
            <Tag size={18} />
            {t('newSpareCategory')}
          </button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[425px] rounded-[2.5rem] bg-slate-900 text-white border-white/10">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black">{t('addCategory')}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-6 pt-4">
            <div className="space-y-2">
              <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('categoryName')}</Label>
              <Input name="name" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" required />
            </div>
            <div className="space-y-2">
              <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('description')}</Label>
              <Input name="description" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" />
            </div>
            <Button type="submit" className="w-full h-14 rounded-2xl bg-emerald-600 hover:bg-emerald-700 font-black text-lg shadow-xl shadow-emerald-500/20" disabled={loading}>
              {loading ? t('loading') : t('save')}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
      <SuccessModal open={showSuccess} onClose={() => setShowSuccess(false)} title={t('saveSuccess')} />
      <ErrorModal open={showError} onClose={() => setShowError(false)} title={t('error')} />
    </>
  );
}

// ---- Luxury Searchable Driver Selector (Popover portal, modal=false for Dialog compat) ----
function LuxuryDriverSelector({ employees, value, onChange, t }: { employees: any[]; value: string; onChange: (v: string) => void; t: any }) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const selected = employees.find((e: any) => e.id.toString() === value);

  const filtered = useMemo(() => {
    if (!search.trim()) return employees;
    const q = search.toLowerCase();
    return employees.filter((emp: any) =>
      (emp.name || '').toLowerCase().includes(q) ||
      (emp.iqama_number || '').includes(q) ||
      (emp.user_code || '').includes(q) ||
      (emp.identity_number || '').includes(q)
    );
  }, [employees, search]);

  const grouped = useMemo(() => {
    const map: Record<string, any[]> = {};
    filtered.forEach((emp: any) => {
      const pkg = emp.package_name || t('noPackage') || 'بدون باقة';
      if (!map[pkg]) map[pkg] = [];
      map[pkg].push(emp);
    });
    return map;
  }, [filtered, t]);

  return (
    <Popover open={open} onOpenChange={(v) => { setOpen(v); if (!v) setSearch(""); }} modal={false}>
      <PopoverTrigger asChild>
        <button type="button" className="flex items-center justify-between w-full bg-white/5 border border-white/10 rounded-xl h-12 px-3 text-white text-sm hover:bg-white/10 transition-all">
          {selected ? (
            <div className="flex items-center gap-3 overflow-hidden">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-400 to-blue-500 flex items-center justify-center overflow-hidden flex-shrink-0 ring-2 ring-white/20">
                {selected.personal_photo ? (
                  <img src={selected.personal_photo} alt="" className="w-full h-full object-cover" />
                ) : (
                  <User size={14} className="text-white" />
                )}
              </div>
              <span className="truncate font-bold">{selected.name}</span>
            </div>
          ) : (
            <span className="text-white/40">{t('selectDriver')}</span>
          )}
          <ChevronsUpDown size={16} className="text-white/40 flex-shrink-0" />
        </button>
      </PopoverTrigger>
      <PopoverContent
        align="start"
        sideOffset={8}
        className="w-[340px] p-0 bg-slate-800 border-white/10 rounded-2xl shadow-2xl shadow-black/40"
        onOpenAutoFocus={(e) => e.preventDefault()}
      >
        {/* Search */}
        <div className="px-4 py-3 border-b border-white/10 bg-white/5 rounded-t-2xl flex items-center gap-2">
          <Search size={16} className="text-white/40 flex-shrink-0" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t('searchByNameOrId')}
            className="w-full bg-transparent text-white text-sm placeholder:text-white/30 outline-none"
            autoFocus
          />
        </div>
        {/* Scrollable list */}
        <div className="max-h-[300px] overflow-y-auto overscroll-contain p-1">
          {filtered.length === 0 ? (
            <div className="text-white/40 text-sm text-center py-8">{t('noResults')}</div>
          ) : (
            Object.entries(grouped).map(([pkgName, emps]) => (
              <div key={pkgName}>
                <div className="flex items-center gap-2 px-3 py-2 sticky top-0 bg-slate-800/95 backdrop-blur-sm z-10">
                  <div className="w-5 h-5 rounded-md bg-gradient-to-br from-blue-500/30 to-purple-500/30 flex items-center justify-center">
                    <Users size={10} className="text-blue-300" />
                  </div>
                  <span className="text-[11px] font-black text-blue-300/80 uppercase tracking-wider">{pkgName}</span>
                  <span className="text-[10px] text-white/30 font-bold">({(emps as any[]).length})</span>
                </div>
                {(emps as any[]).map((emp: any) => (
                  <button
                    type="button"
                    key={emp.id}
                    onClick={() => { onChange(emp.id.toString()); setOpen(false); setSearch(""); }}
                    className={cn(
                      "flex items-center gap-3 px-3 py-3 w-full text-start cursor-pointer rounded-xl mx-0 my-0.5 transition-all",
                      value === emp.id.toString() ? "bg-white/10" : "hover:bg-white/5"
                    )}
                  >
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-400/20 to-blue-500/20 flex items-center justify-center overflow-hidden flex-shrink-0 ring-1 ring-white/10">
                      {emp.personal_photo ? (
                        <img src={emp.personal_photo} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <User size={18} className="text-white/40" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm truncate">{emp.name}</span>
                        {emp.job_title && (
                          <span className="text-[9px] px-2 py-0.5 bg-white/5 rounded-full text-white/40 font-bold truncate">{emp.job_title}</span>
                        )}
                      </div>
                      <div className="flex items-center gap-3 mt-1">
                        {emp.iqama_number && (
                          <span className="flex items-center gap-1 text-[10px] text-white/30 font-mono">
                            <IdCard size={9} className="text-white/20" />
                            {emp.iqama_number}
                          </span>
                        )}
                        {emp.user_code && (
                          <span className="flex items-center gap-1 text-[10px] text-white/30 font-mono">
                            <Hash size={9} className="text-white/20" />
                            {emp.user_code}
                          </span>
                        )}
                      </div>
                    </div>
                    {value === emp.id.toString() && (
                      <Check size={16} className="text-emerald-400 flex-shrink-0" />
                    )}
                  </button>
                ))}
              </div>
            ))
        )}
        </div>
      </PopoverContent>
    </Popover>
  );
}

// ---- Luxury Searchable Category Selector (Popover portal, modal=false for Dialog compat) ----
function LuxuryCategorySelector({ categories, value, onChange, placeholder, t }: { categories: any[]; value: string; onChange: (v: string) => void; placeholder: string; t: any }) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const selected = categories.find((c: any) => c.id.toString() === value);

  const filtered = useMemo(() => {
    if (!search.trim()) return categories;
    const q = search.toLowerCase();
    return categories.filter((cat: any) => (cat.name || '').toLowerCase().includes(q));
  }, [categories, search]);

  return (
    <Popover open={open} onOpenChange={(v) => { setOpen(v); if (!v) setSearch(""); }} modal={false}>
      <PopoverTrigger asChild>
        <button type="button" className="flex items-center justify-between w-full bg-white/5 border border-white/10 rounded-xl h-12 px-3 text-white text-sm hover:bg-white/10 transition-all">
          {selected ? (
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center">
                <Layers size={12} className="text-blue-300" />
              </div>
              <span className="font-bold truncate">{selected.name}</span>
            </div>
          ) : (
            <span className="text-white/40">{placeholder}</span>
          )}
          <ChevronsUpDown size={16} className="text-white/40 flex-shrink-0" />
        </button>
      </PopoverTrigger>
      <PopoverContent
        align="start"
        sideOffset={8}
        className="w-[300px] p-0 bg-slate-800 border-white/10 rounded-2xl shadow-2xl shadow-black/40"
        onOpenAutoFocus={(e) => e.preventDefault()}
      >
        <div className="px-4 py-3 border-b border-white/10 bg-white/5 rounded-t-2xl flex items-center gap-2">
          <Search size={16} className="text-white/40 flex-shrink-0" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t('searchCategory')}
            className="w-full bg-transparent text-white text-sm placeholder:text-white/30 outline-none"
            autoFocus
          />
        </div>
        <div className="max-h-[250px] overflow-y-auto overscroll-contain p-1">
          {filtered.length === 0 ? (
            <div className="text-white/40 text-sm text-center py-6">{t('noResults')}</div>
          ) : (
            filtered.map((cat: any) => (
              <button
                type="button"
                key={cat.id}
                onClick={() => { onChange(cat.id.toString()); setOpen(false); setSearch(""); }}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 w-full text-start cursor-pointer rounded-xl mx-0 my-0.5 transition-all",
                  value === cat.id.toString() ? "bg-white/10" : "hover:bg-white/5"
                )}
              >
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500/20 to-indigo-500/20 flex items-center justify-center flex-shrink-0">
                  <Layers size={14} className="text-blue-300" />
                </div>
                <div className="flex-1 min-w-0">
                  <span className="font-bold text-white text-sm">{cat.name}</span>
                  {cat.description && (
                    <p className="text-[10px] text-white/30 truncate">{cat.description}</p>
                  )}
                </div>
                {value === cat.id.toString() && (
                  <Check size={16} className="text-emerald-400 flex-shrink-0" />
                )}
              </button>
            ))
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}

function AddVehicleDialog({ companyId, employees, vehicleCategories, t }: any) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);
  const [selectedDriver, setSelectedDriver] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    const formData = new FormData(e.currentTarget);
    const data: Record<string, any> = {};
    formData.forEach((val, key) => {
      const v = val.toString().trim();
      if (v) data[key] = v;
    });
    if (selectedDriver) data.driver_id = selectedDriver;
    if (selectedCategory) data.category_id = selectedCategory;
    data.company_id = companyId;
    const res = await addVehicle(data);
    setLoading(false);
    if (res.success) {
      setOpen(false);
      setSelectedDriver("");
      setSelectedCategory("");
      setShowSuccess(true);
    } else {
      setShowError(true);
    }
  }

  return (
    <>
      <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) { setSelectedDriver(""); setSelectedCategory(""); } }}>
        <DialogTrigger asChild>
          <button className="flex items-center gap-3 px-6 py-3 bg-emerald-500 text-white font-black text-sm rounded-2xl hover:bg-emerald-600 transition-all shadow-xl active:scale-95">
            <Truck size={18} />
            {t('addVehicle')}
          </button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[600px] rounded-[2.5rem] bg-slate-900 text-white border-white/10 max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-3xl font-black">{t('vehicleData')}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-6 pt-4">
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('plateAr')}</Label>
                <Input name="plate_number_ar" placeholder="أ ب ج 1234" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" required />
              </div>
              <div className="space-y-2">
                <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('plateEn')}</Label>
                <Input name="plate_number_en" placeholder="ABC 1234" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" required />
              </div>
              <div className="space-y-2">
                <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('brand')}</Label>
                <Input name="brand" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" required />
              </div>
              <div className="space-y-2">
                <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('model')}</Label>
                <Input name="model" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" required />
              </div>
              <div className="space-y-2">
                <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('manufactureYear')}</Label>
                <Input name="manufacture_year" type="number" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" required />
              </div>
              <div className="space-y-2">
                <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('currentKm')}</Label>
                <Input name="current_km" type="number" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" required />
              </div>
              <div className="space-y-2">
                <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('category')}</Label>
                <LuxuryCategorySelector categories={vehicleCategories} value={selectedCategory} onChange={setSelectedCategory} placeholder={t('selectCategory')} t={t} />
              </div>
              <div className="space-y-2">
                <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('driver')}</Label>
                <LuxuryDriverSelector employees={employees} value={selectedDriver} onChange={setSelectedDriver} t={t} />
              </div>
            </div>
            <Button type="submit" className="w-full h-14 rounded-2xl bg-emerald-600 hover:bg-emerald-700 font-black text-lg shadow-xl shadow-emerald-500/20" disabled={loading}>
              {loading ? t('loading') : t('addVehicle')}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
      <SuccessModal open={showSuccess} onClose={() => setShowSuccess(false)} title={t('saveSuccess')} />
      <ErrorModal open={showError} onClose={() => setShowError(false)} title={t('error')} />
    </>
  );
}

function AddSpareDialog({ companyId, categories, t }: any) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData.entries());
    const res = await addSpare({ ...data, company_id: companyId });
    setLoading(false);
    if (res.success) {
      setOpen(false);
      setShowSuccess(true);
    } else {
      setShowError(true);
    }
  }

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <button className="flex items-center gap-3 px-6 py-3 bg-blue-500 text-white font-black text-sm rounded-2xl hover:bg-blue-600 transition-all shadow-xl active:scale-95">
            <Box size={18} />
            {t('addInventory')}
          </button>
        </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] rounded-[2.5rem] bg-slate-900 text-white border-white/10">
        <DialogHeader>
          <DialogTitle className="text-2xl font-black">{t('addInventory')}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 pt-4">
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2 col-span-2">
              <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('spareName')}</Label>
              <Input name="name" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" required />
            </div>
            <div className="space-y-2">
              <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('spareCode')}</Label>
              <Input name="code" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" />
            </div>
            <div className="space-y-2">
              <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('category')}</Label>
              <Select name="category_id">
                <SelectTrigger className="bg-white/5 border-white/10 rounded-xl h-12 text-white">
                  <SelectValue placeholder={t('selectCategory')} />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-white/10 text-white">
                  {categories.map((cat: any) => (
                    <SelectItem key={cat.id} value={cat.id.toString()}>{cat.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('quantity')}</Label>
              <Input name="quantity" type="number" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" required />
            </div>
            <div className="space-y-2">
              <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('minQuantity')}</Label>
              <Input name="min_quantity" type="number" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" defaultValue="5" />
            </div>
            <div className="space-y-2">
              <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('costPrice')}</Label>
              <Input name="unit_price" type="number" step="0.01" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" required />
            </div>
            <div className="space-y-2">
              <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('salePrice')}</Label>
              <Input name="sale_price" type="number" step="0.01" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" />
            </div>
          </div>
          <Button type="submit" className="w-full h-14 rounded-2xl bg-blue-600 hover:bg-blue-700 font-black text-lg shadow-xl shadow-blue-500/20" disabled={loading}>
            {loading ? t('loading') : t('save')}
          </Button>
        </form>
        </DialogContent>
      </Dialog>
      <SuccessModal open={showSuccess} onClose={() => setShowSuccess(false)} title={t('saveSuccess')} />
      <ErrorModal open={showError} onClose={() => setShowError(false)} title={t('error')} />
    </>
  );
}

function MaintenanceRequestDialog({ companyId, vehicles, spares, t, companyEmail }: any) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState("");
  const [selectedSpares, setSelectedSpares] = useState<any[]>([]);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const totalCost = selectedSpares.reduce((sum, s) => sum + (s.quantity * s.unit_price), 0);

  function addSpareToRequest(spareId: string) {
    const spare = spares.find((s: any) => s.id.toString() === spareId);
    if (spare && !selectedSpares.find(s => s.id === spare.id)) {
      setSelectedSpares([...selectedSpares, { ...spare, quantity: 1 }]);
    }
  }

  function updateSpareQuantity(id: number, qty: number) {
    setSelectedSpares(selectedSpares.map(s => s.id === id ? { ...s, quantity: Math.max(1, qty) } : s));
  }

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!selectedVehicle) {
      setErrorMsg(t('selectVehicleRequired') || 'يرجى اختيار المركبة');
      setShowError(true);
      return;
    }
    setLoading(true);
    const formData = new FormData(e.currentTarget);
    const data = {
      company_id: companyId,
      vehicle_id: parseInt(selectedVehicle),
      maintenance_person: formData.get("maintenance_person") as string,
      maintenance_date: formData.get("maintenance_date") as string,
      current_km: parseInt(formData.get("current_km") as string) || 0,
      notes: formData.get("notes") as string,
      total_cost: totalCost,
    };

    const res = await createMaintenanceRequest(data, selectedSpares);
    setLoading(false);
    if (res.success) {
      setOpen(false);
      setSelectedVehicle("");
      setSelectedSpares([]);
      setShowSuccess(true);
      // Send confirmation email automatically after creation
      if (res.maintenanceId) {
        fetch('/api/fleet/complete-maintenance', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ maintenanceId: res.maintenanceId, to: companyEmail }),
        }).catch(() => {});
      }
    } else {
      setErrorMsg(t('error'));
      setShowError(true);
    }
  }

  return (
    <>
      <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) { setSelectedVehicle(""); setSelectedSpares([]); } }}>
        <DialogTrigger asChild>
          <button className="flex items-center gap-3 px-6 py-3 bg-amber-500 text-white font-black text-sm rounded-2xl hover:bg-amber-600 transition-all shadow-xl active:scale-95">
            <Wrench size={18} />
            {t('maintenanceOrder')}
          </button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[700px] rounded-[2.5rem] bg-slate-900 text-white border-white/10 max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-3xl font-black">{t('maintenanceOrder')}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-6 pt-4">
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('vehicles')}</Label>
                <Select value={selectedVehicle} onValueChange={setSelectedVehicle}>
                  <SelectTrigger className="bg-white/5 border-white/10 rounded-xl h-12 text-white">
                    <SelectValue placeholder={t('vehicles')} />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-900 border-white/10 text-white z-[200]">
                    {vehicles.map((v: any) => (
                      <SelectItem key={v.id} value={v.id.toString()}>{v.plate_number_ar} ({v.brand})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('technician')}</Label>
                <Input name="maintenance_person" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" required />
              </div>
              <div className="space-y-2">
                <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('date')}</Label>
                <Input name="maintenance_date" type="date" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" defaultValue={new Date().toISOString().split('T')[0]} required />
              </div>
              <div className="space-y-2">
                <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('currentKm')}</Label>
                <Input name="current_km" type="number" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" placeholder="كم" required />
              </div>
            </div>

            <div className="p-6 rounded-3xl bg-white/5 border border-white/10 space-y-4">
              <h4 className="font-black text-white/70 text-sm flex items-center gap-2">
                <Package size={18} className="text-amber-400" /> {t('usedSpares')}
              </h4>
              <Select onValueChange={addSpareToRequest}>
                <SelectTrigger className="bg-white/5 border-white/10 rounded-xl h-12 text-white">
                  <SelectValue placeholder={t('addSpares')} />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-white/10 text-white z-[200]">
                  {spares.map((s: any) => (
                    <SelectItem key={s.id} value={s.id.toString()} disabled={s.quantity <= 0}>
                      {s.name} ({s.quantity} {t('available')})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <ScrollArea className="h-[150px] w-full rounded-2xl border border-white/10 bg-black/20 p-4">
                <AnimatePresence>
                  {selectedSpares.map(s => (
                    <motion.div 
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      key={s.id} 
                      className="flex items-center justify-between p-3 border-b border-white/5 last:border-0"
                    >
                      <div className="flex flex-col">
                        <span className="font-black text-sm text-white">{s.name}</span>
                        <span className="text-[10px] text-white/30 font-mono tracking-widest">{s.code}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Input 
                          type="number" 
                          className="w-16 h-8 text-center bg-white/5 border-white/10 rounded-lg text-white font-black" 
                          value={s.quantity} 
                          onChange={(e) => updateSpareQuantity(s.id, parseInt(e.target.value))}
                        />
                        <button onClick={() => setSelectedSpares(selectedSpares.filter(item => item.id !== s.id))} className="text-rose-400 hover:text-rose-300 p-1">
                          <X size={18} />
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
                {selectedSpares.length === 0 && (
                  <div className="h-full flex items-center justify-center text-white/20 italic text-sm">{t('noSparesSelected')}</div>
                )}
              </ScrollArea>
              
              <div className="flex justify-between items-center bg-emerald-500/10 p-4 rounded-2xl border border-emerald-500/20">
                <span className="font-black text-emerald-400/70 text-sm">{t('totalCost')}</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black text-emerald-400">{totalCost.toLocaleString()}</span>
                  <span className="text-xs font-black text-emerald-400/50 uppercase tracking-widest">{t('sar')}</span>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('notes')}</Label>
              <Input name="notes" className="bg-white/5 border-white/10 rounded-xl h-12 text-white" />
            </div>

            <Button type="submit" className="w-full h-14 rounded-2xl bg-amber-500 hover:bg-amber-600 font-black text-lg shadow-xl shadow-amber-500/20" disabled={loading}>
              {loading ? t('loading') : t('save')}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
      <SuccessModal open={showSuccess} onClose={() => setShowSuccess(false)} title={t('saveSuccess')} />
      <ErrorModal open={showError} onClose={() => { setShowError(false); setErrorMsg(""); }} title={errorMsg || t('error')} />
    </>
  );
}

function DeleteMaintenanceDialog({ id, onDeleted, t }: { id: number, onDeleted: () => void, t: any }) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);

  async function handleDelete() {
    setLoading(true);
    const res = await deleteMaintenanceRequest(id);
    setLoading(false);
    if (res.success) {
      setOpen(false);
      setShowSuccess(true);
      onDeleted();
    } else {
      setShowError(true);
    }
  }

  return (
    <>
      <button 
        onClick={() => setOpen(true)}
        className="h-10 w-10 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center hover:bg-rose-500 hover:text-white transition-all shadow-lg active:scale-95"
      >
        <Trash2 size={18} />
      </button>
      <DeleteConfirmModal
        open={open}
        onClose={() => setOpen(false)}
        onConfirm={handleDelete}
        title={t('confirmDelete')}
        message={t('confirmDelete')}
        loading={loading}
        confirmLabel={t('delete')}
        cancelLabel={t('cancel')}
      />
      <SuccessModal open={showSuccess} onClose={() => setShowSuccess(false)} title={t('saveSuccess')} />
      <ErrorModal open={showError} onClose={() => setShowError(false)} title={t('error')} />
    </>
  );
}

function SlideConfirmButton({ id, onCompleted, t, companyEmail }: { id: number; onCompleted: () => void, t: any, companyEmail?: string }) {
  const [sliderValue, setSliderValue] = useState(0);
  const [loading, setLoading] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);
  const sliderRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);

  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    updateSlider(e.clientX);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging.current) {
      updateSlider(e.clientX);
    }
  };

  const handleMouseUp = async () => {
    if (isDragging.current) {
      isDragging.current = false;
          if (sliderValue >= 95) {
            setLoading(true);
            const res = await completeMaintenanceRequest(id);
            setLoading(false);
            if (res.success) {
              setConfirmed(true);
              setShowSuccess(true);
              onCompleted();
              // Send completion confirmation email
              if (companyEmail) {
                fetch('/api/fleet/complete-maintenance', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ maintenanceId: id, to: companyEmail }),
                }).catch(() => {});
              }
            } else {
              setShowError(true);
              setSliderValue(0);
            }
          } else {
            setSliderValue(0);
          }
        }
      };

      const handleTouchStart = (e: React.TouchEvent) => {
        isDragging.current = true;
        updateSlider(e.touches[0].clientX);
      };

      const handleTouchMove = (e: React.TouchEvent) => {
        if (isDragging.current) {
          updateSlider(e.touches[0].clientX);
        }
      };

      const handleTouchEnd = async () => {
        if (isDragging.current) {
          isDragging.current = false;
          if (sliderValue >= 95) {
            setLoading(true);
            const res = await completeMaintenanceRequest(id);
            setLoading(false);
            if (res.success) {
              setConfirmed(true);
              setShowSuccess(true);
              onCompleted();
              if (companyEmail) {
                fetch('/api/fleet/complete-maintenance', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ maintenanceId: id, to: companyEmail }),
                }).catch(() => {});
              }
            } else {
              setShowError(true);
              setSliderValue(0);
            }
      } else {
        setSliderValue(0);
      }
    }
  };

  const updateSlider = (clientX: number) => {
    if (sliderRef.current) {
      const rect = sliderRef.current.getBoundingClientRect();
      const x = clientX - rect.left;
      const percentage = Math.min(Math.max((x / rect.width) * 100, 0), 100);
      setSliderValue(percentage);
    }
  };

  if (confirmed) {
    return (
      <>
        <div className="h-10 px-4 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center gap-2 font-black text-xs border border-emerald-500/30">
          <CheckCircle2 size={16} />
          {t('completed')}
        </div>
        <SuccessModal open={showSuccess} onClose={() => setShowSuccess(false)} title={t('maintenanceCompleted')} />
      </>
    );
  }

  return (
    <>
      <div
        ref={sliderRef}
        className="relative h-10 w-40 bg-white/5 rounded-xl border border-white/10 overflow-hidden cursor-pointer select-none"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <div
          className={cn(
            "absolute inset-y-0 left-0 transition-all duration-100",
            sliderValue >= 95 ? "bg-emerald-500" : "bg-emerald-500/50"
          )}
          style={{ width: `${sliderValue}%` }}
        />
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          {loading ? (
            <Loader2 size={16} className="animate-spin text-white" />
          ) : (
            <span className={cn(
              "text-[10px] font-black uppercase tracking-wider transition-colors",
              sliderValue >= 95 ? "text-white" : "text-white/50"
            )}>
              {sliderValue >= 95 ? t('releaseConfirm') : t('slideConfirm') + " ←"}
            </span>
          )}
        </div>
        <motion.div
          className="absolute top-1 bottom-1 w-8 bg-white rounded-lg shadow-lg flex items-center justify-center"
          style={{ left: `calc(${sliderValue}% - ${sliderValue > 5 ? 16 : 4}px)` }}
          animate={{ scale: isDragging.current ? 1.1 : 1 }}
        >
          <ChevronRight size={16} className="text-emerald-500" />
        </motion.div>
      </div>
      <SuccessModal open={showSuccess} onClose={() => setShowSuccess(false)} title={t('maintenanceCompleted')} />
      <ErrorModal open={showError} onClose={() => setShowError(false)} title={t('error')} />
    </>
  );
}

const MaintenanceReceipt = React.forwardRef<HTMLDivElement, { data: any, details: any[], companyName: string, t: any }>(({ data, details, companyName, t }, ref) => {
  const taxRate = 0.15;
  const subtotal = Number(data?.total_cost || 0);
  const taxAmount = subtotal * taxRate;
  const grandTotal = subtotal + taxAmount;

  return (
    <div ref={ref}>
      {!data ? null : (
        <div className="p-16 bg-white min-h-[1100px] relative font-sans text-slate-900" dir="rtl">
          {/* Aesthetic Border */}
          <div className="absolute inset-0 border-[16px] border-slate-50 pointer-events-none"></div>
          <div className="absolute top-0 right-0 left-0 h-2 bg-slate-900"></div>
          
          {/* Header Section */}
          <div className="flex justify-between items-start mb-16 relative z-10">
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-slate-900 rounded-2xl flex items-center justify-center text-white shadow-xl">
                  <Wrench size={32} />
                </div>
                <div>
                  <h1 className="text-4xl font-black tracking-tighter text-slate-900">{companyName}</h1>
                  <p className="text-blue-600 font-black text-sm uppercase tracking-widest">Maintenance Division</p>
                </div>
              </div>
            </div>
            <div className="text-left">
              <h2 className="text-5xl font-black text-slate-100 absolute -left-4 -top-6 select-none">{t('invoice')}</h2>
              <div className="relative z-10 space-y-2">
                <div className="bg-slate-900 text-white px-6 py-3 rounded-2xl shadow-2xl">
                  <p className="text-[10px] font-bold opacity-50 uppercase mb-1">Receipt Number</p>
                  <p className="text-2xl font-black tracking-widest">#{data.id.toString().padStart(6, '0')}</p>
                </div>
                <p className="text-slate-400 font-bold text-xs mt-2">تاريخ الإصدار: {new Date().toLocaleDateString('en-GB')}</p>
              </div>
            </div>
          </div>

          {/* Info Grid */}
          <div className="grid grid-cols-2 gap-12 mb-16">
            <div className="p-8 rounded-[2rem] bg-slate-50 border border-slate-100 space-y-6">
              <h3 className="text-xs font-black text-blue-600 uppercase tracking-[0.2em] flex items-center gap-2">
                <Car size={14} /> {t('maintenanceDetails')}
              </h3>
              <div className="grid grid-cols-2 gap-y-6">
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase">{t('plateNumber')}</p>
                  <p className="text-xl font-black text-slate-800">{data.plate_number_ar}</p>
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase">{t('brand')} / {t('model')}</p>
                  <p className="text-lg font-bold text-slate-800">{data.brand} {data.model}</p>
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase">{t('currentMileage')}</p>
                  <p className="text-lg font-black text-slate-800">{data.current_km.toLocaleString()} <small className="text-[10px] opacity-50">KM</small></p>
                </div>
              </div>
            </div>

            <div className="p-8 rounded-[2rem] bg-slate-50 border border-slate-100 space-y-6">
              <h3 className="text-xs font-black text-amber-600 uppercase tracking-[0.2em] flex items-center gap-2">
                <History size={14} /> {t('maintenanceRegistry')}
              </h3>
              <div className="grid grid-cols-2 gap-y-6">
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase">{t('technician')}</p>
                  <p className="text-lg font-bold text-slate-800">{data.maintenance_person}</p>
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase">{t('date')}</p>
                  <p className="text-lg font-bold text-slate-800">{new Date(data.maintenance_date).toLocaleDateString('en-GB')}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-[10px] font-black text-slate-400 uppercase">{t('notes')}</p>
                  <p className="text-sm font-medium text-slate-600 italic leading-relaxed">{data.notes || t('noSparesSelected')}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Spares Table */}
          <div className="mb-16">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] mb-6 mr-4 flex items-center gap-2">
              <Package size={14} /> {t('usedSpares')}
            </h3>
            <div className="rounded-[2rem] border border-slate-100 overflow-hidden shadow-sm">
              <table className="w-full">
                <thead>
                  <tr className="bg-slate-900 text-white">
                    <th className="py-5 px-8 text-right font-black text-xs uppercase tracking-wider">{t('spareName')} / {t('description')}</th>
                    <th className="py-5 px-4 text-center font-black text-xs uppercase tracking-wider">{t('quantity')}</th>
                    <th className="py-5 px-4 text-center font-black text-xs uppercase tracking-wider">{t('costPrice')}</th>
                    <th className="py-5 px-8 text-left font-black text-xs uppercase tracking-wider">{t('totalCost')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {details && details.length > 0 ? (
                    details.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-50 transition-colors">
                        <td className="py-6 px-8">
                          <div className="flex flex-col">
                            <span className="font-black text-slate-800">{item.spare_name}</span>
                            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">{item.spare_code}</span>
                          </div>
                        </td>
                        <td className="py-6 px-4 text-center font-black text-slate-600">{item.quantity_used}</td>
                        <td className="py-6 px-4 text-center font-bold text-slate-600">{Number(item.unit_price).toFixed(2)}</td>
                        <td className="py-6 px-8 text-left font-black text-slate-900">{Number(item.total_price).toFixed(2)} <small className="text-[8px] opacity-30">{t('sar')}</small></td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td className="py-10 px-8">
                        <div className="flex flex-col">
                          <span className="font-black text-slate-800">{t('maintenanceDetails')}</span>
                          <span className="text-[10px] font-bold text-slate-400">{t('disclaimerText')}</span>
                        </div>
                      </td>
                      <td className="py-10 px-4 text-center font-black text-slate-600">1</td>
                      <td className="py-10 px-4 text-center font-bold text-slate-600">{subtotal.toFixed(2)}</td>
                      <td className="py-10 px-8 text-left font-black text-slate-900">{subtotal.toFixed(2)} <small className="text-[8px] opacity-30">{t('sar')}</small></td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Summary & Totals */}
          <div className="flex justify-between items-end mb-24">
            <div className="w-1/2 space-y-6">
              <div className="p-6 rounded-2xl bg-blue-50/50 border border-blue-100/50">
                <h4 className="text-[10px] font-black text-blue-600 uppercase tracking-widest mb-2">{t('disclaimer')}</h4>
                <p className="text-[10px] leading-relaxed text-blue-800 font-medium">{t('disclaimerText')}</p>
              </div>
            </div>

            <div className="w-80 space-y-4">
              <div className="flex justify-between items-center px-4">
                <span className="text-xs font-black text-slate-400 uppercase tracking-widest">{t('subtotal')}</span>
                <span className="text-lg font-bold text-slate-700">{subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center px-4">
                <span className="text-xs font-black text-slate-400 uppercase tracking-widest">{t('vat')} (15%)</span>
                <span className="text-lg font-bold text-slate-700">{taxAmount.toFixed(2)}</span>
              </div>
              <div className="h-px bg-slate-100 mx-4"></div>
              <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-xl flex justify-between items-center">
                <div className="flex flex-col">
                  <span className="text-[10px] font-black opacity-50 uppercase tracking-widest">{t('totalAmount')}</span>
                  <span className="text-xs font-bold">TOTAL AMOUNT</span>
                </div>
                <div className="flex flex-col items-end">
                  <span className="text-3xl font-black">{grandTotal.toFixed(2)}</span>
                  <span className="text-[10px] font-black opacity-50">{t('sar')} / ريال سعودي</span>
                </div>
              </div>
            </div>
          </div>

          {/* Footer Signatures */}
          <div className="grid grid-cols-3 gap-16 text-center border-t border-slate-100 pt-16">
            <div className="space-y-6">
              <p className="text-xs font-black text-slate-400 uppercase tracking-widest">{t('techApproval')}</p>
              <div className="h-20 flex items-center justify-center italic text-slate-300 font-serif border-b border-dashed border-slate-200">
                Technical Approval
              </div>
            </div>
            <div className="space-y-6">
              <p className="text-xs font-black text-slate-400 uppercase tracking-widest">{t('receiverSignature')}</p>
              <div className="h-20 border-b border-dashed border-slate-200 flex items-center justify-center">
                <User size={24} className="opacity-10" />
              </div>
            </div>
            <div className="relative">
              <p className="text-xs font-black text-slate-400 uppercase tracking-widest relative z-10">{t('officialStamp')}</p>
              <div className="h-20 border-b border-dashed border-slate-200"></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
});

MaintenanceReceipt.displayName = "MaintenanceReceipt";

function ViewPrintEmailDialog({ 
  maintenance, 
  companyId, 
  companyName,
  companyEmail,
  onClose,
  t
}: { 
  maintenance: any; 
  companyId: number; 
  companyName: string;
  companyEmail: string;
  onClose: () => void;
  t: any;
}) {
  const [open, setOpen] = useState(true);
  const [details, setDetails] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [emailMode, setEmailMode] = useState(false);
  const [emailTo, setEmailTo] = useState("");
  const [sendingEmail, setSendingEmail] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const printRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    async function loadDetails() {
      const res = await getMaintenanceDetails(maintenance.id);
      if (res.success) {
        setDetails(res.details || []);
      }
      setLoading(false);
    }
    loadDetails();
  }, [maintenance.id]);

    const handlePrintNow = useCallback(() => {
      if (printRef.current) {
        const printContent = printRef.current.innerHTML;
        const printWindow = window.open('', '_blank', 'width=900,height=700');
        if (printWindow) {
          printWindow.document.write(`
            <!DOCTYPE html>
            <html dir="rtl">
              <head>
                <title>طباعة أمر الصيانة #${maintenance.id}</title>
                <style>
                  * { margin: 0; padding: 0; box-sizing: border-box; }
                  body { font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif; direction: rtl; }
                  @page { size: A4; margin: 0; }
                  @media print {
                    body { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                  }
                </style>
                <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">
              </head>
              <body></body>
            </html>
          `);
          printWindow.document.body.innerHTML = printContent;
          printWindow.document.close();
          printWindow.focus();
          setTimeout(() => {
            printWindow.print();
            printWindow.close();
          }, 500);
        }
      }
    }, [maintenance.id]);

  const handleSendEmail = async () => {
      if (!emailTo.trim()) {
          setErrorMsg(t('emailRequired'));
          setShowError(true);
          return;
        }
      
      setSendingEmail(true);
      try {
        const sparesList = details.length > 0 
          ? details.map(item => `<tr><td style="padding: 12px; border: 1px solid rgba(255,255,255,0.1); color: white; font-weight: 700;">${item.spare_name}</td><td style="padding: 12px; border: 1px solid rgba(255,255,255,0.1); color: white; font-weight: 700; text-align: center;">${item.spare_code || '-'}</td><td style="padding: 12px; border: 1px solid rgba(255,255,255,0.1); color: white; font-weight: 700; text-align: center;">${item.quantity_used}</td></tr>`).join('')
          : `<tr><td colspan="3" style="padding: 12px; border: 1px solid rgba(255,255,255,0.1); color: rgba(255,255,255,0.5); text-align: center;">${t('maintenanceDetails')}</td></tr>`;

        const emailBody = `
            <div dir="rtl" style="font-family: 'Segoe UI', Tahoma, Arial, sans-serif; max-width: 640px; margin: 0 auto; background: #0f172a; border-radius: 24px; overflow: hidden; border: 1px solid rgba(255,255,255,0.05);">
              <div style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); padding: 40px 30px; text-align: center;">
                <div style="width: 60px; height: 60px; background: rgba(255,255,255,0.2); border-radius: 16px; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 16px;">
                  <span style="font-size: 28px;">🔧</span>
                </div>
                <h1 style="margin: 0; font-size: 26px; color: white; font-weight: 900; letter-spacing: -0.5px;">${companyName}</h1>
                <p style="margin: 8px 0 0; color: rgba(255,255,255,0.85); font-size: 14px; font-weight: 600;">${t('maintenanceOrder')} #${maintenance.id.toString().padStart(6, '0')}</p>
              </div>
              
              <div style="padding: 30px;">
                <div style="background: rgba(245,158,11,0.1); border: 1px solid rgba(245,158,11,0.3); border-radius: 16px; padding: 16px 20px; margin-bottom: 24px;">
                  <p style="margin: 0; color: #fbbf24; font-weight: 700; font-size: 13px;">⚠️ ${t('techInstructionsDesc')}</p>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 24px;">
                  <div style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 16px;">
                    <p style="margin: 0 0 4px; color: rgba(255,255,255,0.4); font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px;">${t('plateNumber')}</p>
                    <p style="margin: 0; color: white; font-size: 16px; font-weight: 900;">${maintenance.plate_number_ar}</p>
                  </div>
                  <div style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 16px;">
                    <p style="margin: 0 0 4px; color: rgba(255,255,255,0.4); font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px;">${t('brand')} / ${t('model')}</p>
                    <p style="margin: 0; color: white; font-size: 16px; font-weight: 900;">${maintenance.brand} ${maintenance.model}</p>
                  </div>
                  <div style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 16px;">
                    <p style="margin: 0 0 4px; color: rgba(255,255,255,0.4); font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px;">${t('technician')}</p>
                    <p style="margin: 0; color: white; font-size: 14px; font-weight: 700;">${maintenance.maintenance_person}</p>
                  </div>
                  <div style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 16px;">
                    <p style="margin: 0 0 4px; color: rgba(255,255,255,0.4); font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px;">${t('currentMileage')}</p>
                    <p style="margin: 0; color: white; font-size: 14px; font-weight: 700;">${maintenance.current_km?.toLocaleString()} كم</p>
                  </div>
                </div>
                
                <div style="margin-bottom: 24px;">
                  <h3 style="color: white; font-size: 14px; font-weight: 900; margin: 0 0 12px; padding-bottom: 8px; border-bottom: 1px solid rgba(255,255,255,0.1);">${t('usedSpares')}</h3>
                  <table style="width: 100%; border-collapse: separate; border-spacing: 0 6px;">
                    <tr>
                      <th style="padding: 10px 14px; background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.6); font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; text-align: right; border-radius: 8px 0 0 8px;">${t('spareName')}</th>
                      <th style="padding: 10px 14px; background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.6); font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; text-align: center;">${t('spareCode')}</th>
                      <th style="padding: 10px 14px; background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.6); font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; text-align: center; border-radius: 0 8px 8px 0;">${t('quantity')}</th>
                    </tr>
                    ${sparesList}
                  </table>
                </div>
                
                ${maintenance.notes ? `<div style="background: rgba(59,130,246,0.1); border: 1px solid rgba(59,130,246,0.2); border-radius: 14px; padding: 16px; margin-bottom: 24px;"><p style="margin: 0; color: #93c5fd; font-size: 13px;"><strong style="color: #60a5fa;">📝 ${t('internalNotes')}:</strong> ${maintenance.notes}</p></div>` : ''}
                
                <div style="background: rgba(16,185,129,0.1); border: 2px solid rgba(16,185,129,0.3); border-radius: 16px; padding: 24px; text-align: center; margin-bottom: 24px;">
                  <p style="margin: 0 0 12px; color: #6ee7b7; font-weight: 700; font-size: 14px;">عند الانتهاء من أعمال الصيانة، اضغط الزر أدناه لتأكيد اكتمال العملية</p>
                    <a href="%%CONFIRM_URL_PLACEHOLDER%%" style="display: inline-block; background: linear-gradient(135deg, #10b981, #059669); color: white; text-decoration: none; padding: 16px 48px; border-radius: 16px; font-size: 16px; font-weight: 900; letter-spacing: 0.5px;">✅ تأكيد اكتمال الصيانة</a>
                  <p style="margin: 12px 0 0; color: rgba(255,255,255,0.3); font-size: 11px;">صالح لمدة 72 ساعة من وقت الإرسال</p>
                </div>
              </div>
              
              <div style="padding: 20px 30px; border-top: 1px solid rgba(255,255,255,0.05); text-align: center;">
                <p style="margin: 0; color: rgba(255,255,255,0.3); font-size: 11px;">تم إرسال هذا البريد من نظام ${companyName} لإدارة الأسطول</p>
              </div>
            </div>
          `;

          const response = await fetch('/api/fleet/send-invoice', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              to: emailTo,
              subject: `${t('maintenanceOrder')} #${maintenance.id.toString().padStart(6, '0')} - ${companyName}`,
              html: emailBody,
              maintenanceId: maintenance.id,
            }),
          });

      const result = await response.json();
        if (result.success) {
          setShowSuccess(true);
          setEmailMode(false);
          setEmailTo("");
        } else {
          setErrorMsg(result.error || t('error'));
          setShowError(true);
        }
      } catch {
        setErrorMsg(t('error'));
        setShowError(true);
      } finally {
      setSendingEmail(false);
    }
  };

  const handleClose = () => {
    setOpen(false);
    onClose();
  };

  const taxRate = 0.15;
  const subtotal = Number(maintenance?.total_cost || 0);
  const taxAmount = subtotal * taxRate;
  const grandTotal = subtotal + taxAmount;

    return (
    <>
      <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[900px] max-h-[90vh] rounded-[2rem] bg-slate-900 text-white border-white/10 p-0 overflow-hidden">
        <DialogHeader className="p-6 border-b border-white/10 bg-white/5">
            <DialogTitle className="text-2xl font-black flex items-center gap-3">
              <div className="p-2 bg-amber-500/20 rounded-xl">
                <FileText className="text-amber-400" size={24} />
              </div>
              {t('maintenanceOrder')} #{maintenance.id.toString().padStart(6, '0')}
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex gap-3 p-4 border-b border-white/10 bg-white/5">
          <Button 
            onClick={handlePrintNow}
            className="flex-1 h-12 rounded-xl bg-blue-600 hover:bg-blue-700 font-black gap-2"
          >
            <Printer size={18} />
            {t('print')}
          </Button>
          <Button 
            onClick={() => setEmailMode(!emailMode)}
            variant={emailMode ? "secondary" : "outline"}
            className={cn(
              "flex-1 h-12 rounded-xl font-black gap-2",
              emailMode ? "bg-emerald-600 hover:bg-emerald-700 text-white border-none" : "border-white/20 text-white hover:bg-white/10"
            )}
          >
            <Mail size={18} />
            {t('sendEmail')}
          </Button>
        </div>

        {emailMode && (
          <div className="p-4 border-b border-white/10 bg-emerald-500/5">
            <div className="flex gap-3">
              <Input
                type="email"
                placeholder={t('sendEmail')}
                value={emailTo}
                onChange={(e) => setEmailTo(e.target.value)}
                className="flex-1 bg-white/5 border-white/10 rounded-xl h-12 text-white"
              />
              <Button
                onClick={handleSendEmail}
                disabled={sendingEmail || !emailTo.trim()}
                className="h-12 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-700 font-black gap-2"
              >
                {sendingEmail ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
                {t('sendEmail')}
              </Button>
            </div>
            <div className="flex gap-2 mt-3">
              <button 
                onClick={() => setEmailTo(companyEmail)}
                className="px-3 py-1.5 bg-white/10 rounded-lg text-xs font-bold text-white/70 hover:bg-white/20 transition-all"
              >
                {t('sendEmail')} ({companyEmail || "---"})
              </button>
            </div>
          </div>
        )}

        <ScrollArea className="max-h-[50vh] p-4">
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 size={40} className="animate-spin text-white/30" />
            </div>
          ) : (
            <div ref={printRef} className="bg-white rounded-2xl overflow-hidden">
                <div className="p-12 bg-white min-h-[800px] relative font-sans text-slate-900" dir="rtl">
                  <div className="absolute top-0 right-0 left-0 h-2 bg-amber-500"></div>
                  
                  <div className="flex justify-between items-start mb-12 relative z-10">
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <div className="w-14 h-14 bg-amber-500 rounded-xl flex items-center justify-center text-white shadow-xl">
                          <Wrench size={28} />
                        </div>
                        <div>
                          <h1 className="text-3xl font-black tracking-tight text-slate-900">{companyName}</h1>
                          <p className="text-amber-600 font-black text-sm uppercase tracking-widest">{t('maintenanceOrder')}</p>
                        </div>
                      </div>
                    </div>
                    <div className="text-left">
                      <div className="bg-amber-500 text-white px-5 py-2 rounded-xl shadow-xl">
                        <p className="text-[10px] font-bold opacity-70 uppercase mb-1">رقم الأمر</p>
                        <p className="text-xl font-black tracking-widest">#{maintenance.id.toString().padStart(6, '0')}</p>
                      </div>
                      <p className="text-slate-400 font-bold text-xs mt-2">تاريخ الإصدار: {new Date().toLocaleDateString('en-GB')}</p>
                    </div>
                  </div>

                  <div className="bg-amber-50 border-2 border-amber-200 rounded-2xl p-6 mb-8">
                    <h3 className="text-amber-700 font-black text-lg mb-2 flex items-center gap-2">
                      <AlertTriangle size={20} />
                      {t('techInstructions')}
                    </h3>
                    <p className="text-amber-800 text-sm leading-relaxed">
                      {t('techInstructionsDesc')}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-8 mb-8">
                    <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100 space-y-4">
                      <h3 className="text-xs font-black text-blue-600 uppercase tracking-[0.2em] flex items-center gap-2">
                        <Car size={14} /> {t('maintenanceDetails')}
                      </h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-[10px] font-black text-slate-400 uppercase">{t('plateNumber')}</p>
                          <p className="text-lg font-black text-slate-800">{maintenance.plate_number_ar}</p>
                        </div>
                        <div>
                          <p className="text-[10px] font-black text-slate-400 uppercase">{t('brand')} / {t('model')}</p>
                          <p className="text-base font-bold text-slate-800">{maintenance.brand} {maintenance.model}</p>
                        </div>
                        <div>
                          <p className="text-[10px] font-black text-slate-400 uppercase">{t('currentMileage')}</p>
                          <p className="text-base font-black text-slate-800">{maintenance.current_km?.toLocaleString()} <small className="text-[10px] opacity-50">KM</small></p>
                        </div>
                      </div>
                    </div>

                    <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100 space-y-4">
                      <h3 className="text-xs font-black text-amber-600 uppercase tracking-[0.2em] flex items-center gap-2">
                        <History size={14} /> {t('maintenanceRegistry')}
                      </h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-[10px] font-black text-slate-400 uppercase">{t('technician')}</p>
                          <p className="text-base font-bold text-slate-800">{maintenance.maintenance_person}</p>
                        </div>
                        <div>
                          <p className="text-[10px] font-black text-slate-400 uppercase">{t('date')}</p>
                          <p className="text-base font-bold text-slate-800">{new Date(maintenance.maintenance_date).toLocaleDateString('en-GB')}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mb-8">
                    <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] mb-4 mr-4 flex items-center gap-2">
                      <Package size={14} /> {t('usedSpares')}
                    </h3>
                    <div className="rounded-2xl border border-slate-100 overflow-hidden">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-slate-900 text-white">
                            <th className="py-4 px-6 text-right font-black text-xs uppercase tracking-wider">{t('spareName')} / {t('description')}</th>
                            <th className="py-4 px-4 text-center font-black text-xs uppercase tracking-wider">{t('spareCode')}</th>
                            <th className="py-4 px-4 text-center font-black text-xs uppercase tracking-wider">{t('quantity')}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {details && details.length > 0 ? (
                            details.map((item, idx) => (
                              <tr key={idx} className="hover:bg-slate-50 transition-colors">
                                <td className="py-4 px-6">
                                  <span className="font-black text-slate-800">{item.spare_name}</span>
                                </td>
                                <td className="py-4 px-4 text-center">
                                  <span className="text-xs font-mono text-slate-500 bg-slate-100 px-2 py-1 rounded">{item.spare_code || '-'}</span>
                                </td>
                                <td className="py-4 px-4 text-center font-black text-slate-800">{item.quantity_used}</td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan={3} className="py-6 px-6 text-center text-slate-500">
                                {t('noSparesSelected')}
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {maintenance.notes && (
                    <div className="mb-8 p-6 rounded-2xl bg-blue-50 border border-blue-100">
                      <h3 className="text-xs font-black text-blue-600 uppercase tracking-[0.2em] mb-3 flex items-center gap-2">
                        <FileText size={14} /> {t('internalNotes')}
                      </h3>
                      <p className="text-slate-700 leading-relaxed">{maintenance.notes}</p>
                    </div>
                  )}

                  <div className="grid grid-cols-3 gap-12 text-center border-t border-slate-100 pt-12 mt-8">
                    <div className="space-y-4">
                      <p className="text-xs font-black text-slate-400 uppercase tracking-widest">{t('techApproval')}</p>
                      <div className="h-16 flex items-center justify-center italic text-slate-300 font-serif border-b border-dashed border-slate-200">
                        Manager Signature
                      </div>
                    </div>
                    <div className="space-y-4">
                      <p className="text-xs font-black text-slate-400 uppercase tracking-widest">{t('receiverSignature')}</p>
                      <div className="h-16 border-b border-dashed border-slate-200 flex items-center justify-center">
                        <User size={20} className="opacity-10" />
                      </div>
                    </div>
                    <div className="space-y-4">
                      <p className="text-xs font-black text-slate-400 uppercase tracking-widest">{t('officialStamp')}</p>
                      <div className="h-16 border-b border-dashed border-slate-200"></div>
                    </div>
                  </div>
                </div>
            </div>
          )}
        </ScrollArea>
      </DialogContent>
      </Dialog>
      <SuccessModal open={showSuccess} onClose={() => setShowSuccess(false)} title={t('success')} />
      <ErrorModal open={showError} onClose={() => setShowError(false)} title={errorMsg || t('error')} />
    </>
    );
  }
  
  // ------------------------------------------------------------------------------------------------
  // Main Component
// ------------------------------------------------------------------------------------------------

export function FleetClient({ 
  initialVehicles, 
  initialSpares, 
  categories, 
  vehicleCategories,
  initialMaintenance, 
  employees,
  companyId,
  companyName,
  companyEmail
}: FleetClientProps) {
  const t = useTranslations('fleet');
  const { locale } = useLocale();
  const [vehicles, setVehicles] = useState(initialVehicles);
  const [spares, setSpares] = useState(initialSpares);
  const [maintenance, setMaintenance] = useState(initialMaintenance);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [searchQuery, setSearchQuery] = useState("");
    const [viewingMaintenance, setViewingMaintenance] = useState<any>(null);
    const [deleteVehicleId, setDeleteVehicleId] = useState<number | null>(null);
    const [showDeleteSuccess, setShowDeleteSuccess] = useState(false);
    const [showCompletionBanner, setShowCompletionBanner] = useState(false);
    const [completedMaintenanceInfo, setCompletedMaintenanceInfo] = useState("");
    const [showPendingBanner, setShowPendingBanner] = useState(false);
  
  useEffect(() => { setVehicles(initialVehicles); }, [initialVehicles]);
  useEffect(() => { setSpares(initialSpares); }, [initialSpares]);
  useEffect(() => { setMaintenance(initialMaintenance); }, [initialMaintenance]);

  const totalVehicles = vehicles.length;
  const totalSpares = spares.length;
  const lowStockCount = spares.filter(s => s.quantity <= (s.min_quantity || 0)).length;
  const pendingMaintenance = maintenance.filter(m => m.status === 'pending').length;

    // Show pending maintenance notification when company changes or data updates
  useEffect(() => {
    const currentPending = initialMaintenance.filter(m => m.status === 'pending').length;
    if (currentPending > 0) {
      setShowPendingBanner(true);
    } else {
      setShowPendingBanner(false);
    }
    // Reset completion banner on company switch
    setShowCompletionBanner(false);
  }, [companyId, initialMaintenance]);

  // Poll for confirmed maintenance every 30 seconds (scoped to current company)
  useEffect(() => {
    const pageLoadTime = new Date().toISOString();
    const currentCompanyId = companyId;
    const interval = setInterval(async () => {
      try {
        const res = await fetch(`/api/fleet/check-completed?since=${encodeURIComponent(pageLoadTime)}&company_id=${currentCompanyId}`);
        if (!res.ok) return;
        const data = await res.json();
        if (data.completed && data.completed.length > 0) {
          const latest = data.completed[0];
          const info = `أمر الصيانة #${String(latest.id).padStart(6, '0')} - ${latest.plate_number_ar || ''} (${latest.brand || ''} ${latest.model || ''}) - الفني: ${latest.maintenance_person || '-'}`;
          setCompletedMaintenanceInfo(info);
          setShowCompletionBanner(true);
          // Update local maintenance list status
          setMaintenance(prev => prev.map(m => 
            data.completed.some((c: any) => c.id === m.id) ? { ...m, status: 'completed' } : m
          ));
        }
      } catch { /* silent */ }
    }, 30000);
    return () => clearInterval(interval);
  }, [companyId]);

  const filteredVehicles = vehicles.filter(v => 
    v.plate_number_ar?.includes(searchQuery) || 
    v.brand?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    v.model?.toLowerCase().includes(searchQuery.toLowerCase())
  );

    return (
      <div className="max-w-[98%] mx-auto p-4 md:p-8" dir={locale === 'ar' ? "rtl" : "ltr"}>
        {/* In-App Notification Banner */}
          <MaintenanceAlertModal
            open={showCompletionBanner}
            onClose={() => setShowCompletionBanner(false)}
            title={t('maintenanceCompleted') || "اكتمال أمر الصيانة"}
            message={completedMaintenanceInfo || t('maintenanceCompletedDesc')}
            type="success"
            actionLabel={t('view')}
            onAction={() => {
              setActiveTab("maintenance");
            }}
          />
          {/* Pending Maintenance Alert */}
          <MaintenanceAlertModal
            open={showPendingBanner}
            onClose={() => setShowPendingBanner(false)}
            title={t('pendingMaintenanceAlert') || `طلبات صيانة معلقة (${pendingMaintenance})`}
            message={t('pendingMaintenanceAlertDesc') || `يوجد ${pendingMaintenance} طلب صيانة معلق يتطلب المتابعة والتأكيد`}
            type="warning"
            actionLabel={t('view')}
            onAction={() => {
              setActiveTab("maintenance");
            }}
          />
        {/* Unified Main Card */}
      <div className="relative bg-gradient-to-br from-slate-800 via-slate-700 to-slate-600 rounded-[3rem] shadow-2xl border border-slate-500/30 overflow-hidden flex flex-col p-8 space-y-8">
        <div className="h-1.5 w-full absolute top-0 left-0 bg-gradient-to-r from-blue-500 via-indigo-500 via-purple-500 via-emerald-500 to-blue-500" />
        
        {/* Luxurious Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-slate-900/80 via-slate-800/80 to-slate-900/80 p-10 shadow-2xl border border-white/10"
        >
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-indigo-500 via-purple-500 via-emerald-500 to-blue-500" />

          <div className="relative z-10 space-y-10">
            <div className="flex flex-col lg:flex-row items-center justify-between gap-10">
              <div className="text-center lg:text-right space-y-4">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-md rounded-2xl border border-white/15 mb-2"
                  >
                    <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse" />
                    <span className="text-white/60 font-black text-[10px] uppercase tracking-widest">{t('dashboard')}</span>
                  </motion.div>

                  <h1 className="text-4xl md:text-6xl font-black tracking-tight bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400 bg-clip-text text-transparent">
                    {t('title')}
                  </h1>
                  <p className="text-lg text-white/60 max-w-2xl font-medium leading-relaxed">
                    {t('subtitle', { name: companyName })}
                  </p>

                <div className="flex flex-wrap justify-center lg:justify-start gap-4 mt-8">
                  <AddVehicleDialog companyId={companyId} employees={employees} vehicleCategories={vehicleCategories} t={t} />
                  <AddSpareDialog companyId={companyId} categories={categories} t={t} />
                  <MaintenanceRequestDialog companyId={companyId} vehicles={vehicles} spares={spares} t={t} companyEmail={companyEmail} />
                    <button
                      onClick={() => window.location.reload()}
                      className="flex items-center gap-3 px-6 py-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/15 text-white font-black text-sm hover:bg-white/20 transition-all shadow-xl active:scale-95"
                    >
                      <RefreshCcw size={18} className="text-white/40" />
                      {t('refreshData')}
                    </button>
                  </div>
                </div>

                <div className="flex flex-col gap-4">
                  <div className="flex items-center gap-4">
                    <AddVehicleCategoryDialog companyId={companyId} t={t} />
                    <AddCategoryDialog companyId={companyId} t={t} />
                  </div>
                </div>
              </div>
            </div>

            <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-indigo-500/10 rounded-full blur-[100px] pointer-events-none" />
            <div className="absolute -top-24 -left-24 w-96 h-96 bg-blue-500/10 rounded-full blur-[100px] pointer-events-none" />
        </motion.div>

        <Tabs defaultValue="dashboard" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex items-center justify-center mb-8">
            <TabsList className="bg-white/5 backdrop-blur-xl p-1.5 rounded-2xl border border-white/10 h-16 shadow-xl">
                {[
                  { id: "dashboard", label: t('dashboard'), icon: <LayoutDashboard size={18} className="text-blue-400" /> },
                  { id: "vehicles", label: t('vehicles'), icon: <Car size={18} className="text-emerald-400" /> },
                  { id: "inventory", label: t('inventory'), icon: <Box size={18} className="text-blue-400" /> },
                  { id: "maintenance", label: t('maintenance'), icon: <Wrench size={18} className="text-amber-400" /> },
                  { id: "costs", label: t('costs'), icon: <Calculator size={18} className="text-rose-400" /> }
                ].map((tab) => (
                <TabsTrigger
                  key={tab.id}
                  value={tab.id}
                    className="rounded-xl px-8 h-full data-[state=active]:bg-white/15 data-[state=active]:text-white data-[state=active]:border-white/20 data-[state=active]:shadow-lg font-black text-white/40 transition-all gap-2 border border-transparent"
                >
                  {tab.icon}
                  {tab.label}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          <TabsContent value="dashboard" className="space-y-8">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              <DashboardStatCard title={t('totalFleet')} value={totalVehicles} icon={<Car />} color="blue" desc={t('units.vehicle')} />
              <DashboardStatCard title={t('spareParts')} value={totalSpares} icon={<Box />} color="emerald" desc={t('units.item')} />
              <DashboardStatCard title={t('inventoryAlerts')} value={lowStockCount} icon={<AlertTriangle />} color="amber" desc={t('lowStock')} alert={lowStockCount > 0} />
              <DashboardStatCard title={t('maintenanceRequests')} value={pendingMaintenance} icon={<FileCheck />} color="rose" desc={t('units.request')} />
            </div>

            <div className="grid gap-8 lg:grid-cols-2">
              <Card className="rounded-[2.5rem] bg-white/5 backdrop-blur-xl border-white/10 shadow-2xl overflow-hidden group">
                <CardHeader className="p-8 border-b border-white/10 flex flex-row items-center justify-between bg-white/5">
                  <CardTitle className="text-xl font-black text-white flex items-center gap-3">
                    <div className="p-2 bg-blue-500/20 rounded-xl">
                      <History className="text-blue-400" size={24} />
                    </div>
                    {t('recentMaintenance')}
                  </CardTitle>
                  <ArrowUpRight className="text-white/20 group-hover:text-blue-400 transition-colors" />
                </CardHeader>
                <CardContent className="p-0">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-white/5 hover:bg-transparent">
                        <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('vehicles')}</TableHead>
                        <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('date')}</TableHead>
                        <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('totalCost')}</TableHead>
                        <TableHead className="text-white/60 font-black uppercase text-[10px] text-center">{t('status')}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {maintenance.slice(0, 5).map((m) => (
                        <TableRow key={m.id} className="border-white/5 hover:bg-white/5 transition-colors">
                          <TableCell className="font-black text-white">
                            <span className="px-3 py-1 bg-white/10 rounded-lg border border-white/10">{m.plate_number_ar}</span>
                          </TableCell>
                          <TableCell className="text-white/50 text-xs font-bold">{new Date(m.maintenance_date).toLocaleDateString('en-GB')}</TableCell>
                          <TableCell className="font-black text-emerald-400">
                            {m.total_cost} <small className="opacity-50">{t('sar')}</small>
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge className={cn(
                              "font-black text-[10px] px-3 py-1 rounded-full border",
                              m.status === 'pending' 
                                ? "bg-amber-500/10 text-amber-400 border-amber-500/20" 
                                : "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                            )}>
                              {m.status === 'pending' ? t('pending') : t('completed')}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>

              <Card className="rounded-[2.5rem] bg-white/5 backdrop-blur-xl border-white/10 shadow-2xl overflow-hidden group">
                <CardHeader className="p-8 border-b border-white/10 flex flex-row items-center justify-between bg-white/5">
                  <CardTitle className="text-xl font-black text-white flex items-center gap-3">
                    <div className="p-2 bg-rose-500/20 rounded-xl">
                      <AlertTriangle className="text-rose-400" size={24} />
                    </div>
                    {t('lowStock')}
                  </CardTitle>
                  <TrendingDown className="text-white/20 group-hover:text-rose-400 transition-colors" />
                </CardHeader>
                <CardContent className="p-0">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-white/5 hover:bg-transparent">
                        <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('units.item')}</TableHead>
                        <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('inventory')}</TableHead>
                        <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('minQuantity')}</TableHead>
                        <TableHead className="text-white/60 font-black uppercase text-[10px] text-center">{t('actions')}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {spares.filter(s => s.quantity <= (s.min_quantity || 0)).slice(0, 5).map((s) => (
                        <TableRow key={s.id} className="border-white/5 hover:bg-white/5 transition-colors">
                          <TableCell className="font-black text-white">{s.name}</TableCell>
                          <TableCell>
                            <Badge className="bg-rose-500/20 text-rose-400 border-rose-500/30 font-black">{s.quantity}</Badge>
                          </TableCell>
                          <TableCell className="font-bold text-white/30">{s.min_quantity}</TableCell>
                          <TableCell className="text-center">
                            <button className="p-2 bg-blue-500/20 rounded-xl text-blue-400 hover:bg-blue-500 hover:text-white transition-all">
                              <PlusCircle size={14} />
                            </button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="vehicles">
            <Card className="rounded-[2.5rem] bg-white/5 backdrop-blur-xl border-white/10 shadow-2xl overflow-hidden">
              <CardHeader className="bg-white/5 border-b border-white/10 p-8 flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-emerald-500/20 rounded-2xl">
                    <Car className="text-emerald-400" size={28} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-white">{t('fleetRegistry')}</h3>
                    <p className="text-white/60 text-sm font-medium">{t('fleetRegistryDesc')}</p>
                  </div>
                </div>
                <div className="relative w-full md:w-96">
                  <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-white/20" size={20} />
                  <input
                    type="text"
                    placeholder={t('searchVehicle')}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pr-12 pl-4 py-3 bg-white/5 border border-white/10 rounded-2xl text-white font-medium focus:bg-white/10 focus:border-blue-500/50 outline-none transition-all placeholder:text-white/20"
                  />
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-white/5 border-white/10">
                      <TableHead className="text-white/60 font-black uppercase text-[10px] px-8 py-5">{t('plateNumber')}</TableHead>
                      <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('brand')} & {t('model')}</TableHead>
                      <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('driver')}</TableHead>
                      <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('currentMileage')}</TableHead>
                      <TableHead className="text-white/60 font-black uppercase text-[10px] text-center">{t('status')}</TableHead>
                      <TableHead className="text-white/60 font-black uppercase text-[10px] text-left px-8">{t('actions')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredVehicles.map((v) => (
                      <TableRow key={v.id} className="border-white/5 hover:bg-white/5 transition-all group">
                        <TableCell className="px-8 py-6">
                          <div className="h-12 w-16 border-2 border-white/20 rounded-xl bg-white/5 flex flex-col items-center justify-center font-black group-hover:border-emerald-500/50 transition-colors">
                            <span className="text-xs text-white leading-none">{v.plate_number_ar}</span>
                            <span className="text-[8px] text-white/30 tracking-widest mt-1">{v.plate_number_en}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="font-black text-white group-hover:text-emerald-400 transition-colors">{v.brand}</span>
                            <span className="text-[10px] font-black text-white/30 uppercase tracking-widest">{v.model} - {v.manufacture_year}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="h-8 w-8 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400">
                              <User size={14} />
                            </div>
                            <span className="font-bold text-white/70">{v.driver_name || '---'}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Gauge size={14} className="text-white/20" />
                            <span className="font-black text-white">{v.current_km?.toLocaleString()}</span>
                            <small className="text-[10px] font-black text-white/20 uppercase">KM</small>
                          </div>
                        </TableCell>
                        <TableCell className="text-center">
                          <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 font-black text-[10px] px-3">{locale === 'ar' ? 'نشط' : 'Active'}</Badge>
                        </TableCell>
                        <TableCell className="text-left px-8">
                          <div className="flex justify-end gap-2">
                            <button className="h-9 w-9 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center hover:bg-blue-500 hover:text-white transition-all">
                              <Edit size={16} />
                            </button>
                            <button 
                                onClick={() => setDeleteVehicleId(v.id)}
                                className="h-9 w-9 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center hover:bg-rose-500 hover:text-white transition-all"
                              >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="inventory">
            <div className="grid gap-8 md:grid-cols-4">
              <Card className="rounded-[2.5rem] bg-white/5 backdrop-blur-xl border-white/10 shadow-2xl p-6 h-fit">
                <div className="flex items-center justify-between mb-6 px-2">
                  <h3 className="font-black text-white text-sm flex items-center gap-3">
                    <div className="p-2 bg-blue-500/20 rounded-lg">
                      <Layers size={18} className="text-blue-400" />
                    </div>
                    {t('categories')}
                  </h3>
                  <AddCategoryDialog companyId={companyId} t={t} />
                </div>
                <div className="space-y-2">
                  <button className="w-full flex items-center justify-between px-4 py-3 bg-white/10 text-white rounded-xl font-black text-xs transition-all border border-white/10">
                    <span>{t('all')}</span>
                    <ChevronRight size={14} className="opacity-40" />
                  </button>
                  {categories.map(cat => (
                    <button key={cat.id} className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/5 text-white/50 hover:text-white rounded-xl font-bold text-xs transition-all">
                      <span>{cat.name}</span>
                      <ChevronRight size={14} className="opacity-20" />
                    </button>
                  ))}
                </div>
              </Card>
              
              <Card className="md:col-span-3 rounded-[2.5rem] bg-white/5 backdrop-blur-xl border-white/10 shadow-2xl overflow-hidden">
                <CardHeader className="bg-white/5 border-b border-white/10 p-8 flex flex-row items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-blue-500/20 rounded-2xl">
                      <Box className="text-blue-400" size={28} />
                    </div>
                    <div>
                      <h3 className="text-2xl font-black text-white">{t('inventoryManagement')}</h3>
                      <p className="text-white/60 text-sm font-medium">{t('inventoryManagementDesc')}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-white/5 border-white/10">
                        <TableHead className="text-white/60 font-black uppercase text-[10px] px-8 py-5">{t('spareName')}</TableHead>
                        <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('category')}</TableHead>
                        <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('quantity')}</TableHead>
                        <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('costPrice')}</TableHead>
                        <TableHead className="text-white/60 font-black uppercase text-[10px] text-left px-8">{t('actions')}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {spares.map(s => (
                        <TableRow key={s.id} className="border-white/5 hover:bg-white/5 transition-all group">
                          <TableCell className="px-8 py-6">
                            <div className="flex flex-col">
                              <span className="font-black text-white group-hover:text-blue-400 transition-colors">{s.name}</span>
                              <span className="text-[10px] font-black text-white/20 uppercase tracking-[0.2em]">{s.code}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="border-white/10 text-white/50 text-[10px] font-black px-3">{s.category_name || '---'}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <div className={cn(
                                "w-10 h-10 rounded-xl flex items-center justify-center font-black text-lg",
                                s.quantity <= (s.min_quantity || 0) ? "bg-rose-500/20 text-rose-400 border border-rose-500/20" : "bg-white/10 text-white border border-white/10"
                              )}>
                                {s.quantity}
                              </div>
                              {s.quantity <= (s.min_quantity || 0) && (
                                <Badge className="bg-rose-500 text-white font-black text-[9px] animate-pulse border-none">{t('lowStock')}</Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-baseline gap-1">
                              <span className="text-lg font-black text-white">{s.unit_price}</span>
                              <span className="text-[10px] font-black text-white/30 uppercase">{t('sar')}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-left px-8">
                            <div className="flex justify-end gap-2">
                              <button className="h-9 w-9 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center hover:bg-blue-500 hover:text-white transition-all">
                                <Edit size={16} />
                              </button>
                              <button className="h-9 w-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center hover:bg-emerald-500 hover:text-white transition-all">
                                <PlusCircle size={16} />
                              </button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="maintenance">
            <Card className="rounded-[2.5rem] bg-white/5 backdrop-blur-xl border-white/10 shadow-2xl overflow-hidden">
              <CardHeader className="bg-white/5 border-b border-white/10 p-8 flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-amber-500/20 rounded-2xl">
                    <Wrench className="text-amber-400" size={28} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-white">{t('maintenanceRegistry')}</h3>
                    <p className="text-white/60 text-sm font-medium">{t('maintenanceRegistryDesc')}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <button className="flex items-center gap-2 px-5 py-2.5 bg-white/5 rounded-xl border border-white/10 text-white/50 font-black text-xs hover:bg-white/10 transition-all">
                    <Filter size={16} />
                    {locale === 'ar' ? 'تصفية' : 'Filter'}
                  </button>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-white/5 border-white/10">
                      <TableHead className="text-white/60 font-black uppercase text-[10px] px-8 py-5">{t('maintenanceOrder')}</TableHead>
                      <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('vehicles')}</TableHead>
                      <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('technician')}</TableHead>
                      <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('date')}</TableHead>
                      <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('totalCost')}</TableHead>
                      <TableHead className="text-white/60 font-black uppercase text-[10px] text-center">{t('status')}</TableHead>
                      <TableHead className="text-white/60 font-black uppercase text-[10px] text-left px-8">{t('actions')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {maintenance.map(m => (
                      <TableRow key={m.id} className="border-white/5 hover:bg-white/5 transition-all group">
                        <TableCell className="px-8 py-6">
                          <span className="font-mono text-xs text-white/30 tracking-widest bg-white/5 px-3 py-1.5 rounded-lg border border-white/5 group-hover:text-amber-400 group-hover:border-amber-400/30 transition-all">
                            #{m.id.toString().padStart(6, '0')}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Car size={14} className="text-white/20" />
                            <span className="font-black text-white">{m.plate_number_ar}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="h-8 w-8 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400">
                              <ShieldCheck size={14} />
                            </div>
                            <span className="font-bold text-white/70">{m.maintenance_person}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2 text-xs text-white/60 font-bold">
                            <Calendar size={14} />
                            {new Date(m.maintenance_date).toLocaleDateString('en-GB')}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-baseline gap-1">
                            <span className="text-lg font-black text-emerald-400">{m.total_cost}</span>
                            <span className="text-[10px] font-black text-emerald-400/40 uppercase">{t('sar')}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-center">
                          <Badge className={cn(
                            "font-black text-[10px] px-4 py-1.5 rounded-full border shadow-lg",
                            m.status === 'pending' 
                              ? "bg-amber-500/10 text-amber-400 border-amber-500/20" 
                              : "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                          )}>
                            {m.status === 'pending' ? t('pending') : t('completed')}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-left px-8">
                          <div className="flex justify-end gap-2 items-center">
                            {m.status === 'pending' && (
                              <SlideConfirmButton 
                                id={m.id} 
                                t={t}
                                companyEmail={companyEmail}
                  onCompleted={() => {
                                    setMaintenance(prev => prev.map(item => 
                                      item.id === m.id ? { ...item, status: 'completed' } : item
                                    ));
                                    setCompletedMaintenanceInfo(`${m.maintenance_person || ''} - ${m.maintenance_type || ''}`);
                                    setShowCompletionBanner(true);
                                    setTimeout(() => setShowCompletionBanner(false), 8000);
                                  }}
                              />
                            )}
                            <button 
                              onClick={() => setViewingMaintenance(m)}
                              className="h-9 w-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center hover:bg-emerald-500 hover:text-white transition-all shadow-lg"
                              title={t('view')}
                            >
                              <Eye size={16} />
                            </button>
                            <DeleteMaintenanceDialog id={m.id} t={t} onDeleted={() => {
                              setMaintenance(prev => prev.filter(item => item.id !== m.id));
                            }} />
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="costs">
            <div className="space-y-8">
              <div className="grid gap-6 md:grid-cols-4">
                <DashboardStatCard 
                  title={t('totalMaintenanceCosts')} 
                  value={maintenance.reduce((sum, m) => sum + Number(m.total_cost || 0), 0).toLocaleString()} 
                  icon={<Calculator />} 
                  color="blue" 
                  desc={t('units.sar')} 
                />
                <DashboardStatCard 
                  title={t('inventoryValue')} 
                  value={spares.reduce((sum, s) => sum + (Number(s.quantity || 0) * Number(s.unit_price || 0)), 0).toLocaleString()} 
                  icon={<Box />} 
                  color="emerald" 
                  desc={t('units.sar')} 
                />
                <DashboardStatCard 
                  title={t('maintenanceOrdersCount')} 
                  value={maintenance.length} 
                  icon={<FileCheck />} 
                  color="amber" 
                  desc={t('units.request')} 
                />
                <DashboardStatCard 
                  title={t('averageMaintenanceCost')} 
                  value={maintenance.length > 0 ? Math.round(maintenance.reduce((sum, m) => sum + Number(m.total_cost || 0), 0) / maintenance.length).toLocaleString() : 0} 
                  icon={<TrendingUp />} 
                  color="rose" 
                  desc={t('units.sar') + "/" + t('units.request')} 
                />
              </div>

              <div className="grid gap-8 lg:grid-cols-2">
                <Card className="rounded-[2.5rem] bg-white/5 backdrop-blur-xl border-white/10 shadow-2xl overflow-hidden">
                  <CardHeader className="p-8 border-b border-white/10 bg-white/5">
                    <CardTitle className="text-xl font-black text-white flex items-center gap-3">
                      <div className="p-2 bg-blue-500/20 rounded-xl">
                        <Calendar className="text-blue-400" size={24} />
                      </div>
                      {t('costsByMonth')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      {(() => {
                        const monthlyData: { [key: string]: number } = {};
                        maintenance.forEach(m => {
                          const date = new Date(m.maintenance_date);
                          const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
                          monthlyData[monthKey] = (monthlyData[monthKey] || 0) + Number(m.total_cost || 0);
                        });
                        const sortedMonths = Object.entries(monthlyData).sort((a, b) => b[0].localeCompare(a[0])).slice(0, 6);
                        const maxValue = Math.max(...sortedMonths.map(([, v]) => v), 1);
                        
                        return sortedMonths.map(([month, cost]) => {
                          const [year, monthNum] = month.split('-');
                          const arMonths = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
                          const enMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                          const monthName = locale === 'ar' ? arMonths[parseInt(monthNum) - 1] : enMonths[parseInt(monthNum) - 1];
                          return (
                            <div key={month} className="space-y-2">
                              <div className="flex justify-between items-center">
                                <span className="text-white/70 font-bold text-sm">{monthName} {year}</span>
                                <span className="text-emerald-400 font-black">{cost.toLocaleString()} {t('units.sar')}</span>
                              </div>
                              <div className="h-3 bg-white/5 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-gradient-to-r from-blue-500 to-emerald-500 rounded-full transition-all duration-500"
                                  style={{ width: `${(cost / maxValue) * 100}%` }}
                                />
                              </div>
                            </div>
                          );
                        });
                      })()}
                      {maintenance.length === 0 && (
                        <div className="text-center text-white/30 py-8">---</div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                <Card className="rounded-[2.5rem] bg-white/5 backdrop-blur-xl border-white/10 shadow-2xl overflow-hidden">
                  <CardHeader className="p-8 border-b border-white/10 bg-white/5">
                    <CardTitle className="text-xl font-black text-white flex items-center gap-3">
                      <div className="p-2 bg-amber-500/20 rounded-xl">
                        <Car className="text-amber-400" size={24} />
                      </div>
                      {t('costsByVehicle')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-white/5 hover:bg-transparent">
                          <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('vehicles')}</TableHead>
                          <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('maintenanceOrdersCount')}</TableHead>
                          <TableHead className="text-white/60 font-black uppercase text-[10px]">{t('totalCost')}</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {(() => {
                          const vehicleCosts: { [key: string]: { plate: string, count: number, cost: number } } = {};
                          maintenance.forEach(m => {
                            const key = m.plate_number_ar;
                            if (!vehicleCosts[key]) {
                              vehicleCosts[key] = { plate: key, count: 0, cost: 0 };
                            }
                            vehicleCosts[key].count++;
                            vehicleCosts[key].cost += Number(m.total_cost || 0);
                          });
                          return Object.values(vehicleCosts)
                            .sort((a, b) => b.cost - a.cost)
                            .slice(0, 8)
                            .map((v, idx) => (
                              <TableRow key={idx} className="border-white/5 hover:bg-white/5 transition-colors">
                                <TableCell className="font-black text-white">
                                  <span className="px-3 py-1 bg-white/10 rounded-lg border border-white/10">{v.plate}</span>
                                </TableCell>
                                <TableCell className="text-white/50 font-bold">{v.count} {t('units.request')}</TableCell>
                                <TableCell className="font-black text-emerald-400">{v.cost.toLocaleString()} <small className="opacity-50">{t('sar')}</small></TableCell>
                              </TableRow>
                            ));
                        })()}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </div>

              <Card className="rounded-[2.5rem] bg-white/5 backdrop-blur-xl border-white/10 shadow-2xl overflow-hidden">
                <CardHeader className="p-8 border-b border-white/10 bg-white/5">
                  <CardTitle className="text-xl font-black text-white flex items-center gap-3">
                    <div className="p-2 bg-emerald-500/20 rounded-xl">
                      <Package className="text-emerald-400" size={24} />
                    </div>
                    {t('comparisonDesc')}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-8">
                  <div className="grid md:grid-cols-2 gap-8">
                    <div className="p-6 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-center space-y-4">
                      <div className="w-16 h-16 bg-blue-500/20 rounded-2xl mx-auto flex items-center justify-center">
                        <Wrench size={32} className="text-blue-400" />
                      </div>
                      <div>
                        <p className="text-blue-300/70 font-bold text-sm uppercase tracking-widest mb-2">{t('totalMaintenanceCosts')}</p>
                        <p className="text-4xl font-black text-blue-400">
                          {maintenance.reduce((sum, m) => sum + Number(m.total_cost || 0), 0).toLocaleString()}
                        </p>
                        <p className="text-blue-300/50 font-bold text-xs mt-1">{t('units.sar')}</p>
                      </div>
                    </div>
                    <div className="p-6 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-center space-y-4">
                      <div className="w-16 h-16 bg-emerald-500/20 rounded-2xl mx-auto flex items-center justify-center">
                        <Box size={32} className="text-emerald-400" />
                      </div>
                      <div>
                        <p className="text-emerald-300/70 font-bold text-sm uppercase tracking-widest mb-2">{t('inventoryValue')}</p>
                        <p className="text-4xl font-black text-emerald-400">
                          {spares.reduce((sum, s) => sum + (Number(s.quantity || 0) * Number(s.unit_price || 0)), 0).toLocaleString()}
                        </p>
                        <p className="text-emerald-300/50 font-bold text-xs mt-1">{t('units.sar')}</p>
                      </div>
                    </div>
                  </div>
                  <div className="mt-8 p-4 rounded-xl bg-white/5 border border-white/10">
                    <div className="flex items-center justify-between">
                      <span className="text-white/50 font-bold">{t('comparisonDesc')}</span>
                      <span className="text-2xl font-black text-amber-400">
                        {(() => {
                          const maintenanceCost = maintenance.reduce((sum, m) => sum + Number(m.total_cost || 0), 0);
                          const inventoryValue = spares.reduce((sum, s) => sum + (Number(s.quantity || 0) * Number(s.unit_price || 0)), 0);
                          return inventoryValue > 0 ? ((maintenanceCost / inventoryValue) * 100).toFixed(1) : 0;
                        })()}%
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {viewingMaintenance && (
          <ViewPrintEmailDialog
            maintenance={viewingMaintenance}
            companyId={companyId}
            companyName={companyName}
            companyEmail={companyEmail}
            onClose={() => setViewingMaintenance(null)}
            t={t}
          />
        )}

        {/* Footer Branding */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] font-black text-white/30 uppercase tracking-widest pt-4">
          <div className="flex items-center gap-2">
            <Sparkles size={10} className="text-blue-500" />
            <span>Logistics Systems Pro</span>
          </div>
          <span>{t('allRightsReserved')} © {new Date().getFullYear()}</span>
        </div>
      </div>

      <DeleteConfirmModal
        open={deleteVehicleId !== null}
        onClose={() => setDeleteVehicleId(null)}
        onConfirm={async () => {
          if (deleteVehicleId) {
            await deleteVehicle(deleteVehicleId);
            setDeleteVehicleId(null);
            setShowDeleteSuccess(true);
            window.location.reload();
          }
        }}
        title={t('confirmDelete')}
      />
      <SuccessModal open={showDeleteSuccess} onClose={() => setShowDeleteSuccess(false)} title={t('success')} />
    </div>
  );
}

interface FleetClientProps {
  initialVehicles: any[];
  initialSpares: any[];
  categories: any[];
  vehicleCategories: any[];
  initialMaintenance: any[];
  employees: any[];
  companyId: number;
  companyName: string;
  companyEmail: string;
}
